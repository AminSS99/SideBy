/**
 * Authentication configuration.
 * When true, uses ClerkProvider with secure token caching and Bearer auth.
 */
export const AUTH_REQUIRED = true;

