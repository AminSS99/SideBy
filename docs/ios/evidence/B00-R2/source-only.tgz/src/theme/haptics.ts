import * as Haptics from 'expo-haptics';
import { Platform } from 'react-native';

export const selection = () => {
  if (Platform.OS === 'ios') {
    Haptics.selectionAsync().catch(() => {});
  }
};

export const lightImpact = () => {
  if (Platform.OS === 'ios') {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
  }
};

export const mediumImpact = () => {
  if (Platform.OS === 'ios') {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
  }
};

export const heavyImpact = () => {
  if (Platform.OS === 'ios') {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy).catch(() => {});
  }
};

export const rigidImpact = () => {
  if (Platform.OS === 'ios') {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Rigid).catch(() => {});
  }
};

export const swapTick = () => {
  if (Platform.OS === 'ios') {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
  }
};

export const scrubberTick = () => {
  if (Platform.OS === 'ios') {
    Haptics.selectionAsync().catch(() => {});
  }
};

export const cardSnap = () => {
  if (Platform.OS === 'ios') {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
  }
};

export const stageMilestone = () => {
  if (Platform.OS === 'ios') {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Rigid).catch(() => {});
  }
};

export const boundaryHit = () => {
  if (Platform.OS === 'ios') {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy).catch(() => {});
  }
};

export const dragStart = () => {
  if (Platform.OS === 'ios') {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
  }
};

export const successNotification = () => {
  if (Platform.OS === 'ios') {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
  }
};

export const errorNotification = () => {
  if (Platform.OS === 'ios') {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error).catch(() => {});
  }
};

export const triggerHaptic = {
  selection,
  lightImpact,
  mediumImpact,
  heavyImpact,
  rigidImpact,
  swapTick,
  scrubberTick,
  cardSnap,
  stageMilestone,
  boundaryHit,
  dragStart,
  successNotification,
  errorNotification,
};
