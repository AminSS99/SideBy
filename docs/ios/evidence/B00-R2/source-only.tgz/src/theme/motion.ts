import { WithSpringConfig } from 'react-native-reanimated';

/**
 * Precision motion physics tokens for SideBy.
 * Calibrated for 60-120fps direct manipulation, tactile micro-feedback, and fluid sheet dynamics.
 */
export const SpringConfigs = {
  /** High-precision micro-interactions: buttons, chips, icons, toggles */
  tactile: {
    damping: 18,
    stiffness: 280,
    mass: 0.8,
  } satisfies WithSpringConfig,

  /** Snappy feedback for quick responses like swap, checkmarks, badges */
  snappy: {
    damping: 20,
    stiffness: 350,
    mass: 0.6,
  } satisfies WithSpringConfig,

  /** Organic, fluid transitions: cards expanding, sheets gliding, route shifts */
  fluid: {
    damping: 22,
    stiffness: 180,
    mass: 1.0,
  } satisfies WithSpringConfig,

  /** Playful physics: bounce alerts, celebration bursts, scrubber over-drag */
  bouncy: {
    damping: 14,
    stiffness: 190,
    mass: 0.9,
  } satisfies WithSpringConfig,

  /** Soft ambient movement: aura glows, floating orbs, backdrop breathing */
  gentle: {
    damping: 28,
    stiffness: 110,
    mass: 1.2,
  } satisfies WithSpringConfig,

  /**
   * Velocity-preserving spring for gesture-driven interactions
   * (e.g. dragging dividers, swiping sheets, flicking cards).
   */
  gesture: (velocity?: number): WithSpringConfig => ({
    damping: 24,
    stiffness: 220,
    mass: 0.9,
    velocity,
  }),
} as const;

/**
 * Standard durations for timing-based non-spring animations
 */
export const MotionDurations = {
  instant: 120,
  quick: 200,
  normal: 300,
  deliberate: 450,
  ambient: 2400,
} as const;
