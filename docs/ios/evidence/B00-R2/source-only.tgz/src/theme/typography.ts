import { Platform, TextStyle } from 'react-native';

export const Fonts = {
  sans: Platform.select({ ios: 'System', default: 'sans-serif' }),
  serif: Platform.select({ ios: 'New York', default: 'serif' }),
};

export const Typography: Record<string, TextStyle> = {
  h1: {
    fontFamily: Fonts.serif,
    fontSize: 32,
    fontWeight: '700',
    lineHeight: 38,
    letterSpacing: -0.6,
  },
  h2: {
    fontFamily: Fonts.serif,
    fontSize: 24,
    fontWeight: '700',
    lineHeight: 30,
    letterSpacing: -0.4,
  },
  h3: {
    fontFamily: Fonts.serif,
    fontSize: 18,
    fontWeight: '600',
    lineHeight: 24,
    letterSpacing: -0.2,
  },
  body: {
    fontFamily: Fonts.sans,
    fontSize: 16,
    lineHeight: 23,
    letterSpacing: -0.2,
  },
  bodySm: {
    fontFamily: Fonts.sans,
    fontSize: 14,
    lineHeight: 20,
    letterSpacing: -0.1,
  },
  caption: {
    fontFamily: Fonts.sans,
    fontSize: 12,
    lineHeight: 16,
    letterSpacing: 0.2,
  },
  label: {
    fontFamily: Fonts.sans,
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
};
