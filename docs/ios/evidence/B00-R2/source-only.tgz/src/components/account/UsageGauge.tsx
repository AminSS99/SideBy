import React from 'react';
import { StyleSheet, View, Text } from 'react-native';
import { Colors } from '../../theme/colors';
import { NormalizedUsage, UsageQuotaMetric } from '../../api/usage';
import { GlassSurface } from '../common/GlassSurface';

interface UsageGaugeProps {
  usage?: NormalizedUsage | null;
  /** 'loading' while the usage query is in flight, 'error' when it failed. */
  loadState?: 'loading' | 'error';
}

function formatMetric(metric: UsageQuotaMetric): string {
  if (metric.state === 'unlimited') return 'Unlimited';
  if (metric.state === 'unknown') return 'Unknown';
  if (metric.used === null) return `Limit ${metric.limit} · used unknown`;
  return `${metric.used} / ${metric.limit}`;
}

function metricPct(metric: UsageQuotaMetric): number {
  if (metric.state !== 'finite' || metric.used === null || metric.limit === null) return 0;
  return Math.min(100, Math.round((metric.used / Math.max(1, metric.limit)) * 100));
}

function MetricRow({
  label,
  metric,
  accent,
}: {
  label: string;
  metric: UsageQuotaMetric;
  accent: string;
}) {
  return (
    <View style={styles.metricSection}>
      <View style={styles.metricHeader}>
        <Text style={styles.metricLabel}>{label}</Text>
        <Text style={[styles.metricCount, { color: accent }]}>{formatMetric(metric)}</Text>
      </View>
      <View style={styles.track}>
        <View style={[styles.fill, { width: `${metricPct(metric)}%`, backgroundColor: accent }]} />
      </View>
    </View>
  );
}

export function UsageGauge({ usage, loadState }: UsageGaugeProps) {
  if (loadState === 'loading' && !usage) {
    return (
      <GlassSurface style={styles.container}>
        <Text style={styles.planKicker}>CURRENT SUBSCRIPTION</Text>
        <Text style={styles.planTitle}>Loading usage…</Text>
        <Text style={styles.unavailableDesc}>
          Fetching your current plan and quota from the server.
        </Text>
      </GlassSurface>
    );
  }

  if (loadState === 'error' || !usage) {
    return (
      <GlassSurface style={styles.container}>
        <View style={styles.header}>
          <View>
            <Text style={styles.planKicker}>CURRENT SUBSCRIPTION</Text>
            <Text style={styles.planTitle}>Usage unavailable</Text>
          </View>
          <View style={[styles.badge, styles.badgeUnknown]}>
            <Text style={[styles.badgeText, styles.badgeTextUnknown]}>Unknown</Text>
          </View>
        </View>
        <Text style={styles.unavailableDesc}>
          Quota could not be loaded. No usage or remaining counts are shown because
          the server state is unknown.
        </Text>
      </GlassSurface>
    );
  }

  return (
    <GlassSurface style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.planKicker}>CURRENT SUBSCRIPTION</Text>
          <Text style={styles.planTitle}>{usage.plan}</Text>
        </View>
        {usage.planKnown ? (
          <View style={styles.badge}>
            <Text style={styles.badgeText}>Active</Text>
          </View>
        ) : (
          <View style={[styles.badge, styles.badgeUnknown]}>
            <Text style={[styles.badgeText, styles.badgeTextUnknown]}>Unknown</Text>
          </View>
        )}
      </View>

      <MetricRow label="Daily Deep Comparisons" metric={usage.comparison} accent={Colors.copper} />
      <MetricRow label="Follow-up Evidence Queries" metric={usage.followUp} accent={Colors.cyan} />
      <MetricRow label="Daily Re-evaluations" metric={usage.refresh} accent={Colors.violet} />

      {!usage.planKnown && (
        <Text style={styles.unavailableDesc}>
          Plan details are unknown — quota figures marked Unknown were not reported
          by the server.
        </Text>
      )}
    </GlassSurface>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    borderRadius: 22,
    marginBottom: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 20,
  },
  planKicker: {
    fontSize: 10,
    fontWeight: '700',
    color: Colors.muted,
    letterSpacing: 1.2,
    marginBottom: 4,
  },
  planTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: Colors.ivory,
  },
  badge: {
    backgroundColor: 'rgba(52, 199, 89, 0.15)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'rgba(52, 199, 89, 0.3)',
  },
  badgeText: {
    fontSize: 11,
    fontWeight: '700',
    color: Colors.success,
  },
  badgeUnknown: {
    backgroundColor: 'rgba(169, 176, 192, 0.12)',
    borderColor: 'rgba(169, 176, 192, 0.35)',
  },
  badgeTextUnknown: {
    color: Colors.muted,
  },
  unavailableDesc: {
    fontSize: 13,
    color: Colors.muted,
    lineHeight: 18,
    marginTop: 12,
  },
  metricSection: {
    marginBottom: 16,
  },
  metricHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  metricLabel: {
    fontSize: 13,
    color: Colors.ivory,
    fontWeight: '500',
  },
  metricCount: {
    fontSize: 13,
    fontWeight: '700',
  },
  track: {
    height: 6,
    borderRadius: 3,
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    overflow: 'hidden',
  },
  fill: {
    height: '100%',
    borderRadius: 3,
  },
});
