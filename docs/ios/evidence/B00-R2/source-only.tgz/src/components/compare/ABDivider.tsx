import React from 'react';
import { StyleSheet, View, Pressable, Text } from 'react-native';
import { Colors } from '../../theme/colors';
import { triggerHaptic } from '../../theme/haptics';

interface ABDividerProps {
  onSwap?: () => void;
  entityAName?: string;
  entityBName?: string;
}

export function ABDivider({ onSwap, entityAName, entityBName }: ABDividerProps) {
  const handleSwap = () => {
    triggerHaptic.lightImpact();
    if (onSwap) {
      onSwap();
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.line} />
      <View style={styles.badgeRow}>
        <View style={[styles.entityPill, { backgroundColor: Colors.copperSoft, borderColor: Colors.copper }]}>
          <Text style={[styles.entityText, { color: Colors.copper }]}>A</Text>
        </View>

        {onSwap ? (
          <Pressable style={styles.swapButton} onPress={handleSwap} accessibilityLabel="Swap entities">
            <Text style={styles.swapIcon}>⇄</Text>
          </Pressable>
        ) : (
          <Text style={styles.vsText}>VS</Text>
        )}

        <View style={[styles.entityPill, { backgroundColor: Colors.cyanSoft, borderColor: Colors.cyan }]}>
          <Text style={[styles.entityText, { color: Colors.cyan }]}>B</Text>
        </View>
      </View>
      <View style={styles.line} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 16,
  },
  line: {
    flex: 1,
    height: 1,
    backgroundColor: Colors.border,
  },
  badgeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    gap: 8,
  },
  entityPill: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    borderWidth: 1,
  },
  entityText: {
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  swapButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.raisedTitanium,
    borderWidth: 1,
    borderColor: Colors.borderLight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  swapIcon: {
    color: Colors.ivory,
    fontSize: 18,
    fontWeight: '600',
  },
  vsText: {
    color: Colors.muted,
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 1,
  },
});
