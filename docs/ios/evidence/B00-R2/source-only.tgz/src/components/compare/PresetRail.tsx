import React from 'react';
import { StyleSheet, View, Text, ScrollView } from 'react-native';
import { PressableScale } from '../common/PressableScale';
import { LiquidGlass } from '../common/LiquidGlass';
import { Colors } from '../../theme/colors';

export interface PresetItem {
  a: string;
  b: string;
  context: string;
}

export interface PresetRailProps {
  presets: PresetItem[];
  onSelectPreset: (preset: PresetItem) => void;
}

export function PresetRail({ presets, onSelectPreset }: PresetRailProps) {
  return (
    <View style={styles.container}>
      <Text style={styles.sectionHeading}>CURATED BENCHMARKS</Text>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
        decelerationRate="fast"
      >
        {presets.map((preset, idx) => (
          <PressableScale
            key={idx}
            haptic="selection"
            activeScale={0.92}
            onPress={() => onSelectPreset(preset)}
          >
            <LiquidGlass
              borderRadius={14}
              intensity={45}
              specularColor="rgba(255, 255, 255, 0.22)"
              style={styles.chipGlass}
              contentStyle={styles.chipContent}
            >
              <Text style={styles.chipA}>{preset.a}</Text>
              <Text style={styles.chipVs}>vs</Text>
              <Text style={styles.chipB}>{preset.b}</Text>
            </LiquidGlass>
          </PressableScale>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 20,
  },
  sectionHeading: {
    color: 'rgba(211, 217, 231, 0.60)',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.2,
    marginBottom: 10,
    paddingHorizontal: 2,
  },
  scrollContent: {
    gap: 8,
    paddingRight: 10,
  },
  chipGlass: {
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.12)',
  },
  chipContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 9,
  },
  chipA: {
    color: Colors.copper,
    fontSize: 13,
    fontWeight: '700',
  },
  chipVs: {
    color: 'rgba(255, 255, 255, 0.35)',
    fontSize: 11,
    fontWeight: '600',
  },
  chipB: {
    color: Colors.cyan,
    fontSize: 13,
    fontWeight: '700',
  },
});
