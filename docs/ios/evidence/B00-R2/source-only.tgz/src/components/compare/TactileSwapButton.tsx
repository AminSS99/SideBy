import React from 'react';
import { StyleSheet, View } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  useReducedMotion,
} from 'react-native-reanimated';
import { SymbolView } from 'expo-symbols';
import { PressableScale } from '../common/PressableScale';
import { LiquidGlass } from '../common/LiquidGlass';
import { Colors } from '../../theme/colors';
import { SpringConfigs } from '../../theme/motion';
import { triggerHaptic } from '../../theme/haptics';

export interface TactileSwapButtonProps {
  onSwap: () => void;
}

export function TactileSwapButton({ onSwap }: TactileSwapButtonProps) {
  const rotation = useSharedValue(0);
  const reducedMotion = useReducedMotion();

  const handlePress = () => {
    triggerHaptic.swapTick();
    if (!reducedMotion) {
      rotation.value = withSpring(
        rotation.value + 180,
        SpringConfigs.bouncy
      );
    }
    onSwap();
  };

  const animatedIconStyle = useAnimatedStyle(() => {
    'worklet';
    return {
      transform: [{ rotate: `${rotation.value}deg` }],
    };
  });

  return (
    <View style={styles.swapRow}>
      <View style={styles.dividerLine} />
      <PressableScale
        haptic="none"
        activeScale={0.88}
        style={styles.swapButtonWrapper}
        onPress={handlePress}
        accessibilityLabel="Swap Option A and Option B"
      >
        <LiquidGlass
          borderRadius={22}
          intensity={65}
          specularColor="rgba(255, 255, 255, 0.45)"
          style={styles.swapButtonGlass}
          contentStyle={styles.swapButtonContent}
        >
          <Animated.View style={animatedIconStyle}>
            <SymbolView
              name="arrow.triangle.2.circlepath"
              tintColor={Colors.ivory}
              size={19}
            />
          </Animated.View>
        </LiquidGlass>
      </PressableScale>
      <View style={styles.dividerLine} />
    </View>
  );
}

const styles = StyleSheet.create({
  swapRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: -14,
    zIndex: 10,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.10)',
  },
  swapButtonWrapper: {
    marginHorizontal: 12,
    borderRadius: 22,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
  },
  swapButtonGlass: {
    width: 44,
    height: 44,
    borderRadius: 22,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.22)',
  },
  swapButtonContent: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
