import React, { useRef, useState } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  TextInputProps,
  Pressable,
} from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  useReducedMotion,
} from 'react-native-reanimated';
import { SymbolView } from 'expo-symbols';
import { LiquidGlass } from '../common/LiquidGlass';
import { Colors } from '../../theme/colors';
import { SpringConfigs } from '../../theme/motion';
import { triggerHaptic } from '../../theme/haptics';

interface ContenderInputCardProps extends Omit<TextInputProps, 'style'> {
  optionKey: 'A' | 'B';
  label: string;
  value: string;
  onChangeText: (text: string) => void;
  accentColor: string;
  softColor: string;
  placeholder: string;
}

export function ContenderInputCard({
  optionKey,
  label,
  value,
  onChangeText,
  accentColor,
  softColor,
  placeholder,
  ...inputProps
}: ContenderInputCardProps) {
  const inputRef = useRef<TextInput>(null);
  const [isFocused, setIsFocused] = useState(false);
  const reducedMotion = useReducedMotion();

  const focusScale = useSharedValue(1);
  const glowOpacity = useSharedValue(0.2);
  const clearScale = useSharedValue(value.length > 0 ? 1 : 0);

  React.useEffect(() => {
    if (!reducedMotion) {
      clearScale.value = withSpring(value.length > 0 ? 1 : 0, SpringConfigs.snappy);
    } else {
      clearScale.value = value.length > 0 ? 1 : 0;
    }
  }, [value.length > 0, reducedMotion]);

  const handleFocus = () => {
    setIsFocused(true);
    triggerHaptic.lightImpact();
    if (!reducedMotion) {
      focusScale.value = withSpring(1.015, SpringConfigs.tactile);
      glowOpacity.value = withSpring(0.65, SpringConfigs.tactile);
    }
  };

  const handleBlur = () => {
    setIsFocused(false);
    if (!reducedMotion) {
      focusScale.value = withSpring(1, SpringConfigs.tactile);
      glowOpacity.value = withSpring(0.2, SpringConfigs.tactile);
    }
  };

  const handleClear = () => {
    triggerHaptic.selection();
    onChangeText('');
    inputRef.current?.focus();
  };

  const animatedCardStyle = useAnimatedStyle(() => {
    'worklet';
    return {
      transform: [{ scale: focusScale.value }],
    };
  });

  const animatedGlowStyle = useAnimatedStyle(() => {
    'worklet';
    return {
      opacity: glowOpacity.value,
    };
  });

  const animatedClearStyle = useAnimatedStyle(() => {
    'worklet';
    return {
      transform: [{ scale: clearScale.value }],
      opacity: clearScale.value,
    };
  });

  return (
    <Animated.View style={[styles.wrapper, animatedCardStyle]}>
      {/* Outer Focused Radiance Aura */}
      <Animated.View
        style={[
          styles.glowAura,
          {
            backgroundColor: accentColor,
            shadowColor: accentColor,
          },
          animatedGlowStyle,
        ]}
        pointerEvents="none"
      />

      <LiquidGlass
        intensity={85}
        glowColor={isFocused ? softColor : undefined}
        specularColor={isFocused ? accentColor : 'rgba(255, 255, 255, 0.22)'}
        borderRadius={22}
        style={[
          styles.card,
          {
            borderColor: isFocused ? accentColor : 'rgba(255, 255, 255, 0.12)',
          },
        ]}
        contentStyle={styles.cardContent}
      >
        {/* Card Header Row */}
        <View style={styles.headerRow}>
          <View style={[styles.pill, { backgroundColor: softColor }]}>
            <Text style={[styles.pillText, { color: accentColor }]}>
              {label}
            </Text>
          </View>

          <View style={styles.headerRight}>
            <Animated.View
              style={[styles.clearWrapper, animatedClearStyle]}
              pointerEvents={value.length > 0 ? 'auto' : 'none'}
            >
              <Pressable
                onPress={handleClear}
                hitSlop={8}
                style={styles.clearButton}
                accessibilityLabel={`Clear ${label}`}
              >
                <SymbolView
                  name="xmark.circle.fill"
                  tintColor="rgba(255, 255, 255, 0.45)"
                  size={16}
                />
              </Pressable>
            </Animated.View>
            <SymbolView name="sparkle" tintColor={accentColor} size={15} />
          </View>
        </View>

        {/* Input Field */}
        <TextInput
          ref={inputRef}
          style={[styles.input, { color: accentColor }]}
          placeholder={placeholder}
          placeholderTextColor="rgba(211, 217, 231, 0.35)"
          value={value}
          onChangeText={onChangeText}
          onFocus={handleFocus}
          onBlur={handleBlur}
          autoCapitalize="words"
          autoCorrect={false}
          returnKeyType="next"
          {...inputProps}
        />
      </LiquidGlass>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    position: 'relative',
  },
  glowAura: {
    ...StyleSheet.absoluteFill,
    borderRadius: 24,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 18,
  },
  card: {
    borderWidth: 1,
  },
  cardContent: {
    padding: 18,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  pill: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 100,
  },
  pillText: {
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.2,
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  clearWrapper: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  clearButton: {
    padding: 2,
  },
  input: {
    fontSize: 24,
    fontWeight: '700',
    letterSpacing: -0.4,
    paddingVertical: 4,
  },
});
