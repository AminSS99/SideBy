import React from 'react';
import { StyleProp, ViewStyle, Pressable, PressableProps } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  useReducedMotion,
} from 'react-native-reanimated';
import { SpringConfigs } from '../../theme/motion';
import { triggerHaptic } from '../../theme/haptics';

export interface PressableScaleProps extends Omit<PressableProps, 'style'> {
  style?: StyleProp<ViewStyle>;
  activeScale?: number;
  haptic?: 'light' | 'medium' | 'heavy' | 'selection' | 'none';
  children: React.ReactNode;
}

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

export function PressableScale({
  style,
  activeScale = 0.96,
  haptic = 'light',
  children,
  onPressIn,
  onPressOut,
  onPress,
  disabled,
  ...rest
}: PressableScaleProps) {
  const scale = useSharedValue(1);
  const opacity = useSharedValue(1);
  const reducedMotion = useReducedMotion();

  const animatedStyle = useAnimatedStyle(() => {
    'worklet';
    return {
      transform: [{ scale: scale.value }],
      opacity: opacity.value,
    };
  });

  const handlePressIn = (e: any) => {
    if (disabled) return;
    if (haptic === 'light') triggerHaptic.lightImpact();
    else if (haptic === 'medium') triggerHaptic.mediumImpact();
    else if (haptic === 'heavy') triggerHaptic.heavyImpact();
    else if (haptic === 'selection') triggerHaptic.selection();

    if (!reducedMotion) {
      scale.value = withSpring(activeScale, SpringConfigs.tactile);
      opacity.value = withSpring(0.92, SpringConfigs.tactile);
    }
    onPressIn?.(e);
  };

  const handlePressOut = (e: any) => {
    if (disabled) return;
    if (!reducedMotion) {
      scale.value = withSpring(1, SpringConfigs.tactile);
      opacity.value = withSpring(1, SpringConfigs.tactile);
    }
    onPressOut?.(e);
  };

  React.useEffect(() => {
    if (disabled) {
      scale.value = withSpring(1, SpringConfigs.tactile);
      opacity.value = withSpring(1, SpringConfigs.tactile);
    }
  }, [disabled, scale, opacity]);

  return (
    <AnimatedPressable
      {...rest}
      disabled={disabled}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      onPress={onPress}
      style={[style, animatedStyle]}
    >
      {children}
    </AnimatedPressable>
  );
}
