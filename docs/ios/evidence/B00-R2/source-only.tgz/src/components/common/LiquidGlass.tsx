import React from 'react';
import { Platform, StyleProp, StyleSheet, View, ViewStyle } from 'react-native';
import { BlurView, BlurTint } from 'expo-blur';
import {
  GlassView,
  isGlassEffectAPIAvailable,
  isLiquidGlassAvailable,
} from 'expo-glass-effect';
import { LinearGradient } from 'expo-linear-gradient';

export interface LiquidGlassProps {
  children?: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  contentStyle?: StyleProp<ViewStyle>;
  intensity?: number;
  tint?: BlurTint;
  tintColor?: string;
  glowColor?: string;
  specularColor?: string;
  borderRadius?: number;
  interactive?: boolean;
  testID?: string;
}

/**
 * Optical Liquid Glass Surface for SideBy.
 * Replaces basic blur containers with multi-layer refraction, subsurface ambient tinting,
 * continuous squircle curvature, and specular edge reflections.
 */
export function LiquidGlass({
  children,
  style,
  contentStyle,
  intensity = 80,
  tint = 'systemUltraThinMaterialDark',
  tintColor = 'rgba(15, 18, 27, 0.45)',
  glowColor,
  specularColor = 'rgba(255, 255, 255, 0.30)',
  borderRadius = 22,
  interactive = false,
  testID,
}: LiquidGlassProps) {
  const supportsNativeGlass =
    Platform.OS === 'ios' &&
    isLiquidGlassAvailable() &&
    isGlassEffectAPIAvailable();

  return (
    <View
      testID={testID}
      style={[
        styles.container,
        {
          borderRadius,
          borderCurve: 'continuous',
        },
        style,
      ]}
    >
      {/* Layer 1: Subsurface Glow (Optional Contender Ambient Radiance) */}
      {glowColor ? (
        <LinearGradient
          colors={[glowColor, 'transparent']}
          start={{ x: 0.1, y: 0 }}
          end={{ x: 0.9, y: 1 }}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
      ) : null}

      {/* Layer 2: Optical Frosted Refraction */}
      {supportsNativeGlass ? (
        <GlassView
          isInteractive={interactive}
          glassEffectStyle="regular"
          tintColor={tintColor}
          style={StyleSheet.absoluteFill}
        />
      ) : (
        <BlurView
          tint={tint}
          intensity={intensity}
          experimentalBlurMethod="dimezisBlurView"
          style={StyleSheet.absoluteFill}
        />
      )}

      {/* Layer 3: Physical Specular Bevel (Top Light Catch) */}
      <LinearGradient
        colors={[
          specularColor,
          'rgba(255, 255, 255, 0.08)',
          'rgba(255, 255, 255, 0.02)',
        ]}
        locations={[0, 0.35, 1]}
        start={{ x: 0.5, y: 0 }}
        end={{ x: 0.5, y: 1 }}
        style={[
          styles.specularBorder,
          {
            borderRadius,
            borderCurve: 'continuous',
          },
        ]}
        pointerEvents="none"
      />

      {/* Layer 4: Content Surface */}
      <View
        style={[
          styles.content,
          {
            borderRadius,
            borderCurve: 'continuous',
          },
          contentStyle,
        ]}
      >
        {children}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'relative',
    overflow: 'hidden',
    backgroundColor: 'rgba(12, 15, 24, 0.40)',
  },
  specularBorder: {
    ...StyleSheet.absoluteFill,
    borderWidth: 1,
    borderColor: 'transparent',
  },
  content: {
    position: 'relative',
    zIndex: 1,
  },
});
