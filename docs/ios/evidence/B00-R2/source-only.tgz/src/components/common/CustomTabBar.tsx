import React from 'react';
import { StyleSheet, View, Pressable, Text } from 'react-native';
import { BottomTabBarProps } from '@react-navigation/bottom-tabs';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { SymbolView } from 'expo-symbols';
import { Colors } from '../../theme/colors';
import { triggerHaptic } from '../../theme/haptics';
import { GlassSurface } from './GlassSurface';

export function CustomTabBar({ state, descriptors, navigation }: BottomTabBarProps) {
  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.wrapper, { paddingBottom: Math.max(insets.bottom, 16) }]}>
      <GlassSurface
        intensity={92}
        tint="systemChromeMaterialDark"
        tintColor="rgba(12, 16, 28, 0.42)"
        style={styles.dockContainer}
      >
        {state.routes.map((route: any, index: number) => {
          const { options } = descriptors[route.key];
          const label =
            options.tabBarLabel !== undefined
              ? options.tabBarLabel
              : options.title !== undefined
              ? options.title
              : route.name;

          const isFocused = state.index === index;

          const onPress = () => {
            triggerHaptic.selection();
            const event = navigation.emit({
              type: 'tabPress',
              target: route.key,
              canPreventDefault: true,
            });

            if (!isFocused && !event.defaultPrevented) {
              navigation.navigate(route.name);
            }
          };

          let symbolConfig = 'sparkles';
          if (route.name === 'index' || route.name === 'compare') {
            symbolConfig = 'arrow.left.arrow.right';
          } else if (route.name === 'history') {
            symbolConfig = 'clock.arrow.circlepath';
          } else if (route.name === 'sources') {
            symbolConfig = 'doc.text';
          }

          return (
            <Pressable
              key={route.key}
              accessibilityRole="button"
              accessibilityState={isFocused ? { selected: true } : {}}
              accessibilityLabel={options.tabBarAccessibilityLabel || String(label)}
              testID={(options as any).tabBarTestID || (options as any).tabBarButtonTestID}
              onPress={onPress}
              style={({ pressed }) => [
                styles.tabButton,
                isFocused && styles.tabButtonActive,
                pressed && styles.tabButtonPressed,
              ]}
            >
              <SymbolView
                name={symbolConfig as any}
                tintColor={isFocused ? Colors.ivory : Colors.muted}
                size={20}
                style={styles.tabIcon}
              />
              <Text
                style={[
                  styles.tabLabel,
                  { color: isFocused ? Colors.ivory : Colors.muted },
                  isFocused && styles.tabLabelActive,
                ]}
              >
                {String(label)}
              </Text>
              {isFocused && <View style={styles.activeGlow} />}
            </Pressable>
          );
        })}
      </GlassSurface>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent',
    paddingHorizontal: 24,
  },
  dockContainer: {
    flexDirection: 'row',
    borderRadius: 34,
    paddingVertical: 7,
    paddingHorizontal: 8,
    boxShadow: '0 18px 42px rgba(0, 0, 0, 0.48)',
    width: '100%',
    maxWidth: 356,
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  tabButton: {
    minHeight: 48,
    minWidth: 96,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 24,
    position: 'relative',
    overflow: 'hidden',
  },
  tabButtonActive: {
    backgroundColor: 'rgba(255, 255, 255, 0.12)',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(255, 255, 255, 0.24)',
  },
  tabButtonPressed: {
    transform: [{ scale: 0.96 }],
  },
  tabIcon: {
    marginBottom: 4,
  },
  tabLabel: {
    fontSize: 11,
    fontWeight: '500',
    letterSpacing: 0.2,
  },
  tabLabelActive: {
    fontWeight: '700',
  },
  activeGlow: {
    position: 'absolute',
    bottom: -12,
    width: 54,
    height: 20,
    borderRadius: 27,
    backgroundColor: 'rgba(110, 217, 230, 0.22)',
  },
});
