import React from 'react';
import { StyleSheet, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors } from '../../theme/colors';

export function BackgroundTexture({ children }: { children?: React.ReactNode }) {
  return (
    <View style={styles.container}>
      {/* Deep Obsidian Canvas matching SideBy Web */}
      <LinearGradient
        colors={['#08080A', '#0D0D11', '#08080A']}
        locations={[0, 0.5, 1]}
        style={StyleSheet.absoluteFill}
      />

      {/* Subtle organic ambient glowing orbs */}
      <View style={[styles.glow, styles.glowCopper]} />
      <View style={[styles.glow, styles.glowCyan]} />

      {/* Ultra-fine frosted vignette */}
      <LinearGradient
        colors={['rgba(255, 255, 255, 0.015)', 'transparent', 'rgba(0, 0, 0, 0.4)']}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />

      <View style={styles.content}>{children}</View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  content: {
    flex: 1,
  },
  glow: {
    position: 'absolute',
    borderRadius: 999,
  },
  glowCopper: {
    width: 280,
    height: 280,
    top: -90,
    right: -70,
    backgroundColor: 'rgba(255, 120, 82, 0.10)',
  },
  glowCyan: {
    width: 320,
    height: 320,
    bottom: 80,
    left: -120,
    backgroundColor: 'rgba(60, 191, 220, 0.07)',
  },
});
