import React from 'react';
import { StyleSheet, View, ViewStyle, StyleProp } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

export interface SpecularBorderProps {
  children?: React.ReactNode;
  borderRadius?: number;
  borderWidth?: number;
  highlightColor?: string;
  baseBorderColor?: string;
  style?: StyleProp<ViewStyle>;
  contentStyle?: StyleProp<ViewStyle>;
  pointerEvents?: 'box-none' | 'none' | 'box-only' | 'auto';
}

/**
 * SpecularBorder wraps content with a physical light-catching rim.
 * Emulates the 0.5px incandescent top bevel seen in Linear, Raycast, and Apple VisionOS.
 */
export function SpecularBorder({
  children,
  borderRadius = 22,
  borderWidth = 1,
  highlightColor = 'rgba(255, 255, 255, 0.38)',
  baseBorderColor = 'rgba(255, 255, 255, 0.08)',
  style,
  contentStyle,
  pointerEvents = 'box-none',
}: SpecularBorderProps) {
  return (
    <View
      style={[
        styles.outerContainer,
        { borderRadius, borderCurve: 'continuous' },
        style,
      ]}
      pointerEvents={pointerEvents}
    >
      {/* 0.5px Incandescent Top-to-Bottom Gradient Rim */}
      <LinearGradient
        colors={[highlightColor, baseBorderColor, 'rgba(255, 255, 255, 0.03)']}
        locations={[0, 0.45, 1]}
        start={{ x: 0.5, y: 0 }}
        end={{ x: 0.5, y: 1 }}
        style={[
          StyleSheet.absoluteFill,
          {
            borderRadius,
            borderCurve: 'continuous',
            padding: borderWidth,
          },
        ]}
        pointerEvents="none"
      >
        <View
          style={[
            styles.innerMask,
            {
              borderRadius: Math.max(0, borderRadius - borderWidth),
              borderCurve: 'continuous',
            },
          ]}
        />
      </LinearGradient>

      {/* Inner Children Content */}
      {children != null ? (
        <View
          style={[
            styles.content,
            { borderRadius, borderCurve: 'continuous' },
            contentStyle,
          ]}
        >
          {children}
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  outerContainer: {
    position: 'relative',
    overflow: 'hidden',
  },
  innerMask: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  content: {
    flex: 1,
  },
});
