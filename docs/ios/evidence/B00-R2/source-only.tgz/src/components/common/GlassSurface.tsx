import React from 'react';
import { StyleProp, StyleSheet, ViewStyle } from 'react-native';
import { BlurView, BlurTint } from 'expo-blur';
import {
  GlassView,
  isGlassEffectAPIAvailable,
  isLiquidGlassAvailable,
} from 'expo-glass-effect';

interface GlassSurfaceProps {
  children?: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  intensity?: number;
  tint?: BlurTint;
  tintColor?: string;
  interactive?: boolean;
  testID?: string;
}

export function GlassSurface({
  children,
  style,
  intensity = 78,
  tint = 'systemUltraThinMaterialDark',
  tintColor = 'rgba(20, 24, 34, 0.34)',
  interactive = false,
  testID,
}: GlassSurfaceProps) {
  const supportsNativeGlass =
    process.env.EXPO_OS === 'ios' &&
    isLiquidGlassAvailable() &&
    isGlassEffectAPIAvailable();

  if (supportsNativeGlass) {
    return (
      <GlassView
        testID={testID}
        isInteractive={interactive}
        glassEffectStyle="regular"
        tintColor={tintColor}
        style={[styles.surface, style]}
      >
        {children}
      </GlassView>
    );
  }

  return (
    <BlurView
      testID={testID}
      tint={tint}
      intensity={intensity}
      experimentalBlurMethod="dimezisBlurView"
      style={[styles.surface, style]}
    >
      {children}
    </BlurView>
  );
}

const styles = StyleSheet.create({
  surface: {
    overflow: 'hidden',
    borderCurve: 'continuous',
    backgroundColor: 'rgba(18, 22, 31, 0.36)',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(255, 255, 255, 0.22)',
  },
});
