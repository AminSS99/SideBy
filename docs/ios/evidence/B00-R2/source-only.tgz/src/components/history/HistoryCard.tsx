import React from 'react';
import { StyleSheet, View, Text } from 'react-native';
import { SymbolView } from 'expo-symbols';
import { Colors } from '../../theme/colors';
import { GlassSurface } from '../common/GlassSurface';
import { PressableScale } from '../common/PressableScale';

interface HistoryCardProps {
  item: {
    id: string;
    entityA?: string;
    entityB?: string;
    query?: string;
    summary?: string;
    status: 'running' | 'completed' | 'failed';
    updatedAt: string;
    createdAt?: string;
    sourceCount?: number;
    useCase?: string;
    verdictTitle?: string;
    isFavorited?: boolean;
  };
  onPress: () => void;
  onToggleFavorite?: () => void;
}

export function HistoryCard({ item, onPress }: HistoryCardProps) {
  const isRunning = item.status === 'running';
  const isFailed = item.status === 'failed';

  return (
    <PressableScale haptic="light" activeScale={0.97} onPress={onPress}>
      <GlassSurface intensity={80} style={styles.card}>
        <View style={styles.topRow}>
          <View style={styles.entitiesRow}>
            <Text style={[styles.entityText, { color: Colors.copper }]}>
              {item.entityA || 'Option A'}
            </Text>
            <Text style={styles.vsText}>VS</Text>
            <Text style={[styles.entityText, { color: Colors.cyan }]}>
              {item.entityB || 'Option B'}
            </Text>
          </View>

          <View style={styles.badgesRight}>
            {item.isFavorited ? (
              <SymbolView name="star.fill" tintColor={Colors.copper} size={14} />
            ) : null}

            <View
              style={[
                styles.statusBadge,
                isRunning && styles.statusRunning,
                isFailed && styles.statusFailed,
              ]}
            >
              <Text
                style={[
                  styles.statusText,
                  isRunning && styles.statusTextRunning,
                  isFailed && styles.statusTextFailed,
                ]}
              >
                {isRunning ? 'RUNNING' : isFailed ? 'FAILED' : 'EVALUATED'}
              </Text>
            </View>
          </View>
        </View>

        {item.query ? (
          <Text style={styles.summaryText} numberOfLines={2}>
            {item.summary || item.query}
          </Text>
        ) : null}

        <View style={styles.bottomRow}>
          <View style={styles.sourceRow}>
            <SymbolView name="checkmark.seal.fill" tintColor={Colors.cyan} size={12} />
            <Text style={styles.sourceCountText}>
              {item.sourceCount || 16} Verified Sources
            </Text>
          </View>

          <Text style={styles.arrowText}>View Report →</Text>
        </View>
      </GlassSurface>
    </PressableScale>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 20,
    marginBottom: 12,
    padding: 18,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.12)',
  },
  topRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  entitiesRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    flex: 1,
    marginRight: 8,
  },
  badgesRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
  },
  entityText: {
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: -0.2,
  },
  vsText: {
    color: 'rgba(255, 255, 255, 0.35)',
    fontSize: 10,
    fontWeight: '800',
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.15)',
  },
  statusRunning: {
    borderColor: Colors.warning,
    backgroundColor: 'rgba(255, 149, 0, 0.15)',
  },
  statusFailed: {
    borderColor: Colors.error,
    backgroundColor: 'rgba(255, 59, 48, 0.15)',
  },
  statusText: {
    color: Colors.ivory,
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 0.8,
  },
  statusTextRunning: {
    color: Colors.warning,
  },
  statusTextFailed: {
    color: Colors.error,
  },
  summaryText: {
    color: 'rgba(211, 217, 231, 0.80)',
    fontSize: 13,
    lineHeight: 18,
    marginBottom: 12,
  },
  bottomRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.06)',
  },
  sourceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  sourceCountText: {
    color: 'rgba(211, 217, 231, 0.60)',
    fontSize: 11,
    fontWeight: '600',
  },
  arrowText: {
    color: Colors.ivory,
    fontSize: 12,
    fontWeight: '700',
  },
});
