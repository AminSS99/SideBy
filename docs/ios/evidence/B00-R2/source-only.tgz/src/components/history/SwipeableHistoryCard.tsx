import React from 'react';
import { StyleSheet, View, Text } from 'react-native';
import {
  Gesture,
  GestureDetector,
} from 'react-native-gesture-handler';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  runOnJS,
} from 'react-native-reanimated';
import { SymbolView } from 'expo-symbols';
import { Colors } from '../../theme/colors';
import { SpringConfigs } from '../../theme/motion';
import { triggerHaptic } from '../../theme/haptics';
import { LiquidGlass } from '../common/LiquidGlass';
import { PressableScale } from '../common/PressableScale';

export interface HistoryCardItem {
  id: string;
  entityA?: string;
  entityB?: string;
  query?: string;
  summary?: string;
  status: 'running' | 'completed' | 'failed';
  updatedAt: string;
  createdAt?: string;
  sourceCount?: number;
  useCase?: string;
  verdictTitle?: string;
  isFavorited?: boolean;
}

export interface SwipeableHistoryCardProps {
  item: HistoryCardItem;
  onPress: () => void;
  onToggleFavorite?: () => void;
}

export function SwipeableHistoryCard({
  item,
  onPress,
  onToggleFavorite,
}: SwipeableHistoryCardProps) {
  const isRunning = item.status === 'running';
  const isFailed = item.status === 'failed';

  const translateX = useSharedValue(0);
  const swipedPastThreshold = useSharedValue(false);

  const notifySnap = () => {
    triggerHaptic.cardSnap();
  };

  const panGesture = Gesture.Pan()
    .activeOffsetX([-10, 10])
    .onUpdate((event) => {
      // Allow swiping left up to -100px with resistance beyond -80px
      if (event.translationX < 0) {
        if (event.translationX < -80) {
          const overdrag = event.translationX - (-80);
          translateX.value = Math.max(-100, -80 + overdrag * 0.25);
        } else {
          translateX.value = event.translationX;
        }
        if (event.translationX < -60 && !swipedPastThreshold.value) {
          swipedPastThreshold.value = true;
          runOnJS(notifySnap)();
        }
      } else {
        translateX.value = Math.min(20, event.translationX * 0.2);
      }
    })
    .onEnd((event) => {
      if (translateX.value < -50) {
        translateX.value = withSpring(-80, SpringConfigs.tactile);
      } else {
        translateX.value = withSpring(0, SpringConfigs.tactile);
      }
      swipedPastThreshold.value = false;
    });

  const animatedCardStyle = useAnimatedStyle(() => {
    'worklet';
    return {
      transform: [{ translateX: translateX.value }],
    };
  });

  const actionAnimatedStyle = useAnimatedStyle(() => {
    'worklet';
    const progress = Math.min(1, Math.max(0, Math.abs(translateX.value) / 80));
    return {
      transform: [{ scale: 0.6 + 0.4 * progress }],
      opacity: progress,
    };
  });

  const resetSwipe = () => {
    translateX.value = withSpring(0, SpringConfigs.tactile);
  };

  const handleFavoriteAction = () => {
    triggerHaptic.selection();
    resetSwipe();
    onToggleFavorite?.();
  };

  return (
    <View style={styles.container}>
      {/* Background Revealed Action Buttons */}
      <View style={styles.actionsBackground}>
        <Animated.View style={actionAnimatedStyle}>
          <PressableScale
            haptic="selection"
            activeScale={0.88}
            onPress={handleFavoriteAction}
            accessibilityLabel="Favorite"
          >
            <LiquidGlass
              borderRadius={22}
              intensity={60}
              specularColor={item.isFavorited ? Colors.copper : 'rgba(255, 255, 255, 0.35)'}
              glowColor={item.isFavorited ? Colors.copperSoft : undefined}
              style={styles.actionGlass}
              contentStyle={styles.actionContent}
            >
              <SymbolView
                name={item.isFavorited ? 'star.slash.fill' : 'star.fill'}
                tintColor={Colors.copper}
                size={20}
              />
            </LiquidGlass>
          </PressableScale>
        </Animated.View>
      </View>

      {/* Swipeable Foreground Card */}
      <GestureDetector gesture={panGesture}>
        <Animated.View style={animatedCardStyle}>
          <PressableScale haptic="light" activeScale={0.98} onPress={onPress}>
            <LiquidGlass
              intensity={80}
              borderRadius={20}
              style={styles.card}
              contentStyle={styles.cardContent}
            >
              <View style={styles.topRow}>
                <View style={styles.entitiesRow}>
                  <Text style={[styles.entityText, { color: Colors.copper }]}>
                    {item.entityA || 'Option A'}
                  </Text>
                  <Text style={styles.vsText}>VS</Text>
                  <Text style={[styles.entityText, { color: Colors.cyan }]}>
                    {item.entityB || 'Option B'}
                  </Text>
                </View>

                <View style={styles.badgesRight}>
                  {item.isFavorited ? (
                    <SymbolView name="star.fill" tintColor={Colors.copper} size={14} />
                  ) : null}

                  <View
                    style={[
                      styles.statusBadge,
                      isRunning && styles.statusRunning,
                      isFailed && styles.statusFailed,
                    ]}
                  >
                    <Text
                      style={[
                        styles.statusText,
                        isRunning && styles.statusTextRunning,
                        isFailed && styles.statusTextFailed,
                      ]}
                    >
                      {isRunning ? 'RUNNING' : isFailed ? 'FAILED' : 'SYNTHESIZED'}
                    </Text>
                  </View>
                </View>
              </View>

              {item.query ? (
                <Text style={styles.summaryText} numberOfLines={2}>
                  {item.summary || item.query}
                </Text>
              ) : null}

              <View style={styles.bottomRow}>
                <View style={styles.sourceRow}>
                  <SymbolView name="checkmark.seal.fill" tintColor={Colors.cyan} size={12} />
                  <Text style={styles.sourceCountText}>
                    {item.sourceCount || 16} Verified Sources
                  </Text>
                </View>

                <Text style={styles.arrowText}>View Brief →</Text>
              </View>
            </LiquidGlass>
          </PressableScale>
        </Animated.View>
      </GestureDetector>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 12,
    position: 'relative',
  },
  actionsBackground: {
    ...StyleSheet.absoluteFill,
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    paddingRight: 18,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 155, 115, 0.12)',
  },
  actionGlass: {
    width: 44,
    height: 44,
    borderRadius: 22,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.18)',
  },
  actionContent: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  card: {
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.12)',
  },
  cardContent: {
    padding: 18,
  },
  topRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  entitiesRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    flex: 1,
    marginRight: 8,
  },
  badgesRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
  },
  entityText: {
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: -0.2,
  },
  vsText: {
    color: 'rgba(255, 255, 255, 0.35)',
    fontSize: 10,
    fontWeight: '800',
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.15)',
  },
  statusRunning: {
    borderColor: Colors.warning,
    backgroundColor: 'rgba(255, 149, 0, 0.15)',
  },
  statusFailed: {
    borderColor: Colors.error,
    backgroundColor: 'rgba(255, 59, 48, 0.15)',
  },
  statusText: {
    color: Colors.ivory,
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 0.8,
  },
  statusTextRunning: {
    color: Colors.warning,
  },
  statusTextFailed: {
    color: Colors.error,
  },
  summaryText: {
    color: 'rgba(211, 217, 231, 0.80)',
    fontSize: 13,
    lineHeight: 18,
    marginBottom: 12,
  },
  bottomRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.06)',
  },
  sourceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  sourceCountText: {
    color: 'rgba(211, 217, 231, 0.60)',
    fontSize: 11,
    fontWeight: '600',
  },
  arrowText: {
    color: Colors.ivory,
    fontSize: 12,
    fontWeight: '700',
  },
});
