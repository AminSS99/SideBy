import React from 'react';
import { StyleSheet, View, Text } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  useReducedMotion,
} from 'react-native-reanimated';
import { Colors } from '../../theme/colors';
import { Typography } from '../../theme/typography';
import { SpringConfigs } from '../../theme/motion';
import { LiquidGlass } from '../common/LiquidGlass';
import { SymbolView } from 'expo-symbols';

export interface InteractiveVerdictCardProps {
  entityA: string;
  entityB: string;
  verdict?: {
    winner: 'A' | 'B' | 'TIE';
    title: string;
    summary: string;
    scoreA: number;
    scoreB: number;
    consensuses: string[];
    contradictions: string[];
  };
}

export function InteractiveVerdictCard({
  entityA,
  entityB,
  verdict,
}: InteractiveVerdictCardProps) {
  const reducedMotion = useReducedMotion();

  const totalScore = (verdict?.scoreA ?? 0) + (verdict?.scoreB ?? 0);
  const pctA = totalScore > 0 ? Math.round(((verdict?.scoreA ?? 0) / totalScore) * 100) : 50;

  const animPctA = useSharedValue(0);

  React.useEffect(() => {
    if (!reducedMotion) {
      animPctA.value = withSpring(pctA, SpringConfigs.fluid);
    } else {
      animPctA.value = pctA;
    }
  }, [pctA, reducedMotion]);

  const animatedBarStyleA = useAnimatedStyle(() => {
    'worklet';
    return {
      width: `${animPctA.value}%`,
    };
  });

  const animatedBarStyleB = useAnimatedStyle(() => {
    'worklet';
    return {
      width: `${100 - animPctA.value}%`,
    };
  });

  if (!verdict) {
    return null;
  }

  const winnerName =
    verdict.winner === 'A'
      ? entityA
      : verdict.winner === 'B'
      ? entityB
      : 'Equal Tradeoff';

  const winnerColor =
    verdict.winner === 'A'
      ? Colors.copper
      : verdict.winner === 'B'
      ? Colors.cyan
      : Colors.ivory;

  return (
    <View style={styles.wrapper}>
      {/* Ambient Winner Radiance Glow Aura */}
      <View
        style={[
          styles.glowAura,
          {
            backgroundColor: winnerColor,
            shadowColor: winnerColor,
          },
        ]}
        pointerEvents="none"
      />

      <LiquidGlass
        intensity={88}
        glowColor={
          verdict.winner === 'A'
            ? Colors.copperSoft
            : verdict.winner === 'B'
            ? Colors.cyanSoft
            : undefined
        }
        specularColor={winnerColor}
        borderRadius={26}
        style={styles.card}
        contentStyle={styles.cardContent}
      >
        {/* Celebratory Trophy Winner Badge */}
        <View style={[styles.winnerBadge, { borderColor: winnerColor }]}>
          <SymbolView name="trophy.fill" tintColor={winnerColor} size={13} />
          <Text style={[styles.winnerLabel, { color: winnerColor }]}>
            DECISION WINNER: {winnerName.toUpperCase()}
          </Text>
        </View>

        {/* Editorial Headline */}
        <Text style={styles.verdictTitle}>{verdict.title}</Text>
        <Text style={styles.summaryText}>{verdict.summary}</Text>

        {/* Animated Dual-Color Score Comparison Section */}
        <View style={styles.scoreSection}>
          <View style={styles.scoreHeader}>
            <Text style={[styles.scoreEntityText, { color: Colors.copper }]}>
              {entityA} ({verdict.scoreA})
            </Text>
            <Text style={[styles.scoreEntityText, { color: Colors.cyan }]}>
              {entityB} ({verdict.scoreB})
            </Text>
          </View>

          <View style={styles.barTrack}>
            <Animated.View style={[styles.barA, animatedBarStyleA]} />
            <Animated.View style={[styles.barB, animatedBarStyleB]} />
          </View>
        </View>

      {/* Key Consensus Highlights */}
      {verdict.consensuses && verdict.consensuses.length > 0 && (
        <View style={styles.listSection}>
          <Text style={styles.sectionHeading}>KEY CONSENSUS</Text>
          {verdict.consensuses.map((item, idx) => (
            <View key={idx} style={styles.bulletRow}>
              <Text style={styles.bulletSymbol}>•</Text>
              <Text style={styles.bulletText}>{item}</Text>
            </View>
          ))}
        </View>
      )}

      {/* Key Contradictions */}
      {verdict.contradictions && verdict.contradictions.length > 0 && (
        <View style={styles.listSection}>
          <Text style={styles.sectionHeading}>KEY CONTRADICTIONS</Text>
          {verdict.contradictions.map((item, idx) => (
            <View key={idx} style={styles.bulletRow}>
              <Text style={[styles.bulletSymbol, { color: Colors.warning }]}>⚡</Text>
              <Text style={styles.bulletText}>{item}</Text>
            </View>
          ))}
        </View>
      )}
    </LiquidGlass>
  </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    position: 'relative',
    marginBottom: 20,
  },
  glowAura: {
    ...StyleSheet.absoluteFill,
    borderRadius: 28,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
  },
  card: {
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.14)',
  },
  cardContent: {
    padding: 22,
  },
  winnerBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    alignSelf: 'flex-start',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    borderWidth: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    marginBottom: 14,
  },
  winnerLabel: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.8,
  },
  verdictTitle: {
    ...Typography.h2,
    color: Colors.ivory,
    marginBottom: 10,
    fontSize: 22,
    lineHeight: 28,
  },
  summaryText: {
    ...Typography.bodySm,
    color: 'rgba(211, 217, 231, 0.80)',
    marginBottom: 20,
    lineHeight: 20,
  },
  scoreSection: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 16,
    padding: 14,
    marginBottom: 18,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.08)',
  },
  scoreHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  scoreEntityText: {
    fontSize: 13,
    fontWeight: '700',
  },
  barTrack: {
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.background,
    flexDirection: 'row',
    overflow: 'hidden',
  },
  barA: {
    height: '100%',
    backgroundColor: Colors.copper,
  },
  barB: {
    height: '100%',
    backgroundColor: Colors.cyan,
  },
  listSection: {
    marginTop: 12,
  },
  sectionHeading: {
    color: Colors.muted,
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.0,
    marginBottom: 8,
  },
  bulletRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
    marginBottom: 6,
  },
  bulletSymbol: {
    color: Colors.copper,
    fontSize: 14,
    lineHeight: 18,
  },
  bulletText: {
    color: Colors.ivory,
    fontSize: 13,
    lineHeight: 18,
    flex: 1,
  },
});
