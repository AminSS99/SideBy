import React from 'react';
import { StyleSheet, View, Text } from 'react-native';
import * as WebBrowser from 'expo-web-browser';
import { Colors } from '../../theme/colors';
import { ComparisonSource } from '../../types/schemas';
import { LiquidGlass } from '../common/LiquidGlass';
import { PressableScale } from '../common/PressableScale';
import { SymbolView } from 'expo-symbols';

export interface SourceCardProps {
  source: ComparisonSource;
}

export function SourceCard({ source }: SourceCardProps) {
  const handleOpenLink = async () => {
    try {
      await WebBrowser.openBrowserAsync(source.url);
    } catch {
      // Fallback
    }
  };

  const reliabilityPct = Math.round((source.confidence || 0.85) * 100);
  const domain = (() => {
    try {
      return new URL(source.url).hostname.replace(/^www\./, '');
    } catch {
      return 'Source Citation';
    }
  })();

  return (
    <PressableScale haptic="light" activeScale={0.97} onPress={handleOpenLink}>
      <LiquidGlass
        intensity={80}
        borderRadius={18}
        specularColor="rgba(255, 255, 255, 0.22)"
        style={styles.card}
        contentStyle={styles.cardContent}
      >
        <View style={styles.header}>
          <View style={styles.domainRow}>
            <SymbolView name="globe" tintColor={Colors.copper} size={13} />
            <Text style={styles.domainText} numberOfLines={1}>
              {domain}
            </Text>
          </View>
          <View style={styles.reliabilityBadge}>
            <Text style={styles.reliabilityText}>{reliabilityPct}% CONFIDENCE</Text>
          </View>
        </View>

        <Text style={styles.titleText} numberOfLines={2}>
          {source.title}
        </Text>

        {source.summary ? (
          <Text style={styles.snippetText} numberOfLines={3}>
            {source.summary}
          </Text>
        ) : null}

        <View style={styles.footer}>
          <Text style={styles.reliabilityLabel}>
            {source.reliability || 'Official Documentation'}
          </Text>
          <View style={styles.actionRow}>
            <Text style={styles.linkAction}>Open in Safari</Text>
            <SymbolView name="arrow.up.right" tintColor={Colors.cyan} size={11} />
          </View>
        </View>
      </LiquidGlass>
    </PressableScale>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 18,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.12)',
  },
  cardContent: {
    padding: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  domainRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    flex: 1,
    marginRight: 8,
  },
  domainText: {
    color: Colors.copper,
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.6,
    textTransform: 'uppercase',
  },
  reliabilityBadge: {
    backgroundColor: 'rgba(110, 217, 230, 0.12)',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'rgba(110, 217, 230, 0.30)',
  },
  reliabilityText: {
    color: Colors.cyan,
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  titleText: {
    color: Colors.ivory,
    fontSize: 15,
    fontWeight: '700',
    lineHeight: 20,
    letterSpacing: -0.2,
    marginBottom: 6,
  },
  snippetText: {
    color: 'rgba(211, 217, 231, 0.70)',
    fontSize: 13,
    lineHeight: 18,
    marginBottom: 12,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.06)',
    paddingTop: 8,
  },
  reliabilityLabel: {
    color: 'rgba(211, 217, 231, 0.50)',
    fontSize: 11,
    fontWeight: '600',
  },
  actionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  linkAction: {
    color: Colors.cyan,
    fontSize: 12,
    fontWeight: '700',
  },
});
