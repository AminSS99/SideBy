import React, { useState } from 'react';
import { StyleSheet, View, Text, LayoutChangeEvent } from 'react-native';
import {
  Gesture,
  GestureDetector,
} from 'react-native-gesture-handler';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  runOnJS,
} from 'react-native-reanimated';
import { SymbolView } from 'expo-symbols';
import { Colors } from '../../theme/colors';
import { SpringConfigs } from '../../theme/motion';
import { triggerHaptic } from '../../theme/haptics';
import { LiquidGlass } from '../common/LiquidGlass';

export interface ContenderComparisonScrubberProps {
  entityA: string;
  entityB: string;
  summaryA?: string;
  summaryB?: string;
}

export function ContenderComparisonScrubber({
  entityA,
  entityB,
  summaryA = 'Key advantages in ecosystem maturity, community packages, and developer velocity.',
  summaryB = 'Key advantages in raw execution speed, memory footprint, and low-overhead runtime.',
}: ContenderComparisonScrubberProps) {
  const [cardWidth, setCardWidth] = useState(320);

  // Position from 0 to cardWidth, default at center
  const dividerX = useSharedValue(160);
  const isDragging = useSharedValue(false);
  const lastTickX = useSharedValue(160);

  const handleLayout = (e: LayoutChangeEvent) => {
    const w = e.nativeEvent.layout.width;
    if (w > 0) {
      setCardWidth(w);
      dividerX.value = w * 0.5;
      lastTickX.value = w * 0.5;
    }
  };

  const notifyTick = () => {
    triggerHaptic.scrubberTick();
  };

  const panGesture = Gesture.Pan()
    .onStart(() => {
      isDragging.value = true;
      runOnJS(notifyTick)();
    })
    .onUpdate((event) => {
      const minX = 40;
      const maxX = cardWidth - 40;
      const clamped = Math.max(minX, Math.min(maxX, event.x));
      dividerX.value = clamped;

      // Trigger haptic every 24px of travel
      if (Math.abs(clamped - lastTickX.value) >= 24) {
        lastTickX.value = clamped;
        runOnJS(notifyTick)();
      }
    })
    .onEnd(() => {
      isDragging.value = false;
    });

  const dividerAnimatedStyle = useAnimatedStyle(() => {
    'worklet';
    return {
      transform: [{ translateX: dividerX.value - 20 }],
    };
  });

  return (
    <View style={styles.outerContainer} onLayout={handleLayout}>
      <Text style={styles.sectionHeading}>INTERACTIVE HEAD-TO-HEAD SCRUBBER</Text>

      <GestureDetector gesture={panGesture}>
        <View style={styles.scrubberCanvas}>
          <LiquidGlass
            intensity={80}
            borderRadius={22}
            style={styles.glassBase}
            contentStyle={styles.canvasContent}
          >
            {/* Left Wing: Contender A Focus */}
            <View style={[styles.wing, styles.wingLeft]}>
              <View style={[styles.pillA]}>
                <Text style={styles.pillTextA}>{entityA.toUpperCase()}</Text>
              </View>
              <Text style={styles.wingSummary} numberOfLines={4}>
                {summaryA}
              </Text>
            </View>

            {/* Right Wing: Contender B Focus */}
            <View style={[styles.wing, styles.wingRight]}>
              <View style={[styles.pillB]}>
                <Text style={styles.pillTextB}>{entityB.toUpperCase()}</Text>
              </View>
              <Text style={styles.wingSummary} numberOfLines={4}>
                {summaryB}
              </Text>
            </View>
          </LiquidGlass>

          {/* Draggable Liquid Glass Divider Thumb */}
          <Animated.View style={[styles.thumbHandle, dividerAnimatedStyle]}>
            <View style={styles.thumbLine} />
            <LiquidGlass
              borderRadius={17}
              intensity={85}
              specularColor="rgba(255, 255, 255, 0.45)"
              style={styles.thumbKnobGlass}
              contentStyle={styles.thumbKnobContent}
            >
              <SymbolView
                name="arrow.left.and.right"
                tintColor={Colors.ivory}
                size={14}
              />
            </LiquidGlass>
            <View style={styles.thumbLine} />
          </Animated.View>
        </View>
      </GestureDetector>
    </View>
  );
}

const styles = StyleSheet.create({
  outerContainer: {
    marginBottom: 20,
  },
  sectionHeading: {
    color: 'rgba(211, 217, 231, 0.60)',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.2,
    marginBottom: 10,
  },
  scrubberCanvas: {
    position: 'relative',
    height: 160,
  },
  glassBase: {
    flex: 1,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.12)',
  },
  canvasContent: {
    flex: 1,
    flexDirection: 'row',
  },
  wing: {
    flex: 1,
    padding: 16,
    justifyContent: 'space-between',
  },
  wingLeft: {
    borderRightWidth: 1,
    borderRightColor: 'rgba(255, 255, 255, 0.08)',
  },
  wingRight: {
    alignItems: 'flex-end',
  },
  pillA: {
    backgroundColor: Colors.copperSoft,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  pillTextA: {
    color: Colors.copper,
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.8,
  },
  pillB: {
    backgroundColor: Colors.cyanSoft,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    alignSelf: 'flex-end',
  },
  pillTextB: {
    color: Colors.cyan,
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.8,
  },
  wingSummary: {
    color: 'rgba(211, 217, 231, 0.80)',
    fontSize: 12,
    lineHeight: 17,
  },
  thumbHandle: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    width: 40,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 20,
  },
  thumbLine: {
    flex: 1,
    width: 2,
    backgroundColor: 'rgba(255, 255, 255, 0.45)',
  },
  thumbKnobGlass: {
    width: 34,
    height: 34,
    borderRadius: 17,
    borderWidth: 1.5,
    borderColor: 'rgba(255, 255, 255, 0.35)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.6,
    shadowRadius: 8,
    marginVertical: 4,
  },
  thumbKnobContent: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
