import React, { useEffect } from 'react';
import { StyleSheet, View, Text } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  withSequence,
  withSpring,
  Easing,
  useReducedMotion,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors } from '../../theme/colors';
import { RESEARCH_STAGES, StageKey } from '../../types/api';
import { getStageFromProgress } from '../../utils/progress';
import { LiquidGlass } from '../common/LiquidGlass';
import { SpringConfigs } from '../../theme/motion';
import { triggerHaptic } from '../../theme/haptics';

export interface ResearchOrbPipelineProps {
  progress: number;
  currentStageKey?: StageKey;
}

export function ResearchOrbPipeline({ progress }: ResearchOrbPipelineProps) {
  const currentStage = getStageFromProgress(progress);
  const [elapsed, setElapsed] = React.useState(0);
  const reducedMotion = useReducedMotion();

  // Ambient breathing pulse for the core research orb
  const pulseScale = useSharedValue(1);
  const orbRotation = useSharedValue(0);
  const fillProgress = useSharedValue(progress);
  const prevStageRef = React.useRef(currentStage.key);

  useEffect(() => {
    const timer = setInterval(() => {
      setElapsed((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (!reducedMotion) {
      pulseScale.value = withRepeat(
        withSequence(
          withTiming(1.14, { duration: 1500, easing: Easing.inOut(Easing.ease) }),
          withTiming(1.0, { duration: 1500, easing: Easing.inOut(Easing.ease) })
        ),
        -1,
        true
      );
      orbRotation.value = withRepeat(
        withTiming(360, { duration: 8000, easing: Easing.linear }),
        -1,
        false
      );
    }
  }, [reducedMotion]);

  useEffect(() => {
    if (!reducedMotion) {
      fillProgress.value = withSpring(
        Math.max(5, Math.min(100, progress)),
        SpringConfigs.fluid
      );
    } else {
      fillProgress.value = Math.max(5, Math.min(100, progress));
    }
  }, [progress, reducedMotion]);

  // Haptic pulse when progressing to a new milestone
  useEffect(() => {
    if (currentStage.key !== prevStageRef.current) {
      prevStageRef.current = currentStage.key;
      triggerHaptic.stageMilestone();
    }
  }, [currentStage.key]);

  const animatedOrbStyle = useAnimatedStyle(() => {
    'worklet';
    return {
      transform: [
        { scale: pulseScale.value },
        { rotate: `${orbRotation.value}deg` },
      ],
    };
  });

  const animatedFillStyle = useAnimatedStyle(() => {
    'worklet';
    return {
      width: `${fillProgress.value}%`,
    };
  });

  return (
    <LiquidGlass
      intensity={85}
      glowColor="rgba(110, 217, 230, 0.08)"
      specularColor={Colors.cyan}
      borderRadius={24}
      style={styles.container}
      contentStyle={styles.cardContent}
    >
      {/* Header Row */}
      <View style={styles.headerRow}>
        <View style={styles.titleGroup}>
          <View style={styles.livePulse} />
          <Text style={styles.title}>Autonomous Engine Active</Text>
        </View>
        <View style={styles.metricsGroup}>
          <Text style={styles.elapsedText}>{elapsed}s</Text>
          <Text style={styles.percentageText}>{Math.round(progress)}%</Text>
        </View>
      </View>

      {/* Kinetic Planetary Research Orb */}
      <View style={styles.orbContainer}>
        <Animated.View style={[styles.orbAura, animatedOrbStyle]}>
          <LinearGradient
            colors={[
              'rgba(255, 155, 115, 0.45)',
              'rgba(110, 217, 230, 0.35)',
              'rgba(168, 140, 255, 0.25)',
              'transparent',
            ]}
            locations={[0, 0.4, 0.7, 1]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.orbGradient}
          />
        </Animated.View>
        <View style={styles.orbCenterCore}>
          <Text style={styles.orbCoreNumber}>{Math.round(progress)}%</Text>
          <Text style={styles.orbCoreElapsed}>{elapsed}s elapsed</Text>
          <Text style={styles.orbCoreLabel}>SYNTHESIZING</Text>
        </View>
      </View>

      {/* Progress Track */}
      <View style={styles.track}>
        <Animated.View style={[styles.fill, animatedFillStyle]} />
      </View>

      <Text style={styles.currentStageLabel}>{currentStage.label}</Text>
      <Text style={styles.currentStageDesc}>{currentStage.description}</Text>

      {/* Stage Steps List */}
      <View style={styles.stagesList}>
        {RESEARCH_STAGES.map((stage) => {
          const isDone = progress > stage.threshold + 10 || progress >= 98;
          const isCurrent = currentStage.key === stage.key && !isDone;

          return (
            <View key={stage.key} style={styles.stageItem}>
              <View
                style={[
                  styles.stageDot,
                  isDone && styles.stageDotDone,
                  isCurrent && styles.stageDotCurrent,
                ]}
              >
                {isDone ? (
                  <Text style={styles.checkIcon}>✓</Text>
                ) : isCurrent ? (
                  <View style={styles.activeInnerDot} />
                ) : null}
              </View>
              <Text
                style={[
                  styles.stageText,
                  isDone && styles.stageTextDone,
                  isCurrent && styles.stageTextCurrent,
                ]}
              >
                {stage.label}
              </Text>
            </View>
          );
        })}
      </View>
    </LiquidGlass>
  );
}

const styles = StyleSheet.create({
  container: {
    marginVertical: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.12)',
  },
  cardContent: {
    padding: 20,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  titleGroup: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  livePulse: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.cyan,
    shadowColor: Colors.cyan,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.9,
    shadowRadius: 6,
  },
  title: {
    color: Colors.ivory,
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: -0.2,
  },
  metricsGroup: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  elapsedText: {
    color: Colors.muted,
    fontSize: 13,
    fontWeight: '600',
  },
  percentageText: {
    color: Colors.copper,
    fontSize: 16,
    fontWeight: '800',
  },
  orbContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 18,
    height: 140,
  },
  orbAura: {
    width: 130,
    height: 130,
    borderRadius: 65,
    overflow: 'hidden',
  },
  orbGradient: {
    flex: 1,
    borderRadius: 65,
  },
  orbCenterCore: {
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
    width: 84,
    height: 84,
    borderRadius: 42,
    backgroundColor: '#0A0C13',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.20)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.6,
    shadowRadius: 10,
  },
  orbCoreNumber: {
    color: Colors.ivory,
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.5,
  },
  orbCoreElapsed: {
    color: Colors.muted,
    fontSize: 9,
    fontWeight: '600',
    marginTop: 2,
  },
  orbCoreLabel: {
    color: Colors.cyan,
    fontSize: 8,
    fontWeight: '800',
    letterSpacing: 1.2,
    marginTop: 2,
  },
  track: {
    height: 6,
    backgroundColor: Colors.raisedTitanium,
    borderRadius: 3,
    overflow: 'hidden',
    marginBottom: 16,
  },
  fill: {
    height: '100%',
    backgroundColor: Colors.copper,
    borderRadius: 3,
  },
  currentStageLabel: {
    color: Colors.ivory,
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 4,
  },
  currentStageDesc: {
    color: 'rgba(211, 217, 231, 0.65)',
    fontSize: 13,
    lineHeight: 18,
    marginBottom: 16,
  },
  stagesList: {
    gap: 8,
  },
  stageItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  stageDot: {
    width: 18,
    height: 18,
    borderRadius: 9,
    borderWidth: 1.5,
    borderColor: Colors.borderLight,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.background,
  },
  stageDotDone: {
    backgroundColor: Colors.copper,
    borderColor: Colors.copper,
  },
  stageDotCurrent: {
    borderColor: Colors.ivory,
    backgroundColor: Colors.raisedTitanium,
  },
  activeInnerDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: Colors.ivory,
  },
  checkIcon: {
    color: Colors.background,
    fontSize: 11,
    fontWeight: '900',
  },
  stageText: {
    color: Colors.muted,
    fontSize: 13,
  },
  stageTextDone: {
    color: Colors.ivory,
  },
  stageTextCurrent: {
    color: Colors.ivory,
    fontWeight: '600',
  },
});
