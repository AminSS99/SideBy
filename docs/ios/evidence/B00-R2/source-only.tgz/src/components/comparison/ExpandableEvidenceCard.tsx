import React, { useState } from 'react';
import { StyleSheet, View, Text } from 'react-native';
import Animated, { useAnimatedStyle, withTiming } from 'react-native-reanimated';
import { SymbolView } from 'expo-symbols';
import { Colors } from '../../theme/colors';
import { Typography } from '../../theme/typography';
import { Category } from '../../types/schemas';
import { LiquidGlass } from '../common/LiquidGlass';
import { PressableScale } from '../common/PressableScale';

interface ExpandableEvidenceCardProps {
  category: Category;
  entityAName: string;
  entityBName: string;
  defaultExpanded?: boolean;
}

export function ExpandableEvidenceCard({
  category,
  entityAName,
  entityBName,
  defaultExpanded = false,
}: ExpandableEvidenceCardProps) {
  const [isExpanded, setIsExpanded] = useState(defaultExpanded);

  const toggleExpand = () => {
    setIsExpanded((prev) => !prev);
  };

  const animatedChevronStyle = useAnimatedStyle(() => {
    return {
      transform: [
        {
          rotate: withTiming(isExpanded ? '180deg' : '0deg', { duration: 250 }),
        },
      ],
    };
  });

  const winner = category.winner;
  const winnerColor =
    winner === 'a' ? Colors.copper : winner === 'b' ? Colors.cyan : Colors.muted;

  const winnerLabel =
    winner === 'a'
      ? `WINNER: ${entityAName.toUpperCase()}`
      : winner === 'b'
      ? `WINNER: ${entityBName.toUpperCase()}`
      : winner === 'tie'
      ? 'RESULT: TIE'
      : 'EVALUATION PENDING';

  return (
    <LiquidGlass
      intensity={70}
      borderRadius={18}
      specularColor="rgba(255, 255, 255, 0.15)"
      style={styles.card}
      contentStyle={styles.cardContent}
    >
      {/* Header / Accordion trigger */}
      <PressableScale
        haptic="light"
        activeScale={0.98}
        onPress={toggleExpand}
        style={styles.headerPressable}
        accessibilityRole="button"
        accessibilityLabel={`Toggle ${category.name} evidence`}
      >
        <View style={styles.headerLeft}>
          <Text style={styles.categoryTitle}>{category.name}</Text>
          <View style={[styles.winnerBadge, { borderColor: winnerColor }]}>
            <Text style={[styles.winnerText, { color: winnerColor }]}>
              {winnerLabel}
            </Text>
          </View>
        </View>

        <Animated.View style={animatedChevronStyle}>
          <SymbolView
            name="chevron.down"
            tintColor="rgba(211, 217, 231, 0.65)"
            size={16}
          />
        </Animated.View>
      </PressableScale>

      {/* Expandable Facts Body */}
      {isExpanded && (
        <View style={styles.factsContainer}>
          {category.facts.map((fact, idx) => {
            const hasConfidence = typeof fact.confidence === 'number';
            const confidenceText = hasConfidence
              ? `Confidence: ${Math.round(fact.confidence! * 100)}%`
              : 'Confidence: Unknown';
            const freshnessSuffix = fact.freshness ? ` • ${fact.freshness}` : '';

            return (
              <View key={idx} style={styles.factItem}>
                <Text style={styles.factLabel}>{fact.label}</Text>

                <View
                  style={[
                    styles.factBox,
                    fact.entity === 'a' ? styles.factBoxA : styles.factBoxB,
                  ]}
                >
                  <Text
                    style={[
                      styles.entityNameBadge,
                      { color: fact.entity === 'a' ? Colors.copper : Colors.cyan },
                    ]}
                  >
                    {fact.entity === 'a' ? entityAName : entityBName}
                  </Text>
                  <Text style={styles.factValueText} selectable>
                    {fact.value}
                  </Text>
                </View>

                <Text style={styles.confidenceText}>
                  {confidenceText}
                  {freshnessSuffix}
                </Text>
              </View>
            );
          })}
        </View>
      )}
    </LiquidGlass>
  );
}

const styles = StyleSheet.create({
  card: {
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.12)',
  },
  cardContent: {
    padding: 16,
  },
  headerPressable: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flexWrap: 'wrap',
    flex: 1,
  },
  categoryTitle: {
    ...Typography.h3,
    color: Colors.ivory,
  },
  winnerBadge: {
    borderWidth: 1,
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 6,
    backgroundColor: 'rgba(255, 255, 255, 0.04)',
  },
  winnerText: {
    ...Typography.caption,
    fontSize: 10,
    fontWeight: '700',
  },
  factsContainer: {
    marginTop: 14,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.08)',
    paddingTop: 12,
    gap: 14,
  },
  factItem: {
    gap: 6,
  },
  factLabel: {
    ...Typography.caption,
    color: Colors.ivoryMuted,
    fontWeight: '600',
  },
  factBox: {
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    gap: 4,
  },
  factBoxA: {
    backgroundColor: 'rgba(255, 155, 115, 0.06)',
    borderColor: 'rgba(255, 155, 115, 0.25)',
  },
  factBoxB: {
    backgroundColor: 'rgba(110, 217, 230, 0.06)',
    borderColor: 'rgba(110, 217, 230, 0.25)',
  },
  entityNameBadge: {
    ...Typography.caption,
    fontWeight: '700',
    fontSize: 11,
    textTransform: 'uppercase',
  },
  factValueText: {
    ...Typography.bodySm,
    color: Colors.ivory,
    lineHeight: 20,
  },
  confidenceText: {
    ...Typography.caption,
    fontSize: 11,
    color: Colors.ivoryMuted,
    marginTop: 2,
  },
});
