import React from 'react';
import { StyleSheet, View, Text } from 'react-native';
import { Colors } from '../../theme/colors';
import { ComparisonDimension } from '../../types/schemas';

interface DimensionScoreBarProps {
  dimension: ComparisonDimension;
  entityAName: string;
  entityBName: string;
}

export function DimensionScoreBar({
  dimension,
  entityAName,
  entityBName,
}: DimensionScoreBarProps) {
  const maxScore = dimension.fullMark || 10;
  const scoreA = dimension.a;
  const scoreB = dimension.b;

  const pctA = Math.min(100, Math.max(8, (scoreA / maxScore) * 100));
  const pctB = Math.min(100, Math.max(8, (scoreB / maxScore) * 100));

  const winner = scoreA > scoreB ? 'A' : scoreB > scoreA ? 'B' : 'Tie';
  const diff = Math.abs(scoreA - scoreB);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.subject}>{dimension.subject}</Text>
        {winner !== 'Tie' ? (
          <View
            style={[
              styles.winnerBadge,
              { backgroundColor: winner === 'A' ? Colors.copperSoft : Colors.cyanSoft },
            ]}
          >
            <Text
              style={[
                styles.winnerText,
                { color: winner === 'A' ? Colors.copper : Colors.cyan },
              ]}
            >
              +{diff.toFixed(diff % 1 === 0 ? 0 : 1)} {winner === 'A' ? entityAName : entityBName}
            </Text>
          </View>
        ) : (
          <View style={[styles.winnerBadge, { backgroundColor: 'rgba(255, 255, 255, 0.08)' }]}>
            <Text style={[styles.winnerText, { color: Colors.muted }]}>Tied</Text>
          </View>
        )}
      </View>

      {/* Dual Bar Comparison */}
      <View style={styles.barStack}>
        {/* Option A Bar */}
        <View style={styles.barRow}>
          <Text style={[styles.barEntity, { color: Colors.copper }]} numberOfLines={1}>
            {entityAName}
          </Text>
          <View style={styles.track}>
            <View
              style={[
                styles.fill,
                {
                  width: `${pctA}%`,
                  backgroundColor: Colors.copper,
                  shadowColor: Colors.copper,
                },
              ]}
            />
          </View>
          <Text style={[styles.scoreText, { color: Colors.copper }]}>
            {scoreA.toFixed(scoreA % 1 === 0 ? 0 : 1)}
          </Text>
        </View>

        {/* Option B Bar */}
        <View style={styles.barRow}>
          <Text style={[styles.barEntity, { color: Colors.cyan }]} numberOfLines={1}>
            {entityBName}
          </Text>
          <View style={styles.track}>
            <View
              style={[
                styles.fill,
                {
                  width: `${pctB}%`,
                  backgroundColor: Colors.cyan,
                  shadowColor: Colors.cyan,
                },
              ]}
            />
          </View>
          <Text style={[styles.scoreText, { color: Colors.cyan }]}>
            {scoreB.toFixed(scoreB % 1 === 0 ? 0 : 1)}
          </Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.06)',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  subject: {
    color: Colors.ivory,
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: -0.2,
  },
  winnerBadge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
  },
  winnerText: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  barStack: {
    gap: 6,
  },
  barRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  barEntity: {
    width: 75,
    fontSize: 12,
    fontWeight: '700',
  },
  track: {
    flex: 1,
    height: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.07)',
    borderRadius: 4,
    overflow: 'hidden',
  },
  fill: {
    height: '100%',
    borderRadius: 4,
  },
  scoreText: {
    width: 28,
    textAlign: 'right',
    fontSize: 12,
    fontWeight: '800',
  },
});
