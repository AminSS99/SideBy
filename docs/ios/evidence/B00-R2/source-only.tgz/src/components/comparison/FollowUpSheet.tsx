import React, { useState } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  Pressable,
  ActivityIndicator,
} from 'react-native';
import { SymbolView } from 'expo-symbols';
import * as WebBrowser from 'expo-web-browser';
import { Colors } from '../../theme/colors';
import { triggerHaptic } from '../../theme/haptics';
import { FollowUpResponse } from '../../types/schemas';
import { GlassSurface } from '../common/GlassSurface';

interface FollowUpSheetProps {
  onAsk: (question: string) => void;
  isLoading: boolean;
  history: Array<{ question: string; response: FollowUpResponse }>;
  isOffline: boolean;
}

const QUICK_PROMPTS = [
  'Which is easier to scale in production?',
  'What are the main pricing differences?',
  'How do migration costs compare?',
  'Which has stronger community support?',
];

export function FollowUpSheet({
  onAsk,
  isLoading,
  history,
  isOffline,
}: FollowUpSheetProps) {
  const [question, setQuestion] = useState('');

  const handleSend = (textToSend?: string) => {
    const q = (textToSend || question).trim();
    if (!q || isLoading || isOffline) return;
    triggerHaptic.mediumImpact();
    onAsk(q);
    setQuestion('');
  };

  const handleOpenSource = async (url?: string | null) => {
    if (!url) return;
    triggerHaptic.selection();
    try {
      await WebBrowser.openBrowserAsync(url);
    } catch {
      // open browser error
    }
  };

  return (
    <GlassSurface style={styles.container}>
      <View style={styles.header}>
        <View style={styles.titleRow}>
          <SymbolView name="sparkles" tintColor={Colors.cyan} size={18} />
          <Text style={styles.title}>Evidence-Backed Follow-Up</Text>
        </View>
        <Text style={styles.subtitle}>
          Ask any specific question. SideBy retrieves facts directly from verified sources.
        </Text>
      </View>

      {/* History of Follow-Ups */}
      {history.map((item, idx) => (
        <View key={idx} style={styles.chatCard}>
          <View style={styles.userBubble}>
            <Text style={styles.userText}>{item.question}</Text>
          </View>

          <View style={styles.answerBubble}>
            <Text style={styles.answerText}>{item.response.answer}</Text>

            {item.response.evidence && item.response.evidence.length > 0 && (
              <View style={styles.evidenceContainer}>
                <Text style={styles.evidenceHeader}>CITED EVIDENCE</Text>
                {item.response.evidence.map((ev, eIdx) => (
                  <Pressable
                    key={eIdx}
                    style={styles.evidenceItem}
                    onPress={() => handleOpenSource(ev.sourceUrl)}
                  >
                    <View style={styles.evidenceDot} />
                    <View style={styles.evidenceContent}>
                      <Text style={styles.evidenceLabel}>{ev.label || 'Fact'}:</Text>
                      <Text style={styles.evidenceValue}>{ev.value}</Text>
                      {ev.sourceTitle && (
                        <Text style={styles.evidenceSource} numberOfLines={1}>
                          Source: {ev.sourceTitle} ↗
                        </Text>
                      )}
                    </View>
                  </Pressable>
                ))}
              </View>
            )}

            <View style={styles.confidenceRow}>
              <Text style={styles.confidenceText}>
                Confidence: {Math.round((item.response.confidence || 0.9) * 100)}%
              </Text>
            </View>
          </View>
        </View>
      ))}

      {/* Suggested Quick Prompts if no history yet */}
      {history.length === 0 && (
        <View style={styles.quickPrompts}>
          <Text style={styles.quickLabel}>SUGGESTED QUESTIONS</Text>
          <View style={styles.chipsRow}>
            {QUICK_PROMPTS.map((prompt, pIdx) => (
              <Pressable
                key={pIdx}
                style={styles.chip}
                onPress={() => {
                  triggerHaptic.lightImpact();
                  handleSend(prompt);
                }}
                disabled={isLoading || isOffline}
              >
                <Text style={styles.chipText}>{prompt}</Text>
              </Pressable>
            ))}
          </View>
        </View>
      )}

      {/* Input Bar */}
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder={
            isOffline
              ? 'Offline — Follow-ups disabled'
              : 'Ask a specific follow-up question...'
          }
          placeholderTextColor={Colors.muted}
          value={question}
          onChangeText={setQuestion}
          editable={!isLoading && !isOffline}
          onSubmitEditing={() => handleSend()}
          returnKeyType="send"
        />

        <Pressable
          style={[
            styles.sendButton,
            (!question.trim() || isLoading || isOffline) && styles.sendButtonDisabled,
          ]}
          onPress={() => handleSend()}
          disabled={!question.trim() || isLoading || isOffline}
        >
          {isLoading ? (
            <ActivityIndicator size="small" color={Colors.background} />
          ) : (
            <SymbolView name="arrow.up" tintColor={Colors.background} size={16} />
          )}
        </Pressable>
      </View>
    </GlassSurface>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: 22,
    padding: 18,
    marginBottom: 20,
  },
  header: {
    marginBottom: 16,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4,
  },
  title: {
    color: Colors.ivory,
    fontSize: 17,
    fontWeight: '700',
    letterSpacing: -0.3,
  },
  subtitle: {
    color: Colors.muted,
    fontSize: 13,
    lineHeight: 18,
  },
  chatCard: {
    marginBottom: 16,
    gap: 10,
  },
  userBubble: {
    alignSelf: 'flex-end',
    backgroundColor: 'rgba(255, 255, 255, 0.12)',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 16,
    borderBottomRightRadius: 4,
    maxWidth: '85%',
  },
  userText: {
    color: Colors.ivory,
    fontSize: 14,
    fontWeight: '600',
  },
  answerBubble: {
    backgroundColor: 'rgba(12, 16, 28, 0.70)',
    borderRadius: 16,
    borderBottomLeftRadius: 4,
    padding: 14,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.08)',
  },
  answerText: {
    color: Colors.ivory,
    fontSize: 14,
    lineHeight: 21,
  },
  evidenceContainer: {
    marginTop: 12,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.08)',
    gap: 8,
  },
  evidenceHeader: {
    color: Colors.cyan,
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.8,
  },
  evidenceItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.04)',
    padding: 8,
    borderRadius: 8,
  },
  evidenceDot: {
    width: 5,
    height: 5,
    borderRadius: 2.5,
    backgroundColor: Colors.cyan,
    marginTop: 6,
  },
  evidenceContent: {
    flex: 1,
  },
  evidenceLabel: {
    color: Colors.muted,
    fontSize: 11,
    fontWeight: '700',
  },
  evidenceValue: {
    color: Colors.ivory,
    fontSize: 13,
    lineHeight: 18,
  },
  evidenceSource: {
    color: Colors.cyan,
    fontSize: 11,
    marginTop: 3,
    fontWeight: '600',
  },
  confidenceRow: {
    marginTop: 8,
    alignItems: 'flex-end',
  },
  confidenceText: {
    color: Colors.muted,
    fontSize: 11,
    fontWeight: '600',
  },
  quickPrompts: {
    marginBottom: 14,
  },
  quickLabel: {
    color: Colors.muted,
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.8,
    marginBottom: 8,
  },
  chipsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  chip: {
    backgroundColor: 'rgba(255, 255, 255, 0.06)',
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.10)',
  },
  chipText: {
    color: Colors.ivory,
    fontSize: 12,
    fontWeight: '500',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.07)',
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.14)',
  },
  input: {
    flex: 1,
    color: Colors.ivory,
    fontSize: 14,
    paddingVertical: 8,
    paddingRight: 8,
  },
  sendButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: Colors.ivory,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sendButtonDisabled: {
    opacity: 0.4,
  },
});
