import React from 'react';
import { StyleSheet, View, Text } from 'react-native';
import { Colors } from '../../theme/colors';
import { RESEARCH_STAGES, StageKey } from '../../types/api';
import { getStageFromProgress } from '../../utils/progress';
import { GlassSurface } from '../common/GlassSurface';

interface ResearchStageProgressProps {
  progress: number;
  currentStageKey?: StageKey;
}

export function ResearchStageProgress({ progress }: ResearchStageProgressProps) {
  const currentStage = getStageFromProgress(progress);
  const [elapsed, setElapsed] = React.useState(0);

  React.useEffect(() => {
    const timer = setInterval(() => {
      setElapsed((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <GlassSurface style={styles.container}>
      <View style={styles.headerRow}>
        <View style={styles.titleWithLive}>
          <View style={styles.livePulse} />
          <Text style={styles.title}>Autonomous Research Engine</Text>
        </View>
        <View style={styles.headerRight}>
          <Text style={styles.elapsedText}>{elapsed}s</Text>
          <Text style={styles.percentageText}>{Math.round(progress)}%</Text>
        </View>
      </View>

      {/* Progress Track */}
      <View style={styles.track}>
        <View style={[styles.fill, { width: `${Math.max(5, Math.min(100, progress))}%` }]} />
      </View>

      <Text style={styles.currentStageLabel}>{currentStage.label}</Text>
      <Text style={styles.currentStageDesc}>{currentStage.description}</Text>

      {/* Stage Steps List */}
      <View style={styles.stagesList}>
        {RESEARCH_STAGES.map((stage, idx) => {
          const isDone = progress > stage.threshold + 10 || progress >= 98;
          const isCurrent = currentStage.key === stage.key && !isDone;

          return (
            <View key={stage.key} style={styles.stageItem}>
              <View
                style={[
                  styles.stageDot,
                  isDone && styles.stageDotDone,
                  isCurrent && styles.stageDotCurrent,
                ]}
              >
                {isDone ? (
                  <Text style={styles.checkIcon}>✓</Text>
                ) : isCurrent ? (
                  <View style={styles.activeInnerDot} />
                ) : null}
              </View>
              <Text
                style={[
                  styles.stageText,
                  isDone && styles.stageTextDone,
                  isCurrent && styles.stageTextCurrent,
                ]}
              >
                {stage.label}
              </Text>
            </View>
          );
        })}
      </View>
    </GlassSurface>
  );
}


const styles = StyleSheet.create({
  container: {
    borderRadius: 20,
    padding: 20,
    marginVertical: 16,
    boxShadow: '0 16px 34px rgba(0, 0, 0, 0.22)',
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  titleWithLive: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  livePulse: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.cyan,
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  elapsedText: {
    color: Colors.muted,
    fontSize: 13,
    fontWeight: '600',
  },
  title: {
    color: Colors.ivory,
    fontSize: 15,
    fontWeight: '700',
  },
  percentageText: {
    color: Colors.copper,
    fontSize: 15,
    fontWeight: '800',
  },
  track: {
    height: 6,
    backgroundColor: Colors.raisedTitanium,
    borderRadius: 3,
    overflow: 'hidden',
    marginBottom: 16,
  },
  fill: {
    height: '100%',
    backgroundColor: Colors.copper,
    borderRadius: 3,
  },
  currentStageLabel: {
    color: Colors.ivory,
    fontSize: 15,
    fontWeight: '600',
    marginBottom: 4,
  },
  currentStageDesc: {
    color: Colors.muted,
    fontSize: 13,
    marginBottom: 16,
  },
  stagesList: {
    gap: 8,
  },
  stageItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  stageDot: {
    width: 18,
    height: 18,
    borderRadius: 9,
    borderWidth: 1.5,
    borderColor: Colors.borderLight,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.background,
  },
  stageDotDone: {
    backgroundColor: Colors.copper,
    borderColor: Colors.copper,
  },
  stageDotCurrent: {
    borderColor: Colors.ivory,
    backgroundColor: Colors.raisedTitanium,
  },
  activeInnerDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: Colors.ivory,
  },
  checkIcon: {
    color: Colors.background,
    fontSize: 11,
    fontWeight: '900',
  },
  stageText: {
    color: Colors.muted,
    fontSize: 13,
  },
  stageTextDone: {
    color: Colors.ivory,
  },
  stageTextCurrent: {
    color: Colors.ivory,
    fontWeight: '600',
  },
});
