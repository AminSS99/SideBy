import React from 'react';
import { StyleSheet, View, Text } from 'react-native';
import { Colors } from '../../theme/colors';
import { Typography } from '../../theme/typography';
import { GlassSurface } from '../common/GlassSurface';

interface VerdictHeaderProps {
  entityA: string;
  entityB: string;
  verdict?: {
    winner: 'A' | 'B' | 'TIE';
    title: string;
    summary: string;
    scoreA: number;
    scoreB: number;
    consensuses: string[];
    contradictions: string[];
  };
}

export function VerdictHeader({ entityA, entityB, verdict }: VerdictHeaderProps) {
  if (!verdict) {
    return null;
  }

  const winnerName = verdict.winner === 'A' ? entityA : verdict.winner === 'B' ? entityB : 'Equal Tradeoff';
  const winnerColor = verdict.winner === 'A' ? Colors.copper : verdict.winner === 'B' ? Colors.cyan : Colors.ivory;

  const totalScore = verdict.scoreA + verdict.scoreB;
  const pctA = totalScore > 0 ? Math.round((verdict.scoreA / totalScore) * 100) : 50;
  const pctB = totalScore > 0 ? 100 - pctA : 50;

  return (
    <GlassSurface tintColor="rgba(28, 36, 54, 0.38)" style={styles.card}>
      {/* Winner Badge */}
      <View style={[styles.winnerBadge, { borderColor: winnerColor }]}>
        <Text style={[styles.winnerLabel, { color: winnerColor }]}>
          BEST OVERALL: {winnerName.toUpperCase()}
        </Text>
      </View>

      {/* Georgia Editorial Verdict Title */}
      <Text style={styles.verdictTitle}>{verdict.title}</Text>
      <Text style={styles.summaryText}>{verdict.summary}</Text>

      {/* Score Comparison Bar */}
      <View style={styles.scoreSection}>
        <View style={styles.scoreHeader}>
          <Text style={[styles.scoreEntityText, { color: Colors.copper }]}>
            {entityA} ({verdict.scoreA})
          </Text>
          <Text style={[styles.scoreEntityText, { color: Colors.cyan }]}>
            {entityB} ({verdict.scoreB})
          </Text>
        </View>

        <View style={styles.barTrack}>
          <View style={[styles.barA, { width: `${pctA}%` }]} />
          <View style={[styles.barB, { width: `${pctB}%` }]} />
        </View>
      </View>

      {/* Consensuses */}
      {verdict.consensuses && verdict.consensuses.length > 0 && (
        <View style={styles.listSection}>
          <Text style={styles.sectionHeading}>KEY CONSENSUS</Text>
          {verdict.consensuses.map((item, idx) => (
            <View key={idx} style={styles.bulletRow}>
              <Text style={styles.bulletSymbol}>•</Text>
              <Text style={styles.bulletText}>{item}</Text>
            </View>
          ))}
        </View>
      )}

      {/* Contradictions */}
      {verdict.contradictions && verdict.contradictions.length > 0 && (
        <View style={styles.listSection}>
          <Text style={styles.sectionHeading}>KEY CONTRADICTIONS</Text>
          {verdict.contradictions.map((item, idx) => (
            <View key={idx} style={styles.bulletRow}>
              <Text style={[styles.bulletSymbol, { color: Colors.warning }]}>⚡</Text>
              <Text style={styles.bulletText}>{item}</Text>
            </View>
          ))}
        </View>
      )}
    </GlassSurface>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 24,
    padding: 20,
    marginBottom: 20,
    boxShadow: '0 18px 40px rgba(0, 0, 0, 0.26)',
  },
  winnerBadge: {
    alignSelf: 'flex-start',
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: 12,
    borderWidth: 1,
    backgroundColor: Colors.raisedTitanium,
    marginBottom: 14,
  },
  winnerLabel: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  verdictTitle: {
    ...Typography.h2,
    color: Colors.ivory,
    marginBottom: 10,
  },
  summaryText: {
    ...Typography.bodySm,
    color: Colors.muted,
    marginBottom: 20,
    lineHeight: 20,
  },
  scoreSection: {
    backgroundColor: Colors.raisedTitanium,
    borderRadius: 16,
    padding: 14,
    marginBottom: 20,
  },
  scoreHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  scoreEntityText: {
    fontSize: 13,
    fontWeight: '700',
  },
  barTrack: {
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.background,
    flexDirection: 'row',
    overflow: 'hidden',
  },
  barA: {
    height: '100%',
    backgroundColor: Colors.copper,
  },
  barB: {
    height: '100%',
    backgroundColor: Colors.cyan,
  },
  listSection: {
    marginTop: 12,
  },
  sectionHeading: {
    color: Colors.muted,
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 0.8,
    marginBottom: 8,
  },
  bulletRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
    marginBottom: 6,
  },
  bulletSymbol: {
    color: Colors.copper,
    fontSize: 14,
    lineHeight: 18,
  },
  bulletText: {
    color: Colors.ivory,
    fontSize: 14,
    lineHeight: 19,
    flex: 1,
  },
});
