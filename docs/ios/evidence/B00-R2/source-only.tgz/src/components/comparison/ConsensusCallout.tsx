import React, { useState } from 'react';
import { StyleSheet, View, Text, Pressable } from 'react-native';
import { SymbolView } from 'expo-symbols';
import { Colors } from '../../theme/colors';
import { triggerHaptic } from '../../theme/haptics';
import { GlassSurface } from '../common/GlassSurface';

interface ConsensusCalloutProps {
  consensus: string[];
  contradictions: string[];
}

export function ConsensusCallout({ consensus, contradictions }: ConsensusCalloutProps) {
  const [activeTab, setActiveTab] = useState<'consensus' | 'contradictions'>('consensus');

  if (consensus.length === 0 && contradictions.length === 0) {
    return null;
  }

  const items = activeTab === 'consensus' ? consensus : contradictions;

  return (
    <GlassSurface style={styles.container}>
      {/* Segmented Control Header */}
      <View style={styles.tabBar}>
        <Pressable
          style={[styles.tab, activeTab === 'consensus' && styles.tabActive]}
          onPress={() => {
            triggerHaptic.selection();
            setActiveTab('consensus');
          }}
        >
          <SymbolView
            name="checkmark.seal"
            tintColor={activeTab === 'consensus' ? Colors.cyan : Colors.muted}
            size={14}
          />
          <Text
            style={[
              styles.tabText,
              activeTab === 'consensus' && { color: Colors.ivory, fontWeight: '700' },
            ]}
          >
            Consensus ({consensus.length})
          </Text>
        </Pressable>

        <Pressable
          style={[styles.tab, activeTab === 'contradictions' && styles.tabActive]}
          onPress={() => {
            triggerHaptic.selection();
            setActiveTab('contradictions');
          }}
        >
          <SymbolView
            name="bolt.horizontal"
            tintColor={activeTab === 'contradictions' ? Colors.copper : Colors.muted}
            size={14}
          />
          <Text
            style={[
              styles.tabText,
              activeTab === 'contradictions' && { color: Colors.ivory, fontWeight: '700' },
            ]}
          >
            Contradictions ({contradictions.length})
          </Text>
        </Pressable>
      </View>

      {/* Item List */}
      <View style={styles.list}>
        {items.length === 0 ? (
          <Text style={styles.emptyText}>
            {activeTab === 'consensus'
              ? 'No uniform consensus identified across sources.'
              : 'No major contradictions detected across sources.'}
          </Text>
        ) : (
          items.map((item, idx) => (
            <View key={idx} style={styles.itemRow}>
              <View
                style={[
                  styles.bullet,
                  {
                    backgroundColor:
                      activeTab === 'consensus' ? Colors.cyan : Colors.copper,
                  },
                ]}
              />
              <Text style={styles.itemText}>{item}</Text>
            </View>
          ))
        )}
      </View>
    </GlassSurface>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: 20,
    padding: 16,
    marginBottom: 18,
  },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 4,
    marginBottom: 14,
    gap: 4,
  },
  tab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 8,
    borderRadius: 9,
  },
  tabActive: {
    backgroundColor: 'rgba(255, 255, 255, 0.12)',
  },
  tabText: {
    color: Colors.muted,
    fontSize: 12,
    fontWeight: '600',
  },
  list: {
    gap: 10,
  },
  itemRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
  },
  bullet: {
    width: 6,
    height: 6,
    borderRadius: 3,
    marginTop: 6,
  },
  itemText: {
    flex: 1,
    color: Colors.ivory,
    fontSize: 14,
    lineHeight: 20,
  },
  emptyText: {
    color: Colors.muted,
    fontSize: 13,
    fontStyle: 'italic',
    textAlign: 'center',
    paddingVertical: 8,
  },
});
