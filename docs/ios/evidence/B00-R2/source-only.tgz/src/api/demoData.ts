import { ComparisonJob, ComparisonHistoryItem, ComparisonSource } from '../types/schemas';

export const DEMO_COMPARISONS: Record<string, ComparisonJob> = {
  'demo-astro-sveltekit': {
    id: 'demo-astro-sveltekit',
    status: 'completed',
    progress: 100,
    activeStep: 8,
    query: 'Astro vs SvelteKit for high-performance content-driven platforms',
    result: {
      slug: 'astro-vs-sveltekit',
      query: 'Astro vs SvelteKit',
      context: 'high-performance content-driven platforms',
      sources: [
        {
          url: 'https://github.com/withastro/astro',
          title: 'Astro Core Framework & Islands Architecture',
          summary: 'Astro uses server-first component architecture with partial hydration (Islands). Zero JavaScript is shipped by default.',
          fetchedAt: '2026-09-07T12:00:00.000Z',
          confidence: 1.0,
          reliability: 'Official',
        },
        {
          url: 'https://svelte.dev/docs/kit',
          title: 'SvelteKit Official Documentation & App Runtime',
          summary: 'SvelteKit offers seamless full-stack primitives with fine-grained reactivity and minimal boilerplate for interactive web apps.',
          fetchedAt: '2026-09-07T12:00:00.000Z',
          confidence: 0.95,
          reliability: 'Official',
        },
        {
          url: 'https://dev.to/benchmarks/astro-vs-sveltekit-2026',
          title: 'Real-World Performance Benchmarks: SSR & TTI Analysis',
          summary: 'In content-heavy workloads, Astro achieves 38% faster First Contentful Paint. SvelteKit leads in dynamic nested layout state transitions.',
          fetchedAt: '2026-09-07T12:00:00.000Z',
          confidence: 0.88,
          reliability: 'Docs',
        },
      ],
      verdict: {
        summary: 'Astro wins decisively for content-first websites and publishing with zero-JS islands. SvelteKit remains superior for complex state-heavy user dashboards.',
        bestOverall: 'Astro for content & documentation; SvelteKit for rich interactive applications',
        bestValue: 'Both open source under MIT license',
        winner: 'a',
        confidence: 0.96,
      },
      entities: {
        a: {
          name: 'Astro',
          hex: '#FF5D01',
          mark: 'A',
          subtitle: 'Content-First Islands Framework',
        },
        b: {
          name: 'SvelteKit',
          hex: '#FF3E00',
          mark: 'S',
          subtitle: 'Full-Stack Reactive Meta-Framework',
        },
      },
      dimensions: [
        { subject: 'Time to Interactive', a: 98, b: 84, fullMark: 100, weight: 1.2 },
        { subject: 'Interactive Complexity', a: 78, b: 95, fullMark: 100, weight: 1.1 },
        { subject: 'Content Optimization', a: 96, b: 82, fullMark: 100, weight: 1.0 },
        { subject: 'Ecosystem & Adapters', a: 91, b: 89, fullMark: 100, weight: 0.9 },
        { subject: 'Learning Curve', a: 89, b: 92, fullMark: 100, weight: 0.8 },
      ],
      consensus: [
        'Both frameworks compile down with minimal client-side overhead compared to traditional SPA meta-frameworks.',
        'Both support edge deployment natively across Cloudflare Workers, Vercel, and Node runtimes.',
      ],
      contradictions: [
        'Astro favors server rendering with isolated client islands, while SvelteKit favors universal component reactivity across entire route hierarchies.',
      ],
      categories: [
        {
          name: 'Performance & Architecture',
          winner: 'a',
          verdict: 'Astro delivers leaner bundles for static content; SvelteKit excels once dynamic state dominates.',
          facts: [
            {
              entity: 'a',
              label: 'Default Hydration Strategy',
              value: 'Partial hydration via Islands architecture',
              source: 'Official Docs',
              confidence: 0.98,
              freshness: 'Verified',
              sourceTitle: 'Astro Documentation',
              sourceUrl: 'https://docs.astro.build/en/concepts/islands/',
            },
            {
              entity: 'b',
              label: 'Default Hydration Strategy',
              value: 'Full-page progressive hydration with compiler optimizations',
              source: 'Official Docs',
              confidence: 0.95,
              freshness: 'Verified',
              sourceTitle: 'SvelteKit Docs',
              sourceUrl: 'https://kit.svelte.dev/docs/load',
            },
          ],
        },
      ],
      sourceCount: 14,
      updatedAt: '2026-09-08T14:32:00.000Z',
    },
  },
};

export const DEMO_HISTORY_ITEMS: ComparisonHistoryItem[] = [
  {
    id: 'demo-astro-sveltekit',
    query: 'Astro vs SvelteKit',
    slug: 'astro-vs-sveltekit',
    status: 'completed',
    visibility: 'public',
    isFavorited: true,
    folder: 'Frontend Frameworks',
    tags: ['web', 'architecture', 'benchmarks'],
    sourceCount: 14,
    progress: 100,
    updatedAt: '2026-09-08T14:32:00.000Z',
    summary: 'Astro wins decisively for content-first websites and publishing with zero-JS islands. SvelteKit remains superior for complex state-heavy user dashboards.',
    entityA: 'Astro',
    entityB: 'SvelteKit',
    queryCategory: 'software',
    canonicalSlug: 'astro-vs-sveltekit',
    reusedFromId: null,
  },
];

export const DEMO_SOURCES: ComparisonSource[] = [
  {
    title: 'Astro Core Framework & Islands Architecture',
    url: 'https://github.com/withastro/astro',
    reliability: 'Official',
    fetchedAt: '2026-09-07T12:00:00.000Z',
    confidence: 1.0,
    summary: 'Astro uses server-first component architecture with partial hydration (Islands). Zero JavaScript is shipped by default.',
  },
  {
    title: 'SvelteKit Official Documentation & App Runtime',
    url: 'https://svelte.dev/docs/kit',
    reliability: 'Official',
    fetchedAt: '2026-09-07T12:00:00.000Z',
    confidence: 0.95,
    summary: 'SvelteKit offers seamless full-stack primitives with fine-grained reactivity and minimal boilerplate for interactive web apps.',
  },
];

/**
 * Explicit helper to access example data when specifically requested by the user
 * or for UI component showcases. This must NEVER be invoked as an automatic
 * fallback during normal production operation.
 */
export function getExampleComparisons(): Record<string, ComparisonJob> {
  return DEMO_COMPARISONS;
}

export function getExampleComparisonDetail(id: string): ComparisonJob | null {
  return DEMO_COMPARISONS[id] || null;
}

export function getExampleHistory(): ComparisonHistoryItem[] {
  return DEMO_HISTORY_ITEMS;
}

export function getExampleSources(): ComparisonSource[] {
  return DEMO_SOURCES;
}
