import { z } from 'zod';
import { fetchComparisonsHistory, fetchComparisonDetail } from './comparisons';
import { ComparisonSource } from '../types/schemas';
import { getExampleSources } from './demoData';
import { apiFetch } from './client';
import { ApiError } from '../types/api';

const SourceFeedbackEnvelopeSchema = z.object({
  feedback: z.object({
    id: z.string().optional(),
    sourceUrl: z.string().optional(),
    vote: z.number().optional(),
    reason: z.string().nullable().optional(),
  }),
});

export function normalizeUrl(url: string): string {
  try {
    const parsed = new URL(url);
    const hostname = parsed.hostname.toLowerCase().replace(/^www\./, '');
    const pathname = parsed.pathname.replace(/\/$/, '');
    return `${hostname}${pathname}${parsed.search}`;
  } catch {
    return url.toLowerCase().trim().replace(/^https?:\/\//, '').replace(/^www\./, '');
  }
}

export interface AggregatedSourcesReport {
  sources: ComparisonSource[];
  status: 'empty' | 'complete' | 'partial' | 'all_failed';
  totalCompleted: number;
  failedCount: number;
}

/**
 * Fetches and aggregates sources across recent completed comparisons,
 * tracking whether failures occurred to distinguish true empty from network/fetch failures.
 */
export async function fetchAggregatedSourcesReport(limit = 10): Promise<AggregatedSourcesReport> {
  const history = await fetchComparisonsHistory(20);
  const completedItems = history.filter((item) => item.status === 'completed').slice(0, limit);

  if (completedItems.length === 0) {
    return {
      sources: [],
      status: 'empty',
      totalCompleted: 0,
      failedCount: 0,
    };
  }

  const aggregated: ComparisonSource[] = [];
  let failedCount = 0;

  for (const item of completedItems) {
    try {
      const detail = await fetchComparisonDetail(item.id);
      if (detail.result?.sources) {
        aggregated.push(...detail.result.sources);
      }
    } catch {
      failedCount += 1;
    }
  }

  if (failedCount === completedItems.length) {
    return {
      sources: [],
      status: 'all_failed',
      totalCompleted: completedItems.length,
      failedCount,
    };
  }

  const seenUrls = new Set<string>();
  const deduplicatedSources: ComparisonSource[] = [];

  for (const src of aggregated) {
    const norm = normalizeUrl(src.url);
    if (!seenUrls.has(norm)) {
      seenUrls.add(norm);
      deduplicatedSources.push(src);
    }
  }

  return {
    sources: deduplicatedSources,
    status: failedCount > 0 ? 'partial' : 'complete',
    totalCompleted: completedItems.length,
    failedCount,
  };
}

/**
 * Convenience accessor for aggregated sources.
 * Throws typed ApiError if all completed comparisons failed retrieval.
 */
export async function fetchAggregatedSources(): Promise<ComparisonSource[]> {
  const report = await fetchAggregatedSourcesReport();
  if (report.status === 'all_failed') {
    const err: ApiError = {
      statusCode: 502,
      message: 'Failed to retrieve comparison sources from server.',
      code: 'ALL_SOURCES_FAILED',
      retryable: true,
    };
    throw err;
  }
  return report.sources;
}

/**
 * Explicit helper to retrieve example sources for visual previews.
 */
export function getDemoSources(): ComparisonSource[] {
  return getExampleSources();
}

/**
 * Submits feedback on a specific citation source to the backend.
 * Validates the server response envelope.
 */
export async function submitSourceFeedback(
  sourceUrl: string,
  vote: -1 | 0 | 1,
  comparisonId?: string,
  reason?: string
): Promise<{ success: boolean; feedback?: any }> {
  const json = await apiFetch<any>('/api/source-feedback', {
    method: 'POST',
    body: JSON.stringify({
      sourceUrl,
      vote,
      comparisonId,
      reason,
    }),
  });

  const parsed = SourceFeedbackEnvelopeSchema.safeParse(json);
  if (!parsed.success) {
    const err: ApiError = {
      statusCode: 502,
      message: 'Invalid source feedback envelope returned by server.',
      code: 'MALFORMED_RESPONSE',
    };
    throw err;
  }

  return {
    success: true,
    feedback: parsed.data.feedback,
  };
}
