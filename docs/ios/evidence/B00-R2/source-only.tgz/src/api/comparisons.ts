import { z } from 'zod';
import { apiFetch } from './client';
import {
  ComparisonHistoryItemSchema,
  ComparisonHistoryItem,
  ComparisonJobSchema,
  ComparisonJob,
  FollowUpResponseSchema,
  FollowUpResponse,
} from '../types/schemas';
import { getExampleComparisonDetail, getExampleHistory } from './demoData';
import { ApiError } from '../types/api';

const OrganizeResponseSchema = z.object({
  success: z.literal(true),
  // isFavorited is required: the backend always returns the persisted row
  // (comparisons.is_favorited is NOT NULL DEFAULT false), so a missing value
  // means the acknowledgement is malformed and must not be treated as success.
  comparison: z.object({
    isFavorited: z.boolean(),
    folder: z.string().nullable().optional(),
    tags: z.array(z.string()).optional(),
    updatedAt: z.any().optional(),
  }),
});

/**
 * Checks whether an ID represents a static example/demo comparison.
 */
export function isExampleId(id: string): boolean {
  return id.startsWith('demo-') || id.startsWith('example-');
}

/**
 * Fetches recent comparisons for the authenticated user from the backend.
 * Empty history returns an empty array without demo synthesis.
 * Throws a typed ApiError on network or authentication failure.
 */
export async function fetchComparisonsHistory(limit = 50): Promise<ComparisonHistoryItem[]> {
  const json = await apiFetch<any>(`/api/comparisons?limit=${limit}`);
  const schema = z.object({
    comparisons: z.array(ComparisonHistoryItemSchema),
  });
  const parsed = schema.safeParse(json);
  if (!parsed.success) {
    const error: ApiError = {
      statusCode: 502,
      message: 'Invalid comparison history format received from server.',
      code: 'MALFORMED_RESPONSE',
    };
    throw error;
  }
  return parsed.data.comparisons;
}

/**
 * Creates a real comparison research job on the backend.
 * Never accepts arbitrary unvalidated payloads or synthesizes fake metrics.
 */
export async function createComparison(
  query: string,
  options?: { workspaceId?: string; projectId?: string }
): Promise<ComparisonJob> {
  const json = await apiFetch<any>('/api/comparisons', {
    method: 'POST',
    body: JSON.stringify({
      query,
      workspaceId: options?.workspaceId,
      projectId: options?.projectId,
    }),
  });

  const parsed = ComparisonJobSchema.safeParse(json);
  if (!parsed.success) {
    const error: ApiError = {
      statusCode: 502,
      message: 'Malformed job response received from server.',
      code: 'MALFORMED_JOB',
    };
    throw error;
  }

  return parsed.data;
}

/**
 * Fetches full comparison detail for a specific comparison ID.
 * Example fixtures are only returned if the ID explicitly references an example.
 * Rejects malformed server payloads without synthesizing fake completion states.
 */
export async function fetchComparisonDetail(id: string): Promise<ComparisonJob> {
  if (isExampleId(id)) {
    const example = getExampleComparisonDetail(id);
    if (example) return example;
    const notFoundErr: ApiError = {
      statusCode: 404,
      message: `Example comparison ${id} not found.`,
      code: 'NOT_FOUND',
    };
    throw notFoundErr;
  }

  const json = await apiFetch<any>(`/api/comparisons/${id}`);
  const parsed = ComparisonJobSchema.safeParse(json);
  if (!parsed.success) {
    const error: ApiError = {
      statusCode: 502,
      message: 'Malformed comparison detail received from server.',
      code: 'MALFORMED_RESPONSE',
    };
    throw error;
  }

  return parsed.data;
}

/**
 * Triggers a refresh or retry on an existing comparison.
 * Blocks calls on example comparisons.
 */
export async function manageComparison(
  id: string,
  action: 'refresh' | 'retry'
): Promise<{ success: boolean; message?: string }> {
  if (isExampleId(id)) {
    const err: ApiError = {
      statusCode: 400,
      message: 'Example comparisons are static and cannot be refreshed or retried.',
      code: 'EXAMPLE_READ_ONLY',
    };
    throw err;
  }

  const res = await apiFetch<any>(`/api/comparisons/${id}/manage`, {
    method: 'POST',
    body: JSON.stringify({ action }),
  });

  if (!res || res.success !== true) {
    const err: ApiError = {
      statusCode: 502,
      message: 'Invalid management acknowledgement received from server.',
      code: 'MALFORMED_RESPONSE',
    };
    throw err;
  }

  return res;
}

/**
 * Organizes a comparison with real folder, tags, and favorite updates.
 * Blocks calls on example comparisons.
 */
export async function organizeComparison(
  id: string,
  updates: {
    isFavorited?: boolean;
    folder?: string | null;
    tags?: string[];
  }
): Promise<{ success: boolean; comparison: { isFavorited: boolean; folder?: string | null; tags?: string[] } }> {
  if (isExampleId(id)) {
    const err: ApiError = {
      statusCode: 400,
      message: 'Example comparisons are static and cannot be organized.',
      code: 'EXAMPLE_READ_ONLY',
    };
    throw err;
  }

  const json = await apiFetch<any>(`/api/comparisons/${id}/manage`, {
    method: 'POST',
    body: JSON.stringify({
      action: 'organize',
      ...updates,
    }),
  });

  const parsed = OrganizeResponseSchema.safeParse(json);
  if (!parsed.success) {
    const err: ApiError = {
      statusCode: 502,
      message: 'Malformed organize response received from server.',
      code: 'MALFORMED_RESPONSE',
    };
    throw err;
  }

  return parsed.data;
}

/**
 * Real toggle favorite mutation calling the backend organize endpoint.
 * The returned isFavorited is always the server-persisted value; a response
 * missing it is rejected as malformed so callers roll back instead of
 * acknowledging an unconfirmed state.
 */
export async function toggleFavorite(
  id: string,
  isFavorited: boolean
): Promise<{ success: boolean; isFavorited: boolean }> {
  const result = await organizeComparison(id, { isFavorited });
  return {
    success: result.success,
    isFavorited: result.comparison.isFavorited,
  };
}

/**
 * Submits user feedback (star rating, text correction, source accuracy report)
 * to the backend. Blocks calls on example comparisons.
 */
export async function submitFeedback(
  id: string,
  rating: number,
  correction?: string,
  sourceReport?: string
): Promise<{ success: boolean }> {
  if (isExampleId(id)) {
    const err: ApiError = {
      statusCode: 400,
      message: 'Example comparisons are static and do not accept feedback.',
      code: 'EXAMPLE_READ_ONLY',
    };
    throw err;
  }

  const res = await apiFetch<any>(`/api/comparisons/${id}`, {
    method: 'POST',
    body: JSON.stringify({
      rating,
      correction,
      sourceReport,
    }),
  });

  if (!res || res.success !== true) {
    const err: ApiError = {
      statusCode: 502,
      message: 'Invalid feedback submission acknowledgement from server.',
      code: 'MALFORMED_RESPONSE',
    };
    throw err;
  }

  return res;
}

/**
 * Asks an evidence-grounded follow-up question.
 * Throws honestly on error; never synthesizes fake citations.
 * Blocks calls on example comparisons.
 */
export async function submitFollowUpQuestion(
  id: string,
  question: string
): Promise<FollowUpResponse> {
  if (isExampleId(id)) {
    const err: ApiError = {
      statusCode: 400,
      message: 'Follow-up questions are disabled for static example comparisons.',
      code: 'EXAMPLE_READ_ONLY',
    };
    throw err;
  }

  const json = await apiFetch<any>(`/api/comparisons/${id}/actions`, {
    method: 'POST',
    body: JSON.stringify({ action: 'follow-up', question }),
  });
  const parsed = FollowUpResponseSchema.safeParse(json);
  if (!parsed.success) {
    const error: ApiError = {
      statusCode: 502,
      message: 'Invalid follow-up response format from server.',
      code: 'MALFORMED_RESPONSE',
    };
    throw error;
  }
  return parsed.data;
}

/**
 * Validates a comparison query against backend taxonomy and safety rules.
 * Throws typed MALFORMED_RESPONSE if validation endpoint response is invalid.
 */
export async function validateComparison(
  query: string
): Promise<{ canStart: boolean; message?: string; category?: string; intent?: any }> {
  const json = await apiFetch<any>('/api/comparisons/validate', {
    method: 'POST',
    body: JSON.stringify({ query }),
  });

  if (!json || (json.canStart === undefined && json.intent?.canStart === undefined)) {
    const err: ApiError = {
      statusCode: 502,
      message: 'Invalid validation response from server.',
      code: 'MALFORMED_RESPONSE',
    };
    throw err;
  }

  return {
    canStart: Boolean(json.intent?.canStart ?? json.canStart),
    message: json.intent?.message || json.message,
    category: json.category || json.intent?.category,
    intent: json.intent,
  };
}

/**
 * Fetches taxonomy categories and guidelines from the backend.
 */
export async function fetchTaxonomyCategories(): Promise<any[]> {
  const json = await apiFetch<any>('/api/comparisons?action=taxonomy');
  if (json && Array.isArray(json.categories)) {
    return json.categories;
  }
  return [];
}

/**
 * Searches user comparisons locally within real history.
 */
export async function searchComparisons(
  q: string,
  limit = 10
): Promise<ComparisonHistoryItem[]> {
  const history = await fetchComparisonsHistory(limit);
  const lower = q.toLowerCase();
  return history.filter(
    (h) =>
      h.query.toLowerCase().includes(lower) ||
      (h.entityA && h.entityA.toLowerCase().includes(lower)) ||
      (h.entityB && h.entityB.toLowerCase().includes(lower))
  );
}

/**
 * Exports a comparison in the specified format via the backend export engine.
 * Decodes raw markdown text correctly without JSON parsing errors.
 */
export async function exportComparison(
  id: string,
  format: 'markdown' | 'json' = 'markdown'
): Promise<string> {
  const res = await apiFetch<any>(`/api/comparisons/${id}/actions`, {
    method: 'POST',
    body: JSON.stringify({ action: 'export', format }),
  });

  if (typeof res === 'string') return res;
  if (format === 'markdown' && res?.markdown) return res.markdown;
  return typeof res === 'string' ? res : JSON.stringify(res, null, 2);
}
