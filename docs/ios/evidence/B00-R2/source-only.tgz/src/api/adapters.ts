import { ComparisonHistoryItem, ComparisonJob, ComparisonData } from '../types/schemas';

export interface ComparisonViewModel {
  id: string;
  query: string;
  status: 'queued' | 'running' | 'completed' | 'failed';
  progress: number;
  entityA: string;
  entityB: string;
  summary: string;
  sourceCount: number;
  updatedAt: string;
  result: ComparisonData | null;
  error?: string | null;
  isFavorited?: boolean;
}

export function jobToViewModel(job: ComparisonJob): ComparisonViewModel {
  const result = job.result || null;
  const entityA = result?.entities?.a?.name || 'Entity A';
  const entityB = result?.entities?.b?.name || 'Entity B';
  const summary = result?.verdict?.summary || '';
  const sourceCount = result?.sourceCount || 0;
  const updatedAt = result?.updatedAt || new Date().toISOString();

  return {
    id: job.id,
    query: job.query,
    status: job.status,
    progress: job.progress,
    entityA,
    entityB,
    summary,
    sourceCount,
    updatedAt,
    result,
    error: job.error,
    isFavorited: Boolean(job.isFavorited),
  };
}

export function historyItemToViewModel(item: ComparisonHistoryItem): ComparisonViewModel {
  return {
    id: item.id,
    query: item.query,
    status: item.status,
    progress: item.progress || 0,
    entityA: item.entityA || 'Entity A',
    entityB: item.entityB || 'Entity B',
    summary: item.summary || '',
    sourceCount: item.sourceCount || 0,
    updatedAt: item.updatedAt || new Date().toISOString(),
    result: null,
    isFavorited: item.isFavorited || false,
  };
}
