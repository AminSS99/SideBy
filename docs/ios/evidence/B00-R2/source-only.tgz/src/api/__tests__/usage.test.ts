process.env['EXPO_PUBLIC_API_URL'] = 'https://api.sideby.app';

import { fetchUsageStatus } from '../usage';
import * as client from '../client';

describe('Usage API — Strict Quota Contract and Unlimited Tier Support', () => {
  let apiFetchSpy: jest.SpyInstance;

  beforeEach(() => {
    jest.clearAllMocks();
    apiFetchSpy = jest.spyOn(client, 'apiFetch');
  });

  afterEach(() => {
    apiFetchSpy.mockRestore();
  });

  it('rejects malformed or empty payloads ({}) with typed MALFORMED_RESPONSE error', async () => {
    apiFetchSpy.mockResolvedValueOnce({});

    await expect(fetchUsageStatus()).rejects.toEqual(
      expect.objectContaining({
        statusCode: 502,
        code: 'MALFORMED_RESPONSE',
        message: 'Invalid usage payload received from server.',
      })
    );
  });

  it('correctly maps null limits to unlimited quota (isUnlimited: true, limit: null)', async () => {
    apiFetchSpy.mockResolvedValueOnce({
      plan: 'enterprise',
      limits: {
        comparison: null,
        followUp: null,
        refresh: null,
      },
      usage: {
        comparison: { used: 42, limit: null, remaining: null },
        followUp: { used: 120, limit: null, remaining: null },
        refresh: { used: 15, limit: null, remaining: null },
      },
    });

    const result = await fetchUsageStatus();

    expect(result.plan).toBe('Enterprise');
    expect(result.comparison.isUnlimited).toBe(true);
    expect(result.comparison.limit).toBeNull();
    expect(result.comparison.remaining).toBeNull();
    expect(result.comparison.used).toBe(42);

    expect(result.followUp.isUnlimited).toBe(true);
    expect(result.followUp.limit).toBeNull();
    expect(result.refresh.isUnlimited).toBe(true);
  });

  it('parses structured numerical quotas for standard subscription tiers', async () => {
    apiFetchSpy.mockResolvedValueOnce({
      plan: 'pro',
      limits: {
        comparison: 50,
        followUp: 100,
        refresh: 20,
      },
      usage: {
        comparison: { used: 5, limit: 50, remaining: 45 },
        followUp: { used: 12, limit: 100, remaining: 88 },
        refresh: { used: 2, limit: 20, remaining: 18 },
      },
    });

    const result = await fetchUsageStatus();

    expect(result.plan).toBe('Pro Plan');
    expect(result.planKnown).toBe(true);
    expect(result.comparison.isUnlimited).toBe(false);
    expect(result.comparison.state).toBe('finite');
    expect(result.comparison.used).toBe(5);
    expect(result.comparison.limit).toBe(50);
    expect(result.comparison.remaining).toBe(45);
  });

  it('marks omitted limits as unknown, never unlimited or zero-used', async () => {
    apiFetchSpy.mockResolvedValueOnce({
      plan: 'pro',
      limits: {},
      usage: {
        comparison: { used: 5 },
        followUp: {},
        refresh: {},
      },
    });

    const result = await fetchUsageStatus();

    expect(result.comparison.state).toBe('unknown');
    expect(result.comparison.isUnlimited).toBe(false);
    expect(result.comparison.limit).toBeNull();
    expect(result.comparison.remaining).toBeNull();
    expect(result.comparison.used).toBe(5);
    expect(result.followUp.state).toBe('unknown');
    expect(result.followUp.used).toBeNull();
  });

  it('reports an unknown plan instead of a default active plan label', async () => {
    apiFetchSpy.mockResolvedValueOnce({
      limits: { comparisonsPerDay: 10 },
      usage: { comparison: { used: 1, limit: 10, remaining: 9 } },
    });

    const result = await fetchUsageStatus();

    expect(result.plan).toBe('Unknown plan');
    expect(result.planKnown).toBe(false);
  });

  it('leaves remaining unknown when a finite limit has no reported usage', async () => {
    apiFetchSpy.mockResolvedValueOnce({
      plan: 'free',
      limits: { comparisonsPerDay: 10 },
      usage: { comparison: { limit: 10 } },
    });

    const result = await fetchUsageStatus();

    expect(result.comparison.state).toBe('finite');
    expect(result.comparison.used).toBeNull();
    expect(result.comparison.remaining).toBeNull();
  });

  it('leaves reset time unknown when the server omits it', async () => {
    apiFetchSpy.mockResolvedValueOnce({
      plan: 'free',
      limits: { comparisonsPerDay: 10 },
      usage: { comparison: { used: 1, limit: 10, remaining: 9 } },
    });

    const result = await fetchUsageStatus();

    expect(result.resetAt).toBeNull();
  });
});
