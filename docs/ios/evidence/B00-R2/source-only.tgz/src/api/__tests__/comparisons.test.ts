process.env['EXPO_PUBLIC_API_URL'] = 'https://api.sideby.app';

import {
  fetchComparisonsHistory,
  createComparison,
  fetchComparisonDetail,
  toggleFavorite,
  organizeComparison,
  submitFeedback,
  submitFollowUpQuestion,
  exportComparison,
  validateComparison,
} from '../comparisons';
import * as client from '../client';

describe('Comparisons API — Honest Transport and Mutation Contracts', () => {
  let apiFetchSpy: jest.SpyInstance;

  beforeEach(() => {
    jest.clearAllMocks();
    apiFetchSpy = jest.spyOn(client, 'apiFetch');
  });

  afterEach(() => {
    apiFetchSpy.mockRestore();
  });

  describe('fetchComparisonsHistory', () => {
    it('returns honest empty history when user has no comparisons (NO fallback to demo items)', async () => {
      apiFetchSpy.mockResolvedValueOnce({ comparisons: [] });

      const result = await fetchComparisonsHistory(20);

      expect(result).toEqual([]);
      expect(result.length).toBe(0);
      expect(apiFetchSpy).toHaveBeenCalledWith('/api/comparisons?limit=20');
    });

    it('returns parsed comparison list when backend returns data', async () => {
      const mockItem = {
        id: 'real-comp-1',
        query: 'Bun vs Node.js',
        status: 'completed',
        progress: 100,
        updatedAt: '2026-10-01T12:00:00.000Z',
        summary: 'Bun features faster startup.',
        entityA: 'Bun',
        entityB: 'Node.js',
        sourceCount: 5,
        visibility: 'private',
        isFavorited: true,
      };

      apiFetchSpy.mockResolvedValueOnce({ comparisons: [mockItem] });

      const result = await fetchComparisonsHistory(10);
      expect(result.length).toBe(1);
      expect(result[0]?.entityA).toBe('Bun');
      expect(result[0]?.isFavorited).toBe(true);
    });

    it('throws 401 error honestly without synthesizing fallback demo comparisons', async () => {
      apiFetchSpy.mockRejectedValueOnce({
        statusCode: 401,
        message: 'Authentication required. Please sign in.',
        code: 'HTTP_401',
      });

      await expect(fetchComparisonsHistory()).rejects.toEqual(
        expect.objectContaining({
          statusCode: 401,
          code: 'HTTP_401',
        })
      );
    });

    it('throws error on malformed success payload (missing comparisons array)', async () => {
      apiFetchSpy.mockResolvedValueOnce({ wrongKey: 'bad_payload' });

      await expect(fetchComparisonsHistory()).rejects.toEqual(
        expect.objectContaining({
          statusCode: 502,
          code: 'MALFORMED_RESPONSE',
        })
      );
    });
  });

  describe('createComparison', () => {
    it('creates real comparison job and returns parsed job', async () => {
      const mockJob = {
        id: 'job-real-99',
        status: 'running',
        progress: 10,
        activeStep: 1,
        query: 'FastAPI vs Go Gin',
        result: null,
      };

      apiFetchSpy.mockResolvedValueOnce(mockJob);

      const result = await createComparison('FastAPI vs Go Gin');
      expect(result.id).toBe('job-real-99');
      expect(result.status).toBe('running');
      expect(apiFetchSpy).toHaveBeenCalledWith('/api/comparisons', {
        method: 'POST',
        body: JSON.stringify({ query: 'FastAPI vs Go Gin' }),
      });
    });

    it('rejects malformed job payload (e.g. missing status or id) with MALFORMED_JOB', async () => {
      apiFetchSpy.mockResolvedValueOnce({ invalid: 'payload' });

      await expect(createComparison('A vs B')).rejects.toEqual(
        expect.objectContaining({
          statusCode: 502,
          code: 'MALFORMED_JOB',
        })
      );
    });

    it('throws 422 error on rejected/sensitive query without synthesizing fake results', async () => {
      apiFetchSpy.mockRejectedValueOnce({
        statusCode: 422,
        message: 'Comparisons require two distinct entities to evaluate.',
        code: 'QUERY_NOT_COMPARABLE',
      });

      await expect(createComparison('just one entity')).rejects.toEqual(
        expect.objectContaining({
          statusCode: 422,
          code: 'QUERY_NOT_COMPARABLE',
        })
      );
    });

    it('throws 500 server error without client-side fallback synthesis', async () => {
      apiFetchSpy.mockRejectedValueOnce({
        statusCode: 500,
        message: 'Research worker failed.',
        code: 'HTTP_500',
      });

      await expect(createComparison('Redis vs Dragonfly')).rejects.toEqual(
        expect.objectContaining({
          statusCode: 500,
          code: 'HTTP_500',
        })
      );
    });
  });

  describe('fetchComparisonDetail', () => {
    it('fetches real comparison detail from server', async () => {
      const mockDetail = {
        id: 'real-job-123',
        status: 'completed',
        progress: 100,
        activeStep: 8,
        query: 'PostgreSQL vs MySQL',
        result: {
          slug: 'postgresql-vs-mysql',
          entities: {
            a: { name: 'PostgreSQL', mark: 'P', hex: '#336791' },
            b: { name: 'MySQL', mark: 'M', hex: '#00758F' },
          },
          sources: [],
          dimensions: [],
          consensus: [],
          contradictions: [],
          categories: [],
        },
      };

      apiFetchSpy.mockResolvedValueOnce(mockDetail);

      const job = await fetchComparisonDetail('real-job-123');
      expect(job.id).toBe('real-job-123');
      expect(apiFetchSpy).toHaveBeenCalledWith('/api/comparisons/real-job-123');
    });

    it('rejects malformed detail payload with MALFORMED_RESPONSE', async () => {
      apiFetchSpy.mockResolvedValueOnce({ id: 'bad-job', status: 'not-a-valid-status' });

      await expect(fetchComparisonDetail('bad-job')).rejects.toEqual(
        expect.objectContaining({
          statusCode: 502,
          code: 'MALFORMED_RESPONSE',
        })
      );
    });

    it('throws 404 honestly when ID does not exist (NO fallback to astro-vs-sveltekit)', async () => {
      apiFetchSpy.mockRejectedValueOnce({
        statusCode: 404,
        message: 'Comparison not found.',
        code: 'HTTP_404',
      });

      await expect(fetchComparisonDetail('non-existent-id')).rejects.toEqual(
        expect.objectContaining({
          statusCode: 404,
          code: 'HTTP_404',
        })
      );
    });

    it('retrieves isolated example comparison only when ID explicitly requests demo/example', async () => {
      const example = await fetchComparisonDetail('demo-astro-sveltekit');
      expect(example.id).toBe('demo-astro-sveltekit');
      expect(example.result?.entities.a.name).toBe('Astro');
      expect(apiFetchSpy).not.toHaveBeenCalled();
    });
  });

  describe('validateComparison', () => {
    it('rejects malformed validation payload ({}) with MALFORMED_RESPONSE', async () => {
      apiFetchSpy.mockResolvedValueOnce({});

      await expect(validateComparison('A vs B')).rejects.toEqual(
        expect.objectContaining({
          statusCode: 502,
          code: 'MALFORMED_RESPONSE',
        })
      );
    });
  });

  describe('toggleFavorite and organize mutations', () => {
    it('calls real backend manage endpoint with organize action and isFavorited', async () => {
      apiFetchSpy.mockResolvedValueOnce({
        success: true,
        comparison: { isFavorited: true },
      });

      const res = await toggleFavorite('comp-456', true);
      expect(res.success).toBe(true);
      expect(res.isFavorited).toBe(true);
      expect(apiFetchSpy).toHaveBeenCalledWith('/api/comparisons/comp-456/manage', {
        method: 'POST',
        body: JSON.stringify({ action: 'organize', isFavorited: true }),
      });
    });

    it('returns the server-persisted isFavorited even when it differs from the request', async () => {
      apiFetchSpy.mockResolvedValueOnce({
        success: true,
        comparison: { isFavorited: false },
      });

      const res = await toggleFavorite('comp-456', true);
      expect(res.success).toBe(true);
      expect(res.isFavorited).toBe(false);
    });

    it('propagates failure on toggleFavorite so caller can perform mutation rollback', async () => {
      apiFetchSpy.mockRejectedValueOnce({
        statusCode: 500,
        message: 'Database update failed',
        code: 'HTTP_500',
      });

      await expect(toggleFavorite('comp-456', true)).rejects.toEqual(
        expect.objectContaining({
          statusCode: 500,
          code: 'HTTP_500',
        })
      );
    });

    it('rejects a malformed organize acknowledgement missing server isFavorited', async () => {
      // The backend always returns the persisted row (is_favorited NOT NULL),
      // so a missing isFavorited must throw rather than echo the request.
      apiFetchSpy.mockResolvedValueOnce({
        success: true,
        comparison: { folder: 'Database Studies', tags: ['infra', 'sql'] },
      });

      await expect(toggleFavorite('comp-456', true)).rejects.toEqual(
        expect.objectContaining({
          statusCode: 502,
          code: 'MALFORMED_RESPONSE',
        })
      );
    });

    it('organizes folder and tags through real backend endpoint', async () => {
      apiFetchSpy.mockResolvedValueOnce({
        success: true,
        comparison: { isFavorited: false, folder: 'Database Studies', tags: ['infra', 'sql'] },
      });

      const res = await organizeComparison('comp-456', {
        folder: 'Database Studies',
        tags: ['infra', 'sql'],
      });

      expect(res.success).toBe(true);
      expect(apiFetchSpy).toHaveBeenCalledWith('/api/comparisons/comp-456/manage', {
        method: 'POST',
        body: JSON.stringify({
          action: 'organize',
          folder: 'Database Studies',
          tags: ['infra', 'sql'],
        }),
      });
    });
  });

  describe('submitFeedback and follow-up mutations', () => {
    it('submits rating and correction to POST /api/comparisons/:id', async () => {
      apiFetchSpy.mockResolvedValueOnce({ success: true });

      const res = await submitFeedback('comp-789', 5, 'Great analysis of concurrency models.');
      expect(res.success).toBe(true);
      expect(apiFetchSpy).toHaveBeenCalledWith('/api/comparisons/comp-789', {
        method: 'POST',
        body: JSON.stringify({
          rating: 5,
          correction: 'Great analysis of concurrency models.',
        }),
      });
    });

    it('submits follow-up question to POST /api/comparisons/:id/actions and returns verified answer', async () => {
      const mockFollowUp = {
        answer: 'PostgreSQL provides JSONB indexing whereas MySQL JSON support was added later.',
        evidence: [
          {
            id: 'ev-1',
            label: 'Index Type',
            value: 'GIN indexes on JSONB fields',
            confidence: 0.95,
          },
        ],
        confidence: 0.95,
      };

      apiFetchSpy.mockResolvedValueOnce(mockFollowUp);

      const res = await submitFollowUpQuestion('comp-789', 'How do they compare on JSON indexing?');
      expect(res.answer).toContain('PostgreSQL provides JSONB');
      expect(apiFetchSpy).toHaveBeenCalledWith('/api/comparisons/comp-789/actions', {
        method: 'POST',
        body: JSON.stringify({
          action: 'follow-up',
          question: 'How do they compare on JSON indexing?',
        }),
      });
    });

    it('throws honestly on follow-up failure without synthesizing fake answer', async () => {
      apiFetchSpy.mockRejectedValueOnce({
        statusCode: 429,
        message: 'Rate limit exceeded for follow-up queries.',
        code: 'HTTP_429',
      });

      await expect(
        submitFollowUpQuestion('comp-789', 'Another question?')
      ).rejects.toEqual(
        expect.objectContaining({
          statusCode: 429,
          code: 'HTTP_429',
        })
      );
    });
  });

  describe('Example Comparison Mutation Blocking', () => {
    it('blocks organize mutations on static examples with EXAMPLE_READ_ONLY', async () => {
      await expect(toggleFavorite('demo-astro-sveltekit', true)).rejects.toEqual(
        expect.objectContaining({
          statusCode: 400,
          code: 'EXAMPLE_READ_ONLY',
        })
      );
      expect(apiFetchSpy).not.toHaveBeenCalled();
    });

    it('blocks feedback submission on static examples with EXAMPLE_READ_ONLY', async () => {
      await expect(submitFeedback('demo-astro-sveltekit', 5)).rejects.toEqual(
        expect.objectContaining({
          statusCode: 400,
          code: 'EXAMPLE_READ_ONLY',
        })
      );
      expect(apiFetchSpy).not.toHaveBeenCalled();
    });

    it('blocks follow-up questions on static examples with EXAMPLE_READ_ONLY', async () => {
      await expect(submitFollowUpQuestion('example-react-vue', 'Which is faster?')).rejects.toEqual(
        expect.objectContaining({
          statusCode: 400,
          code: 'EXAMPLE_READ_ONLY',
        })
      );
      expect(apiFetchSpy).not.toHaveBeenCalled();
    });
  });

  describe('exportComparison format-correctness', () => {
    it('exports comparison as markdown format correctly', async () => {
      const markdownContent = '# Astro vs SvelteKit\n\nComparative synthesis.';
      apiFetchSpy.mockResolvedValueOnce({ markdown: markdownContent });

      const result = await exportComparison('comp-123', 'markdown');
      expect(result).toBe(markdownContent);
      expect(apiFetchSpy).toHaveBeenCalledWith('/api/comparisons/comp-123/actions', {
        method: 'POST',
        body: JSON.stringify({ action: 'export', format: 'markdown' }),
      });
    });

    it('exports comparison as raw markdown string preserving newlines', async () => {
      const markdownContent = '# Astro vs SvelteKit\n\nComparative synthesis.\n\n- Point 1\n- Point 2';
      apiFetchSpy.mockResolvedValueOnce(markdownContent);

      const result = await exportComparison('comp-123', 'markdown');
      expect(result).toBe(markdownContent);
    });

    it('exports comparison as JSON format correctly', async () => {
      const jsonPayload = { query: 'Astro vs SvelteKit', verdict: { winner: 'a' } };
      apiFetchSpy.mockResolvedValueOnce(jsonPayload);

      const result = await exportComparison('comp-123', 'json');
      expect(JSON.parse(result)).toEqual(jsonPayload);
      expect(apiFetchSpy).toHaveBeenCalledWith('/api/comparisons/comp-123/actions', {
        method: 'POST',
        body: JSON.stringify({ action: 'export', format: 'json' }),
      });
    });
  });
});
