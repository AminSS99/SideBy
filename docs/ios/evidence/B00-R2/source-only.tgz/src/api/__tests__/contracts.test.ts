import {
  ComparisonHistoryItemSchema,
  ComparisonJobSchema,
  FollowUpResponseSchema,
  UsageStatusSchema,
} from '../../types/schemas';
import { jobToViewModel, historyItemToViewModel } from '../adapters';

describe('Real Backend Schema Contract Verification', () => {

  it('validates a real backend History item fixture', () => {
    const fixture = {
      id: 'job-101',
      query: 'PostgreSQL vs MongoDB for analytics',
      status: 'completed',
      progress: 100,
      updatedAt: '2026-07-23T10:00:00.000Z',
      summary: 'PostgreSQL excels in relational integrity while MongoDB excels in flexible schema write speed.',
      entityA: 'PostgreSQL',
      entityB: 'MongoDB',
      sourceCount: 12,
      queryCategory: 'databases',
    };

    const parsed = ComparisonHistoryItemSchema.safeParse(fixture);
    expect(parsed.success).toBe(true);

    if (parsed.success) {
      const vm = historyItemToViewModel(parsed.data);
      expect(vm.entityA).toBe('PostgreSQL');
      expect(vm.entityB).toBe('MongoDB');
      expect(vm.sourceCount).toBe(12);
      expect(vm.updatedAt).toBe('2026-07-23T10:00:00.000Z');
    }
  });

  it('validates a real backend ComparisonJob payload fixture with nested result', () => {
    const fixture = {
      id: 'job-102',
      status: 'completed',
      progress: 100,
      query: 'React vs Vue for enterprise dashboard',
      result: {
        slug: 'react-vs-vue-enterprise-dashboard',
        query: 'React vs Vue for enterprise dashboard',
        context: 'Enterprise dashboard with 50+ engineers',
        entities: {
          a: { name: 'React', subtitle: 'UI Framework', mark: 'A', hex: '#B97450' },
          b: { name: 'Vue', subtitle: 'Progressive Framework', mark: 'B', hex: '#4F858C' },
        },
        sourceCount: 8,
        updatedAt: '2026-07-23T11:00:00.000Z',
        verdict: {
          bestOverall: 'React',
          bestValue: 'Vue',
          summary: 'React offers larger ecosystem support for large enterprise teams.',
        },
        dimensions: [
          { subject: 'Ecosystem', a: 9, b: 7, fullMark: 10 },
          { subject: 'Learning Curve', a: 6, b: 9, fullMark: 10 },
        ],
        consensus: ['Both support TypeScript', 'Both render component trees efficiently'],
        contradictions: ['React uses JSX whereas Vue uses template syntax by default'],
        categories: [
          {
            name: 'Performance',
            winner: 'a',
            verdict: 'React Concurrent Mode offers fine-grained rendering control.',
            facts: [
              {
                entity: 'a',
                label: 'Bundle Size',
                value: '42KB gzipped',
                source: 'Official Docs',
                sourceUrl: 'https://react.dev',
                sourceTitle: 'React Core',
                confidence: 0.95,
                freshness: 'Fresh',
              },
            ],
          },
        ],
        sources: [
          {
            title: 'React Documentation',
            url: 'https://react.dev',
            reliability: 'Official',
            fetchedAt: '2026-07-23T10:30:00.000Z',
            confidence: 0.98,
            summary: 'Official React docs',
          },
        ],
      },
    };

    const parsed = ComparisonJobSchema.safeParse(fixture);
    expect(parsed.success).toBe(true);

    if (parsed.success) {
      const vm = jobToViewModel(parsed.data);
      expect(vm.entityA).toBe('React');
      expect(vm.entityB).toBe('Vue');
      expect(vm.result?.verdict?.bestOverall).toBe('React');
      expect(vm.result?.sources.length).toBe(1);
    }
  });

  it('validates follow-up response payload fixture', () => {
    const fixture = {
      answer: 'React Native compiles to native views whereas Flutter uses Skia rendering.',
      evidence: [
        {
          id: 'ev-1',
          label: 'Rendering Engine',
          value: 'Native iOS UIComponents vs Canvas',
          confidence: 0.92,
        },
      ],
      confidence: 0.94,
    };

    const parsed = FollowUpResponseSchema.safeParse(fixture);
    expect(parsed.success).toBe(true);
    if (parsed.success) {
      expect(parsed.data.evidence.length).toBe(1);
    }
  });

  it('validates usage status payload fixture', () => {
    const fixture = {
      plan: 'Pro Plan',
      limits: { dailyQueries: 20 },
      usage: { dailyQueries: 4, resetAt: '2026-07-24T00:00:00.000Z' },
    };

    const parsed = UsageStatusSchema.safeParse(fixture);
    expect(parsed.success).toBe(true);
  });

  it('validates live backend multi-action usage payload', () => {
    const liveBackendFixture = {
      plan: 'free',
      limits: { comparisonsPerDay: 5, followUpsPerDay: 10, refreshesPerDay: 3 },
      usage: {
        comparison: { used: 1, limit: 5, remaining: 4 },
        followUp: { used: 2, limit: 10, remaining: 8 },
        refresh: { used: 0, limit: 3, remaining: 3 },
      },
      billingConfigured: true,
      subscription: { plan: 'free', status: 'active' },
    };

    const parsed = UsageStatusSchema.safeParse(liveBackendFixture);
    expect(parsed.success).toBe(true);
  });

  it('validates taxonomy category payload', () => {
    const taxonomyFixture = {
      id: 'software',
      label: 'Software & Libraries',
      shortLabel: 'Software',
      description: 'Frameworks, programming languages, and tools.',
      examples: ['React vs Vue', 'TypeScript vs JavaScript'],
      dimensions: [
        { name: 'Developer Experience', description: 'Ergonomics and tooling', weight: 1.1 },
        { name: 'Performance', description: 'Execution speed and bundle size', weight: 1.0 },
      ],
    };

    const { TaxonomyCategorySchema } = require('../../types/schemas');
    const parsed = TaxonomyCategorySchema.safeParse(taxonomyFixture);
    expect(parsed.success).toBe(true);
    if (parsed.success) {
      expect(parsed.data.dimensions.length).toBe(2);
      expect(parsed.data.examples).toContain('React vs Vue');
    }
  });
});

