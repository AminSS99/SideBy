process.env['EXPO_PUBLIC_API_URL'] = 'https://api.sideby.app';

import { apiFetch, setTokenGetter, isTrustedOrigin } from '../client';

(globalThis as any).fetch = jest.fn();

describe('API Client Error Normalization, Quotas, and Security', () => {
  beforeEach(() => {
    process.env['EXPO_PUBLIC_API_URL'] = 'https://api.sideby.app';
    jest.clearAllMocks();
  });

  describe('HTTP Status Handling & Envelopes', () => {
    it('normalizes 401 Unauthorized HTTP errors', async () => {
      ((globalThis as any).fetch as jest.Mock).mockResolvedValueOnce({
        ok: false,
        status: 401,
        headers: new Headers(),
        json: async () => ({ error: 'Authentication required. Please sign in.' }),
      });

      await expect(apiFetch('/api/test')).rejects.toEqual({
        statusCode: 401,
        message: 'Authentication required. Please sign in.',
        code: 'HTTP_401',
        retryAfter: undefined,
        retryable: false,
      });
    });

    it('normalizes 403 Forbidden HTTP errors', async () => {
      ((globalThis as any).fetch as jest.Mock).mockResolvedValueOnce({
        ok: false,
        status: 403,
        headers: new Headers(),
        json: async () => ({ error: 'Access forbidden.' }),
      });

      await expect(apiFetch('/api/test')).rejects.toEqual({
        statusCode: 403,
        message: 'Access forbidden.',
        code: 'HTTP_403',
        retryAfter: undefined,
        retryable: false,
      });
    });

    it('normalizes 404 Not Found HTTP errors', async () => {
      ((globalThis as any).fetch as jest.Mock).mockResolvedValueOnce({
        ok: false,
        status: 404,
        headers: new Headers(),
        json: async () => ({ error: 'Requested resource not found.' }),
      });

      await expect(apiFetch('/api/test')).rejects.toEqual({
        statusCode: 404,
        message: 'Requested resource not found.',
        code: 'HTTP_404',
        retryAfter: undefined,
        retryable: false,
      });
    });

    it('normalizes 422 Unprocessable Entity errors', async () => {
      ((globalThis as any).fetch as jest.Mock).mockResolvedValueOnce({
        ok: false,
        status: 422,
        headers: new Headers(),
        json: async () => ({ error: 'Query contains unsupported domain.' }),
      });

      await expect(apiFetch('/api/test')).rejects.toEqual({
        statusCode: 422,
        message: 'Query contains unsupported domain.',
        code: 'HTTP_422',
        retryAfter: undefined,
        retryable: false,
      });
    });

    it('normalizes 429 Rate Limit errors and parses Retry-After header', async () => {
      ((globalThis as any).fetch as jest.Mock).mockResolvedValueOnce({
        ok: false,
        status: 429,
        headers: {
          get: (h: string) => (h === 'retry-after' ? '30' : null),
        },
        json: async () => ({ message: 'Rate limit exceeded. Please wait 30 seconds.' }),
      });

      await expect(apiFetch('/api/test')).rejects.toEqual({
        statusCode: 429,
        message: 'Rate limit exceeded. Please wait 30 seconds.',
        code: 'HTTP_429',
        retryAfter: 30,
        retryable: true,
      });
    });

    it('parses HTTP-date format in Retry-After header', async () => {
      const futureDate = new Date(Date.now() + 45000).toUTCString();
      ((globalThis as any).fetch as jest.Mock).mockResolvedValueOnce({
        ok: false,
        status: 429,
        headers: {
          get: (h: string) => (h === 'retry-after' ? futureDate : null),
        },
        json: async () => ({ message: 'Rate limit hit' }),
      });

      try {
        await apiFetch('/api/test');
        fail('Should have thrown');
      } catch (err: any) {
        expect(err.statusCode).toBe(429);
        expect(err.retryAfter).toBeGreaterThanOrEqual(40);
        expect(err.retryAfter).toBeLessThanOrEqual(50);
      }
    });

    it('normalizes 500 Internal Server errors', async () => {
      ((globalThis as any).fetch as jest.Mock).mockResolvedValueOnce({
        ok: false,
        status: 500,
        headers: new Headers(),
        json: async () => ({ error: 'Database connection failed' }),
      });

      await expect(apiFetch('/api/test')).rejects.toEqual({
        statusCode: 500,
        message: 'Database connection failed',
        code: 'HTTP_500',
        retryAfter: undefined,
        retryable: false,
      });
    });

    it('normalizes 503 Service Unavailable errors as retryable', async () => {
      ((globalThis as any).fetch as jest.Mock).mockResolvedValueOnce({
        ok: false,
        status: 503,
        headers: new Headers(),
        json: async () => ({ message: 'Service undergoing maintenance.' }),
      });

      await expect(apiFetch('/api/test')).rejects.toEqual({
        statusCode: 503,
        message: 'Service undergoing maintenance.',
        code: 'HTTP_503',
        retryAfter: undefined,
        retryable: true,
      });
    });
  });

  describe('Real Response Boundary Content-Type Decoding', () => {
    it('decodes raw multi-line text/markdown without JSON parsing failure', async () => {
      const markdown = '# Comparison: Bun vs Node.js\n\n- Fact 1: Fast startup\n- Fact 2: Native TS';
      const headers = new Headers({ 'content-type': 'text/markdown; charset=utf-8' });
      const realResponse = new Response(markdown, { status: 200, headers });
      ((globalThis as any).fetch as jest.Mock).mockResolvedValueOnce(realResponse);

      const res = await apiFetch<string>('/api/comparisons/123/actions');
      expect(res).toBe(markdown);
    });

    it('decodes application/json into structured JavaScript object', async () => {
      const data = { id: 'comp-1', verdict: { winner: 'a' } };
      const headers = new Headers({ 'content-type': 'application/json' });
      const realResponse = new Response(JSON.stringify(data), { status: 200, headers });
      ((globalThis as any).fetch as jest.Mock).mockResolvedValueOnce(realResponse);

      const res = await apiFetch<typeof data>('/api/comparisons/comp-1');
      expect(res).toEqual(data);
    });
  });

  describe('Trusted-Origin Token Handling', () => {
    it('attaches Bearer token for trusted origin relative paths', async () => {
      setTokenGetter(async () => 'clerk_test_token_123');

      ((globalThis as any).fetch as jest.Mock).mockResolvedValueOnce({
        ok: true,
        status: 200,
        json: async () => ({ ok: true }),
      });

      await apiFetch('/api/comparisons');

      expect((globalThis as any).fetch).toHaveBeenCalledWith(
        'https://api.sideby.app/api/comparisons',
        expect.objectContaining({
          headers: expect.objectContaining({
            Authorization: 'Bearer clerk_test_token_123',
          }),
        })
      );
    });

    it('attaches Bearer token for trusted origin absolute URLs matching API URL', async () => {
      setTokenGetter(async () => 'clerk_test_token_123');

      ((globalThis as any).fetch as jest.Mock).mockResolvedValueOnce({
        ok: true,
        status: 200,
        json: async () => ({ ok: true }),
      });

      await apiFetch('https://api.sideby.app/api/user');

      expect((globalThis as any).fetch).toHaveBeenCalledWith(
        'https://api.sideby.app/api/user',
        expect.objectContaining({
          headers: expect.objectContaining({
            Authorization: 'Bearer clerk_test_token_123',
          }),
        })
      );
    });

    it('SUPPRESSES Bearer token for untrusted third-party origins', async () => {
      setTokenGetter(async () => 'clerk_test_token_123');

      ((globalThis as any).fetch as jest.Mock).mockResolvedValueOnce({
        ok: true,
        status: 200,
        json: async () => ({ ok: true }),
      });

      await apiFetch('https://untrusted-external-site.com/api/data');

      const calledHeaders = ((globalThis as any).fetch as jest.Mock).mock.calls[0][1].headers;
      expect(calledHeaders['Authorization']).toBeUndefined();
    });

    it('STRIPS caller-supplied Authorization header when target is an untrusted third-party origin', async () => {
      ((globalThis as any).fetch as jest.Mock).mockResolvedValueOnce({
        ok: true,
        status: 200,
        json: async () => ({ ok: true }),
      });

      await apiFetch('https://evil-analytics.com/track', {
        headers: { Authorization: 'Bearer secret_user_token' },
      });

      const calledHeaders = ((globalThis as any).fetch as jest.Mock).mock.calls[0][1].headers;
      expect(calledHeaders['Authorization']).toBeUndefined();
      expect(calledHeaders['authorization']).toBeUndefined();
    });

    it('throws typed AUTH_ERROR when getAuthTokenFn rejects', async () => {
      setTokenGetter(async () => {
        throw new Error('Clerk session expired');
      });

      await expect(apiFetch('/api/protected')).rejects.toEqual({
        statusCode: 401,
        message: 'Failed to retrieve authentication token.',
        code: 'AUTH_ERROR',
        retryable: false,
      });
      setTokenGetter(null);
    });

    it('correctly determines trusted origin with isTrustedOrigin helper', () => {
      const baseUrl = 'https://api.sideby.app';
      expect(isTrustedOrigin('/api/comparisons', baseUrl)).toBe(true);
      expect(isTrustedOrigin('https://api.sideby.app/api/comparisons', baseUrl)).toBe(true);
      expect(isTrustedOrigin('https://attacker.com/api/comparisons', baseUrl)).toBe(false);
      expect(isTrustedOrigin('http://api.sideby.app/api/comparisons', baseUrl)).toBe(false);
      expect(isTrustedOrigin('https://api.sideby.app:8080/api', baseUrl)).toBe(false);
    });
  });

  describe('Timeout and Cancellation', () => {
    it('rejects immediately without calling fetch if signal is already aborted', async () => {
      const controller = new AbortController();
      controller.abort();

      await expect(
        apiFetch('/api/test', { signal: controller.signal })
      ).rejects.toEqual({
        statusCode: 0,
        message: 'Request was cancelled.',
        code: 'CANCELLED',
        retryable: false,
      });

      expect((globalThis as any).fetch).not.toHaveBeenCalled();
    });

    it('handles explicit AbortSignal cancellation during execution', async () => {
      const controller = new AbortController();
      ((globalThis as any).fetch as jest.Mock).mockImplementationOnce(() => {
        controller.abort();
        const err = new Error('The operation was aborted');
        err.name = 'AbortError';
        return Promise.reject(err);
      });

      await expect(
        apiFetch('/api/long-running', { signal: controller.signal })
      ).rejects.toEqual({
        statusCode: 0,
        message: 'Request was cancelled.',
        code: 'CANCELLED',
        retryable: false,
      });
    });

    it('handles timeout when request exceeds timeoutMs', async () => {
      ((globalThis as any).fetch as jest.Mock).mockImplementationOnce((_url: string, opts: any) => {
        return new Promise((_, reject) => {
          if (opts.signal) {
            opts.signal.addEventListener('abort', () => {
              const err = new Error('The operation was aborted');
              err.name = 'AbortError';
              reject(err);
            });
          }
        });
      });

      await expect(apiFetch('/api/slow', { timeoutMs: 15 })).rejects.toEqual({
        statusCode: 0,
        message: 'Request timed out after 15ms.',
        code: 'TIMEOUT',
        retryable: true,
      });
    });
  });
});
