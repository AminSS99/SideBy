import {
  normalizeUrl,
  fetchAggregatedSources,
  fetchAggregatedSourcesReport,
  submitSourceFeedback,
} from '../sources';
import * as comparisons from '../comparisons';
import * as client from '../client';
import { ComparisonHistoryItem, ComparisonJob } from '../../types/schemas';

describe('Source URL Normalization and Deduplication', () => {
  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('normalizes URLs by stripping www prefix, trailing slashes, and lowercasing protocol/hostname', () => {
    expect(normalizeUrl('https://www.example.com/page/')).toBe('example.com/page');
    expect(normalizeUrl('HTTP://WWW.TEST.ORG/path/to/doc')).toBe('test.org/path/to/doc');
  });

  it('preserves query parameters while normalizing', () => {
    expect(normalizeUrl('https://www.google.com/search?q=sideby')).toBe('google.com/search?q=sideby');
  });

  it('returns honest empty array when user has no completed comparisons (NO fallback to DEMO_SOURCES)', async () => {
    jest.spyOn(comparisons, 'fetchComparisonsHistory').mockResolvedValueOnce([]);

    const sources = await fetchAggregatedSources();
    expect(sources).toEqual([]);
    expect(sources.length).toBe(0);
  });

  it('aggregates and deduplicates sources from completed comparisons', async () => {
    const mockHistoryItem: ComparisonHistoryItem = {
      id: 'comp-1',
      query: 'Next.js vs Remix',
      slug: 'nextjs-vs-remix',
      status: 'completed',
      progress: 100,
      updatedAt: '2026-10-01T00:00:00.000Z',
      visibility: 'private',
      isFavorited: false,
      tags: [],
    };

    jest.spyOn(comparisons, 'fetchComparisonsHistory').mockResolvedValueOnce([mockHistoryItem]);

    const mockDetail: ComparisonJob = {
      id: 'comp-1',
      status: 'completed',
      progress: 100,
      activeStep: 8,
      query: 'Next.js vs Remix',
      result: {
        slug: 'nextjs-vs-remix',
        query: 'Next.js vs Remix',
        context: '',
        sourceCount: 2,
        updatedAt: '2026-10-01T00:00:00.000Z',
        dimensions: [],
        consensus: [],
        contradictions: [],
        categories: [],
        sources: [
          {
            title: 'Next.js Documentation',
            url: 'https://nextjs.org/docs',
            reliability: 'Official',
            confidence: 0.98,
            summary: 'Next.js React Framework',
            fetchedAt: '2026-10-01T00:00:00.000Z',
          },
          {
            title: 'Next.js Docs (dup)',
            url: 'https://nextjs.org/docs/',
            reliability: 'Official',
            confidence: 0.98,
            summary: 'Next.js React Framework duplicate',
            fetchedAt: '2026-10-01T00:00:00.000Z',
          },
        ],
        entities: {
          a: { name: 'Next.js', subtitle: 'Framework', mark: 'N', hex: '#000000' },
          b: { name: 'Remix', subtitle: 'Framework', mark: 'R', hex: '#121212' },
        },
      },
    };

    jest.spyOn(comparisons, 'fetchComparisonDetail').mockResolvedValueOnce(mockDetail);

    const sources = await fetchAggregatedSources();
    expect(sources.length).toBe(1);
    expect(sources[0]?.title).toBe('Next.js Documentation');
  });

  describe('fetchAggregatedSourcesReport status handling', () => {
    it('returns empty status when user has no completed comparisons', async () => {
      jest.spyOn(comparisons, 'fetchComparisonsHistory').mockResolvedValueOnce([]);

      const report = await fetchAggregatedSourcesReport();
      expect(report.status).toBe('empty');
      expect(report.sources).toEqual([]);
      expect(report.failedCount).toBe(0);
    });

    it('returns all_failed status when all detail requests reject', async () => {
      const mockHistoryItem: ComparisonHistoryItem = {
        id: 'comp-fail-1',
        query: 'A vs B',
        slug: 'a-vs-b',
        status: 'completed',
        progress: 100,
        updatedAt: '2026-10-01T00:00:00.000Z',
        visibility: 'private',
        isFavorited: false,
        tags: [],
      };

      jest.spyOn(comparisons, 'fetchComparisonsHistory').mockResolvedValueOnce([mockHistoryItem]);
      jest.spyOn(comparisons, 'fetchComparisonDetail').mockRejectedValueOnce(new Error('500 server error'));

      const report = await fetchAggregatedSourcesReport();
      expect(report.status).toBe('all_failed');
      expect(report.failedCount).toBe(1);
      expect(report.sources).toEqual([]);
    });

    it('throws ALL_SOURCES_FAILED when fetchAggregatedSources encounters all_failed', async () => {
      const mockHistoryItem: ComparisonHistoryItem = {
        id: 'comp-fail-2',
        query: 'A vs B',
        slug: 'a-vs-b',
        status: 'completed',
        progress: 100,
        updatedAt: '2026-10-01T00:00:00.000Z',
        visibility: 'private',
        isFavorited: false,
        tags: [],
      };

      jest.spyOn(comparisons, 'fetchComparisonsHistory').mockResolvedValueOnce([mockHistoryItem]);
      jest.spyOn(comparisons, 'fetchComparisonDetail').mockRejectedValueOnce(new Error('500 server error'));

      await expect(fetchAggregatedSources()).rejects.toEqual(
        expect.objectContaining({
          statusCode: 502,
          code: 'ALL_SOURCES_FAILED',
        })
      );
    });

    it('returns partial status when some detail requests succeed and others fail', async () => {
      const item1: ComparisonHistoryItem = {
        id: 'comp-ok',
        query: 'A vs B',
        slug: 'a-vs-b',
        status: 'completed',
        progress: 100,
        updatedAt: '2026-10-01T00:00:00.000Z',
        visibility: 'private',
        isFavorited: false,
        tags: [],
      };
      const item2: ComparisonHistoryItem = {
        id: 'comp-bad',
        query: 'C vs D',
        slug: 'c-vs-d',
        status: 'completed',
        progress: 100,
        updatedAt: '2026-10-01T00:00:00.000Z',
        visibility: 'private',
        isFavorited: false,
        tags: [],
      };

      jest.spyOn(comparisons, 'fetchComparisonsHistory').mockResolvedValueOnce([item1, item2]);
      jest.spyOn(comparisons, 'fetchComparisonDetail')
        .mockResolvedValueOnce({
          id: 'comp-ok',
          status: 'completed',
          progress: 100,
          query: 'A vs B',
          result: {
            sources: [{ title: 'Doc A', url: 'https://doc-a.org' }],
            entities: { a: { name: 'A' }, b: { name: 'B' } },
          },
        } as any)
        .mockRejectedValueOnce(new Error('Network error'));

      const report = await fetchAggregatedSourcesReport();
      expect(report.status).toBe('partial');
      expect(report.failedCount).toBe(1);
      expect(report.sources.length).toBe(1);
    });
  });

  it('submits source accuracy feedback to POST /api/source-feedback', async () => {
    const apiFetchSpy = jest.spyOn(client, 'apiFetch').mockResolvedValueOnce({
      feedback: { id: 'fb-1', vote: 1 },
    });

    const res = await submitSourceFeedback('https://docs.astro.build', 1, 'comp-10', 'Very accurate');
    expect(res.success).toBe(true);
    expect(apiFetchSpy).toHaveBeenCalledWith('/api/source-feedback', {
      method: 'POST',
      body: JSON.stringify({
        sourceUrl: 'https://docs.astro.build',
        vote: 1,
        comparisonId: 'comp-10',
        reason: 'Very accurate',
      }),
    });
  });
});
