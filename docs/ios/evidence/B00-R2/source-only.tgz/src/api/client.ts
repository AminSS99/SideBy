import { ApiError } from '../types/api';

let getAuthTokenFn: (() => Promise<string | null>) | null = null;

export function setTokenGetter(fn: (() => Promise<string | null>) | null) {
  getAuthTokenFn = fn;
}

export function getApiBaseUrl(): string {
  const env = process.env || {};
  const apiUrl = env['EXPO_PUBLIC_API_URL'] || (globalThis as any).__EXPO_PUBLIC_API_URL__;
  if (!apiUrl) {
    throw new Error('EXPO_PUBLIC_API_URL is not configured in environment.');
  }
  return String(apiUrl).replace(/\/$/, '');
}

/**
 * Checks if the target URL shares the exact origin (protocol + hostname + port)
 * with the configured base API URL. Relative URLs (starting with /) are always trusted.
 */
export function isTrustedOrigin(targetUrl: string, baseUrl: string): boolean {
  if (targetUrl.startsWith('/') && !targetUrl.startsWith('//')) {
    return true;
  }
  try {
    const targetParsed = new URL(targetUrl);
    const baseParsed = new URL(baseUrl);
    return targetParsed.origin === baseParsed.origin;
  } catch {
    return false;
  }
}

export interface ApiFetchOptions extends RequestInit {
  timeoutMs?: number;
  responseType?: 'json' | 'text' | 'auto';
}

/**
 * Normalizes any HeadersInit into a plain key-value object.
 */
function normalizeHeaders(headersInit?: HeadersInit): Record<string, string> {
  const result: Record<string, string> = {};
  if (!headersInit) return result;

  if (typeof Headers !== 'undefined' && headersInit instanceof Headers) {
    headersInit.forEach((value, key) => {
      result[key] = value;
    });
  } else if (Array.isArray(headersInit)) {
    headersInit.forEach(([key, value]) => {
      result[key] = value;
    });
  } else {
    Object.assign(result, headersInit);
  }
  return result;
}

/**
 * Parses the Retry-After header which can be either a number of seconds
 * or an HTTP-date (RFC 7231).
 */
export function parseRetryAfter(headerValue?: string | null): number | undefined {
  if (!headerValue) return undefined;
  const trimmed = headerValue.trim();

  // Try parsing as integer seconds
  const seconds = parseInt(trimmed, 10);
  if (!Number.isNaN(seconds) && /^\d+$/.test(trimmed)) {
    return Math.max(0, seconds);
  }

  // Try parsing as HTTP-date
  const timestamp = Date.parse(trimmed);
  if (!Number.isNaN(timestamp)) {
    const diffSec = Math.ceil((timestamp - Date.now()) / 1000);
    return Math.max(0, diffSec);
  }

  return undefined;
}

export async function apiFetch<T>(
  endpoint: string,
  options: ApiFetchOptions = {}
): Promise<T> {
  // Check pre-aborted signal before beginning any work
  if (options.signal?.aborted) {
    const apiErr: ApiError = {
      statusCode: 0,
      message: 'Request was cancelled.',
      code: 'CANCELLED',
      retryable: false,
    };
    throw apiErr;
  }

  const baseUrl = getApiBaseUrl();
  const isTrusted = isTrustedOrigin(endpoint, baseUrl);
  const url = endpoint.startsWith('http://') || endpoint.startsWith('https://')
    ? endpoint
    : `${baseUrl}${endpoint.startsWith('/') ? '' : '/'}${endpoint}`;

  const incomingHeaders = normalizeHeaders(options.headers);
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    Accept: 'application/json, text/markdown, text/plain, */*',
    ...incomingHeaders,
  };

  // ENFORCE ORIGIN SECURITY:
  // If destination is UNTRUSTED, strictly strip any caller-supplied authorization headers
  if (!isTrusted) {
    delete headers['Authorization'];
    delete headers['authorization'];
  } else if (getAuthTokenFn) {
    try {
      const token = await getAuthTokenFn();
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
    } catch {
      const authErr: ApiError = {
        statusCode: 401,
        message: 'Failed to retrieve authentication token.',
        code: 'AUTH_ERROR',
        retryable: false,
      };
      throw authErr;
    }
  }

  // Setup timeout and abort handling
  const timeoutMs = options.timeoutMs ?? 20000;
  const controller = new AbortController();
  let timedOut = false;

  const timer = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, timeoutMs);

  const abortListener = () => {
    controller.abort();
  };

  if (options.signal) {
    options.signal.addEventListener('abort', abortListener);
  }

  try {
    const response = await fetch(url, {
      ...options,
      headers,
      signal: controller.signal,
    });

    if (!response.ok) {
      let errorData: any = {};

      try {
        if (typeof response.json === 'function') {
          errorData = await response.json();
        } else if (typeof response.text === 'function') {
          const raw = await response.text();
          try {
            errorData = JSON.parse(raw);
          } catch {
            errorData = { message: raw };
          }
        }
      } catch {
        if (typeof response.text === 'function') {
          try {
            const raw = await response.text();
            errorData = { message: raw };
          } catch {}
        }
      }

      const retryAfter =
        parseRetryAfter(response.headers?.get?.('retry-after')) ??
        (typeof errorData?.retryAfter === 'number' ? errorData.retryAfter : undefined);

      // Server outage/rate limits are retryable; 500 application error is not
      const isRetryable =
        response.status === 429 ||
        response.status === 502 ||
        response.status === 503 ||
        response.status === 504 ||
        Boolean(errorData?.retryable);

      const apiErr: ApiError = {
        statusCode: response.status,
        message:
          errorData?.message ||
          errorData?.error ||
          (response.status === 401
            ? 'Authentication required. Please sign in.'
            : response.status === 403
            ? 'Access forbidden.'
            : response.status === 404
            ? 'Requested resource not found.'
            : response.status === 422
            ? 'Unprocessable entity or invalid parameters.'
            : response.status === 429
            ? 'Rate limit exceeded. Please wait before retrying.'
            : response.status === 503
            ? 'Service temporarily unavailable. Please retry shortly.'
            : response.status >= 500
            ? `Server error (${response.status}). Please try again later.`
            : `HTTP error ${response.status}`),
        code: errorData?.code || `HTTP_${response.status}`,
        retryAfter,
        retryable: isRetryable,
      };

      throw apiErr;
    }

    if (response.status === 204) {
      return null as T;
    }

    const responseType = options.responseType || 'auto';
    const contentType = response.headers?.get?.('content-type') || '';

    if (responseType === 'text' && typeof response.text === 'function') {
      return (await response.text()) as T;
    }

    if (responseType === 'json' && typeof response.json === 'function') {
      return (await response.json()) as T;
    }

    // Auto-decode based on Content-Type header
    if (
      (contentType.includes('text/markdown') || contentType.includes('text/plain')) &&
      typeof response.text === 'function'
    ) {
      return (await response.text()) as T;
    }

    if (contentType.includes('application/json') && typeof response.json === 'function') {
      return (await response.json()) as T;
    }

    // Fallback: prefer response.json if available, then response.text
    if (typeof response.json === 'function') {
      try {
        return (await response.json()) as T;
      } catch {
        if (typeof response.text === 'function') {
          return (await response.text()) as T;
        }
      }
    } else if (typeof response.text === 'function') {
      const bodyText = await response.text();
      try {
        return JSON.parse(bodyText) as T;
      } catch {
        return bodyText as unknown as T;
      }
    }

    return {} as T;
  } catch (err: any) {
    if (timedOut) {
      const apiErr: ApiError = {
        statusCode: 0,
        message: `Request timed out after ${timeoutMs}ms.`,
        code: 'TIMEOUT',
        retryable: true,
      };
      throw apiErr;
    }
    if (options.signal?.aborted) {
      const apiErr: ApiError = {
        statusCode: 0,
        message: 'Request was cancelled.',
        code: 'CANCELLED',
        retryable: false,
      };
      throw apiErr;
    }
    if (err && typeof err === 'object' && 'statusCode' in err) {
      throw err;
    }
    const apiErr: ApiError = {
      statusCode: 0,
      message: err?.message || 'Network connection failed. Device may be offline.',
      code: 'NETWORK_ERROR',
      retryable: true,
    };
    throw apiErr;
  } finally {
    clearTimeout(timer);
    if (options.signal) {
      options.signal.removeEventListener('abort', abortListener);
    }
  }
}
