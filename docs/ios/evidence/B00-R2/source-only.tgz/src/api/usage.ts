import { apiFetch } from './client';
import { ApiError } from '../types/api';

/**
 * Quota knowledge state for a single metric.
 * - 'finite': server supplied a numeric limit.
 * - 'unlimited': server explicitly reported no limit (JSON null).
 * - 'unknown': server omitted the limit, so no quota claim can be made.
 * A missing field must never render as "Unlimited" or as a known count.
 */
export type QuotaState = 'finite' | 'unlimited' | 'unknown';

export interface UsageQuotaMetric {
  used: number | null; // null when the server did not report usage
  limit: number | null; // null when unlimited OR unknown — see `state`
  remaining: number | null; // null when unlimited, unknown, or used is unknown
  state: QuotaState;
  isUnlimited: boolean; // true only when state === 'unlimited'
}

export interface NormalizedUsage {
  plan: string; // 'Unknown plan' when the server did not report one
  planKnown: boolean;
  comparison: UsageQuotaMetric;
  followUp: UsageQuotaMetric;
  refresh: UsageQuotaMetric;
  dailyQueries: number | null;
  dailyLimit: number | null;
  resetAt: string | null; // null when the server did not report a reset time
}

/**
 * Fetches real usage status and quota limits for the authenticated user.
 * Rejects malformed server payloads ({}) rather than synthesizing a fake Free Plan.
 * Throws a typed ApiError on network, authentication, or schema failure.
 */
export async function fetchUsageStatus(): Promise<NormalizedUsage> {
  const json = await apiFetch<any>('/api/usage');

  if (!json || typeof json !== 'object' || (!json.plan && !json.limits && !json.usage)) {
    const err: ApiError = {
      statusCode: 502,
      message: 'Invalid usage payload received from server.',
      code: 'MALFORMED_RESPONSE',
    };
    throw err;
  }

  const rawPlan = json.plan;
  const planKnown = typeof rawPlan === 'string' && rawPlan.trim().length > 0;
  const plan = !planKnown
    ? 'Unknown plan'
    : rawPlan === 'free'
    ? 'Free Tier'
    : rawPlan === 'pro'
    ? 'Pro Plan'
    : rawPlan.charAt(0).toUpperCase() + rawPlan.slice(1);

  const rawUsage = json.usage || {};
  const rawLimits = json.limits || {};

  const comparison = parseQuotaMetric(
    typeof rawUsage.comparison?.used === 'number'
      ? rawUsage.comparison.used
      : typeof rawUsage.dailyQueries === 'number'
      ? rawUsage.dailyQueries
      : undefined,
    rawUsage.comparison?.limit !== undefined
      ? rawUsage.comparison.limit
      : rawLimits.comparisonsPerDay !== undefined
      ? rawLimits.comparisonsPerDay
      : rawLimits.dailyQueries,
    rawUsage.comparison?.remaining
  );
  const followUp = parseQuotaMetric(
    rawUsage.followUp?.used,
    rawUsage.followUp?.limit !== undefined
      ? rawUsage.followUp.limit
      : rawLimits.followUpsPerDay,
    rawUsage.followUp?.remaining
  );
  const refresh = parseQuotaMetric(
    rawUsage.refresh?.used,
    rawUsage.refresh?.limit !== undefined
      ? rawUsage.refresh.limit
      : rawLimits.refreshesPerDay,
    rawUsage.refresh?.remaining
  );

  return {
    plan,
    planKnown,
    comparison,
    followUp,
    refresh,
    dailyQueries: comparison.used,
    dailyLimit: comparison.limit,
    resetAt: typeof rawUsage.resetAt === 'string' ? rawUsage.resetAt : null,
  };
}

/**
 * Normalizes one quota metric into finite / unlimited / unknown.
 * An omitted limit (undefined) is unknown — never unlimited, never zero-used.
 * An explicit JSON null limit is an unlimited entitlement.
 */
function parseQuotaMetric(
  rawUsed: unknown,
  rawLimit: unknown,
  rawRemaining: unknown
): UsageQuotaMetric {
  const used = typeof rawUsed === 'number' ? rawUsed : null;

  if (rawLimit === null) {
    return { used, limit: null, remaining: null, state: 'unlimited', isUnlimited: true };
  }
  if (typeof rawLimit !== 'number') {
    return { used, limit: null, remaining: null, state: 'unknown', isUnlimited: false };
  }
  const remaining =
    used === null
      ? null
      : typeof rawRemaining === 'number'
      ? rawRemaining
      : Math.max(0, rawLimit - used);
  return { used, limit: rawLimit, remaining, state: 'finite', isUnlimited: false };
}

/**
 * Returns static example usage status for preview screens without live backend.
 */
export function getExampleUsageStatus(): NormalizedUsage {
  return {
    plan: 'Pro Plan',
    planKnown: true,
    comparison: { used: 3, limit: 20, remaining: 17, state: 'finite', isUnlimited: false },
    followUp: { used: 5, limit: 50, remaining: 45, state: 'finite', isUnlimited: false },
    refresh: { used: 1, limit: 10, remaining: 9, state: 'finite', isUnlimited: false },
    dailyQueries: 3,
    dailyLimit: 20,
    resetAt: 'Midnight UTC',
  };
}
