import React from 'react';
import { QueryClient } from '@tanstack/react-query';
import { PersistQueryClientProvider } from '@tanstack/react-query-persist-client';
import { createAsyncStoragePersister } from '@tanstack/query-async-storage-persister';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      gcTime: 1000 * 60 * 60 * 24 * 7, // 7 days
      staleTime: 1000 * 60 * 5, // 5 minutes
      retry: (failureCount, error: any) => {
        // Retry transient GET failures twice
        if (failureCount < 2) {
          if (!error?.statusCode || error.statusCode >= 500 || error.statusCode === 0) {
            return true;
          }
        }
        return false;
      },
    },
    mutations: {
      retry: false, // Never retry mutations automatically
    },
  },
});

const asyncStoragePersister = createAsyncStoragePersister({
  storage: AsyncStorage,
  key: 'SIDEBY_QUERY_CACHE_V2',
});

export function QueryProvider({ children }: { children: React.ReactNode }) {
  return (
    <PersistQueryClientProvider
      client={queryClient}
      persistOptions={{
        persister: asyncStoragePersister,
        maxAge: 1000 * 60 * 60 * 24 * 7, // 7 days
        dehydrateOptions: {
          shouldDehydrateQuery: (query) => {
            if (query.state.status !== 'success' || query.state.fetchStatus !== 'idle') {
              return false;
            }

            // Only persist completed comparison details, history, aggregated sources, and usage
            const queryKey = query.queryKey[0];
            if (queryKey === 'history' || queryKey === 'sources' || queryKey === 'usage') {
              return true;
            }
            if (queryKey === 'comparisonDetail') {
              const state = query.state.data as any;
              return state?.status === 'completed';
            }
            return false;
          },
        },
      }}
    >
      {children}
    </PersistQueryClientProvider>
  );
}
