import { z } from 'zod';

export const ComparisonHistoryItemSchema = z.object({
  id: z.string(),
  query: z.string(),
  slug: z.string().optional().default(''),
  status: z.enum(['queued', 'running', 'completed', 'failed']),
  progress: z.number().default(0),
  updatedAt: z.string(),
  summary: z.string().nullable().optional(),
  entityA: z.string().nullable().optional(),
  entityB: z.string().nullable().optional(),
  sourceCount: z.number().nullable().optional(),
  queryCategory: z.string().nullable().optional(),
  visibility: z.enum(['private', 'team', 'public']).optional().default('private'),
  isFavorited: z.boolean().optional().default(false),
  folder: z.string().nullable().optional(),
  tags: z.array(z.string()).optional().default([]),
  canonicalSlug: z.string().nullable().optional(),
  reusedFromId: z.string().nullable().optional(),
});

export type ComparisonHistoryItem = z.infer<typeof ComparisonHistoryItemSchema>;

export const ComparisonFactSchema = z.object({
  entity: z.enum(['a', 'b']),
  label: z.string(),
  value: z.string(),
  source: z.string().nullable().optional(),
  sourceUrl: z.string().nullable().optional(),
  sourceTitle: z.string().nullable().optional(),
  confidence: z.number().nullable().optional(),
  freshness: z.string().nullable().optional(),
});

export type ComparisonFact = z.infer<typeof ComparisonFactSchema>;

export const CategorySchema = z.object({
  name: z.string(),
  winner: z.enum(['a', 'b', 'tie']).nullable().optional(),
  verdict: z.string().nullable().optional(),
  facts: z.array(ComparisonFactSchema).default([]),
});

export type Category = z.infer<typeof CategorySchema>;

export const ComparisonSourceSchema = z.object({
  title: z.string(),
  url: z.string(),
  reliability: z.string().nullable().optional(),
  fetchedAt: z.string().nullable().optional(),
  confidence: z.number().nullable().optional(),
  summary: z.string().nullable().optional(),
});

export type ComparisonSource = z.infer<typeof ComparisonSourceSchema>;

export const ComparisonDimensionSchema = z.object({
  subject: z.string(),
  a: z.number(),
  b: z.number(),
  fullMark: z.number().optional().default(10),
  weight: z.number().optional().default(1.0),
});

export type ComparisonDimension = z.infer<typeof ComparisonDimensionSchema>;

export const ComparisonDataSchema = z.object({
  slug: z.string().optional().default(''),
  query: z.string().optional().default(''),
  context: z.string().optional().default(''),
  entities: z.object({
    a: z.object({
      name: z.string(),
      subtitle: z.string().optional().default(''),
      mark: z.string().optional().default('A'),
      hex: z.string().optional().default('#FF9B73'),
    }),
    b: z.object({
      name: z.string(),
      subtitle: z.string().optional().default(''),
      mark: z.string().optional().default('B'),
      hex: z.string().optional().default('#6ED9E6'),
    }),
  }),
  sourceCount: z.number().optional().default(0),
  updatedAt: z.string().optional().default(''),
  verdict: z.object({
    bestOverall: z.string().nullable().optional(),
    bestValue: z.string().nullable().optional(),
    summary: z.string().nullable().optional(),
    winner: z.string().nullable().optional(),
    confidence: z.number().nullable().optional(),
  }).nullable().optional(),
  dimensions: z.array(ComparisonDimensionSchema).optional().default([]),
  consensus: z.array(z.string()).optional().default([]),
  contradictions: z.array(z.string()).optional().default([]),
  categories: z.array(CategorySchema).optional().default([]),
  sources: z.array(ComparisonSourceSchema).optional().default([]),
});

export type ComparisonData = z.infer<typeof ComparisonDataSchema>;

export const ComparisonActivityStepSchema = z.object({
  id: z.string(),
  task: z.string(),
  stepName: z.string(),
  status: z.string(),
  startedAt: z.string().nullable().optional(),
  completedAt: z.string().nullable().optional(),
  durationMs: z.number().nullable().optional(),
  inputSummary: z.string().nullable().optional(),
  outputSummary: z.string().nullable().optional(),
  error: z.string().nullable().optional(),
  model: z.string().nullable().optional(),
});

export type ComparisonActivityStep = z.infer<typeof ComparisonActivityStepSchema>;

export const ComparisonJobSchema = z.object({
  id: z.string(),
  status: z.enum(['queued', 'running', 'completed', 'failed']),
  progress: z.number().min(0).max(100),
  activeStep: z.number().optional().default(0),
  query: z.string(),
  result: ComparisonDataSchema.nullable().optional(),
  error: z.string().nullable().optional(),
  failedStep: z.string().nullable().optional(),
  retryable: z.boolean().optional(),
  visibility: z.enum(['private', 'team', 'public']).optional(),
  isFavorited: z.boolean().optional(),
  sourcesFound: z.number().optional(),
  factsExtracted: z.number().optional(),
  dimensionsScored: z.number().optional(),
  activity: z.array(ComparisonActivityStepSchema).optional(),
  reuseSource: z.object({
    sourceId: z.string().nullable().optional(),
    type: z.enum(['memory', 'database', 'stale']).optional(),
    label: z.string().optional(),
    confidence: z.number().nullable().optional(),
  }).optional(),
});

export type ComparisonJob = z.infer<typeof ComparisonJobSchema>;

export const FollowUpResponseSchema = z.object({
  answer: z.string(),
  evidence: z.array(
    z.object({
      id: z.string().optional(),
      label: z.string().optional(),
      value: z.string().optional(),
      confidence: z.number().nullable().optional(),
      sourceTitle: z.string().nullable().optional(),
      sourceUrl: z.string().nullable().optional(),
    })
  ).optional().default([]),
  confidence: z.number().nullable().optional(),
});

export type FollowUpResponse = z.infer<typeof FollowUpResponseSchema>;

export const UsageItemSchema = z.object({
  used: z.number(),
  limit: z.number().nullable().optional(),
  remaining: z.number().nullable().optional(),
});

export type UsageItem = z.infer<typeof UsageItemSchema>;

export const UsageStatusSchema = z.object({
  plan: z.string().optional(),
  limits: z.record(z.any()).optional(),
  usage: z.record(z.any()).optional(),
  billingConfigured: z.boolean().optional(),
  message: z.string().nullable().optional(),
});

export type UsageStatus = z.infer<typeof UsageStatusSchema>;

export const TaxonomyCategorySchema = z.object({
  id: z.string().optional(),
  name: z.string().optional(),
  label: z.string().optional(),
  shortLabel: z.string().optional(),
  description: z.string().optional(),
  guidelines: z.array(z.string()).optional(),
  rules: z.array(z.string()).optional(),
  examples: z.array(z.string()).optional(),
  dimensions: z.array(z.any()).optional(),
});

export type TaxonomyCategory = z.infer<typeof TaxonomyCategorySchema>;
