export type StageKey =
  | 'parse'
  | 'search'
  | 'extraction'
  | 'dimensions'
  | 'facts'
  | 'scoring'
  | 'verdict'
  | 'finalize';

export interface StageInfo {
  key: StageKey;
  label: string;
  description: string;
  threshold: number; // percentage min threshold (0-100)
}

export const RESEARCH_STAGES: StageInfo[] = [
  { key: 'parse', label: 'Parsing Query', description: 'Extracting entity A, entity B, and intended use case', threshold: 0 },
  { key: 'search', label: 'Gathering Sources', description: 'Searching live web indexes and benchmark databases', threshold: 15 },
  { key: 'extraction', label: 'Extracting Evidence', description: 'Parsing source contents and verifying citation validity', threshold: 30 },
  { key: 'dimensions', label: 'Building Dimensions', description: 'Establishing criteria categories for fair comparison', threshold: 45 },
  { key: 'facts', label: 'Synthesizing Facts', description: 'Aggregating metric data points and confidence metrics', threshold: 60 },
  { key: 'scoring', label: 'Calculating Scores', description: 'Applying weighted scoring algorithms across dimensions', threshold: 75 },
  { key: 'verdict', label: 'Formulating Verdict', description: 'Structuring executive recommendation and key tradeoffs', threshold: 90 },
  { key: 'finalize', label: 'Finalizing Brief', description: 'Formatting citation links and caching brief data', threshold: 98 },
];

export interface ComparisonSummary {
  id: string;
  query: string;
  entityA: string;
  entityB: string;
  useCase?: string;
  teamContext?: string;
  status: 'running' | 'completed' | 'failed';
  progress: number; // 0 to 100
  winner?: 'A' | 'B' | 'TIE';
  verdictTitle?: string;
  createdAt: string;
  updatedAt: string;
}

export interface FactRow {
  dimension: string;
  entityAFact: string;
  entityBFact: string;
  winner?: 'A' | 'B' | 'TIE';
  confidenceScore: number; // 0 to 1.0
  freshnessDays?: number;
}

export interface EvidenceCategory {
  category: string;
  winner: 'A' | 'B' | 'TIE';
  facts: FactRow[];
}

export interface ComparisonSource {
  id: string;
  url: string;
  normalizedUrl: string;
  title: string;
  domain: string;
  reliabilityScore: number; // 0 to 1.0
  snippet: string;
  fetchedAt: string;
}

export interface ComparisonResult {
  id: string;
  query: string;
  entityA: string;
  entityB: string;
  useCase?: string;
  teamContext?: string;
  status: 'running' | 'completed' | 'failed';
  progress: number;
  currentStage: StageKey;
  errorMessage?: string;
  verdict?: {
    winner: 'A' | 'B' | 'TIE';
    title: string;
    summary: string;
    scoreA: number;
    scoreB: number;
    consensuses: string[];
    contradictions: string[];
  };
  evidenceCategories?: EvidenceCategory[];
  sources?: ComparisonSource[];
  createdAt: string;
  updatedAt: string;
}

export interface UsageStatus {
  planName: string;
  dailyQueriesUsed: number;
  dailyQueriesLimit: number;
  resetAt: string;
}

export interface ApiError {
  statusCode: number;
  message: string;
  code?: string;
  retryAfter?: number;
  retryable?: boolean;
}
