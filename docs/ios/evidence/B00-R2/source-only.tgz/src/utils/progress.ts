import { StageKey, RESEARCH_STAGES, StageInfo } from '../types/api';

export function getStageFromProgress(progress: number): StageInfo {
  const normalizedProgress = Math.max(0, Math.min(100, progress));
  let currentStage = RESEARCH_STAGES[0];

  for (let i = RESEARCH_STAGES.length - 1; i >= 0; i--) {
    if (normalizedProgress >= RESEARCH_STAGES[i].threshold) {
      currentStage = RESEARCH_STAGES[i];
      break;
    }
  }

  return currentStage;
}

export function parseEntitiesFromQuery(query: string): { entityA: string; entityB: string; useCase: string } {
  // Parsing query format: "A vs B for {use case}"
  const vsIndex = query.toLowerCase().indexOf(' vs ');
  if (vsIndex === -1) {
    return { entityA: query.trim(), entityB: '', useCase: '' };
  }

  const entityA = query.substring(0, vsIndex).trim();
  const rest = query.substring(vsIndex + 4).trim();
  const forIndex = rest.toLowerCase().indexOf(' for ');

  if (forIndex === -1) {
    return { entityA, entityB: rest.trim(), useCase: '' };
  }

  const entityB = rest.substring(0, forIndex).trim();
  const useCase = rest.substring(forIndex + 5).trim();

  return { entityA, entityB, useCase };
}

export function composeQuery(entityA: string, entityB: string, useCase?: string, teamContext?: string): string {
  let query = `${entityA.trim()} vs ${entityB.trim()}`;
  if (useCase && useCase.trim().length > 0) {
    query += ` for ${useCase.trim()}`;
  }
  if (teamContext && teamContext.trim().length > 0) {
    query += `. Team context: ${teamContext.trim()}`;
  }
  return query;
}
