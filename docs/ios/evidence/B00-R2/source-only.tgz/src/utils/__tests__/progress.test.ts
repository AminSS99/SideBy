import { getStageFromProgress, parseEntitiesFromQuery, composeQuery } from '../progress';

describe('Progress and Stage Mapping Utilities', () => {

  it('maps progress percentage to the correct 8 research stages', () => {
    expect(getStageFromProgress(0).key).toBe('parse');
    expect(getStageFromProgress(10).key).toBe('parse');
    expect(getStageFromProgress(20).key).toBe('search');
    expect(getStageFromProgress(35).key).toBe('extraction');
    expect(getStageFromProgress(50).key).toBe('dimensions');
    expect(getStageFromProgress(65).key).toBe('facts');
    expect(getStageFromProgress(80).key).toBe('scoring');
    expect(getStageFromProgress(92).key).toBe('verdict');
    expect(getStageFromProgress(99).key).toBe('finalize');
  });

  it('correctly parses entity A, entity B, and use case from query string', () => {
    const parsed = parseEntitiesFromQuery('PostgreSQL vs MongoDB for high write throughput');
    expect(parsed.entityA).toBe('PostgreSQL');
    expect(parsed.entityB).toBe('MongoDB');
    expect(parsed.useCase).toBe('high write throughput');
  });

  it('composes full backend query string with entities, use case, and team context', () => {
    const fullQuery = composeQuery('React', 'Vue', 'mobile dashboard', 'Small team with 3 devs');
    expect(fullQuery).toBe('React vs Vue for mobile dashboard. Team context: Small team with 3 devs');
  });

  it('handles query composition without optional fields', () => {
    const query = composeQuery('iOS', 'Android');
    expect(query).toBe('iOS vs Android');
  });
});
