import React, { useState } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  Pressable,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';
import { useSignIn, useOAuth } from '@clerk/expo';
import { useRouter, Link } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { BackgroundTexture } from '../../src/components/common/BackgroundTexture';
import { Colors } from '../../src/theme/colors';
import { Typography } from '../../src/theme/typography';
import { triggerHaptic } from '../../src/theme/haptics';
import { GlassSurface } from '../../src/components/common/GlassSurface';

export default function SignInScreen() {
  const { signIn, setActive, isLoaded } = useSignIn() as any;
  const router = useRouter();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const { startOAuthFlow: startGoogleOAuth } = useOAuth({ strategy: 'oauth_google' });
  const { startOAuthFlow: startAppleOAuth } = useOAuth({ strategy: 'oauth_apple' });

  const handleEmailSignIn = async () => {
    if (!isLoaded || !signIn) return;
    if (!email || !password) {
      setErrorMsg('Please provide both email and password.');
      return;
    }

    setLoading(true);
    setErrorMsg('');
    triggerHaptic.lightImpact();

    try {
      const result = await signIn.create({
        identifier: email.trim(),
        password,
      });

      if (result.status === 'complete') {
        await setActive({ session: result.createdSessionId });
        triggerHaptic.successNotification();
        router.replace('/(tabs)');
      } else {
        setErrorMsg('Authentication incomplete. Please check credentials.');
      }
    } catch (err: any) {
      triggerHaptic.errorNotification();
      setErrorMsg(err?.errors?.[0]?.message || 'Sign in failed. Check email and password.');
    } finally {
      setLoading(false);
    }
  };

  const handleOAuthSignIn = async (provider: 'google' | 'apple') => {
    triggerHaptic.mediumImpact();
    setLoading(true);
    setErrorMsg('');

    try {
      const oauthFlow = provider === 'google' ? startGoogleOAuth : startAppleOAuth;
      const { createdSessionId, setActive: setOAuthActive } = await oauthFlow();

      if (createdSessionId && setOAuthActive) {
        await setOAuthActive({ session: createdSessionId });
        triggerHaptic.successNotification();
        router.replace('/(tabs)');
      }
    } catch (err: any) {
      triggerHaptic.errorNotification();
      setErrorMsg(err?.message || `${provider} authentication could not be completed.`);
    } finally {
      setLoading(false);
    }
  };

  const handleContinueAsGuest = async () => {
    triggerHaptic.selection();
    await AsyncStorage.setItem('SIDEBY_GUEST_MODE', 'true');
    router.replace('/(tabs)');
  };

  return (
    <BackgroundTexture>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.container}
      >
        <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">
          <View style={styles.headerSection}>
            <Text style={styles.brandTitle}>SideBy</Text>
            <Text style={styles.subtitle}>Autonomous AI Decision Engine</Text>
          </View>

          <GlassSurface style={styles.card}>
            <Text style={styles.cardTitle}>Sign In</Text>

            {errorMsg ? (
              <View style={styles.errorBanner}>
                <Text style={styles.errorText}>{errorMsg}</Text>
              </View>
            ) : null}

            {/* Email Input */}
            <Text style={styles.inputLabel}>EMAIL ADDRESS</Text>
            <TextInput
              style={styles.input}
              placeholder="engineer@company.com"
              placeholderTextColor={Colors.muted}
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
              editable={!loading}
            />

            {/* Password Input */}
            <Text style={styles.inputLabel}>PASSWORD</Text>
            <TextInput
              style={styles.input}
              placeholder="••••••••••••"
              placeholderTextColor={Colors.muted}
              value={password}
              onChangeText={setPassword}
              secureTextEntry
              editable={!loading}
            />

            {/* Sign In Button */}
            <Pressable
              style={[styles.primaryButton, loading && styles.buttonDisabled]}
              onPress={handleEmailSignIn}
              disabled={loading}
            >
              {loading ? (
                <ActivityIndicator color={Colors.background} />
              ) : (
                <Text style={styles.primaryButtonText}>Sign In</Text>
              )}
            </Pressable>

            <View style={styles.dividerRow}>
              <View style={styles.dividerLine} />
              <Text style={styles.dividerText}>OR CONTINUE WITH</Text>
              <View style={styles.dividerLine} />
            </View>

            {/* Native OAuth Buttons */}
            <View style={styles.oauthContainer}>
              <Pressable
                style={styles.oauthButton}
                onPress={() => handleOAuthSignIn('apple')}
                disabled={loading}
              >
                <Text style={styles.oauthButtonText}> Sign in with Apple</Text>
              </Pressable>

              <Pressable
                style={styles.oauthButton}
                onPress={() => handleOAuthSignIn('google')}
                disabled={loading}
              >
                <Text style={styles.oauthButtonText}>G  Sign in with Google</Text>
              </Pressable>
            </View>

            {/* Guest Exploration Option */}
            <Pressable
              style={styles.guestButton}
              onPress={handleContinueAsGuest}
            >
              <Text style={styles.guestButtonText}>Explore as Guest →</Text>
            </Pressable>
          </GlassSurface>

          <View style={styles.footerRow}>
            <Text style={styles.footerText}>Don't have an account? </Text>
            <Link href="/(auth)/sign-up" asChild>
              <Pressable>
                <Text style={styles.linkText}>Sign Up</Text>
              </Pressable>
            </Link>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </BackgroundTexture>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 24,
    paddingTop: 60,
  },
  headerSection: {
    alignItems: 'center',
    marginBottom: 32,
  },
  brandTitle: {
    ...Typography.h1,
    fontSize: 36,
    color: Colors.ivory,
    letterSpacing: -1,
    marginBottom: 6,
  },
  subtitle: {
    ...Typography.bodySm,
    color: Colors.muted,
    letterSpacing: 0.5,
  },
  card: {
    borderRadius: 24,
    padding: 24,
    boxShadow: '0 20px 46px rgba(0, 0, 0, 0.28)',
  },
  cardTitle: {
    ...Typography.h2,
    color: Colors.ivory,
    marginBottom: 20,
  },
  errorBanner: {
    backgroundColor: 'rgba(255, 59, 48, 0.15)',
    borderWidth: 1,
    borderColor: Colors.error,
    borderRadius: 12,
    padding: 12,
    marginBottom: 16,
  },
  errorText: {
    color: Colors.error,
    fontSize: 13,
    fontWeight: '500',
  },
  inputLabel: {
    color: Colors.muted,
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 0.8,
    marginBottom: 8,
  },
  input: {
    backgroundColor: Colors.raisedTitanium,
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 14,
    color: Colors.ivory,
    fontSize: 15,
    borderWidth: 1,
    borderColor: Colors.borderLight,
    marginBottom: 16,
  },
  primaryButton: {
    backgroundColor: Colors.ivory,
    borderRadius: 16,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 8,
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  primaryButtonText: {
    color: Colors.background,
    fontSize: 16,
    fontWeight: '700',
  },
  dividerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 20,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: Colors.border,
  },
  dividerText: {
    color: Colors.muted,
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 1,
    paddingHorizontal: 12,
  },
  oauthContainer: {
    gap: 10,
  },
  oauthButton: {
    backgroundColor: Colors.raisedTitanium,
    borderRadius: 14,
    paddingVertical: 14,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.borderLight,
  },
  oauthButtonText: {
    color: Colors.ivory,
    fontSize: 15,
    fontWeight: '600',
  },
  guestButton: {
    marginTop: 16,
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.12)',
    backgroundColor: 'rgba(255, 255, 255, 0.04)',
  },
  guestButtonText: {
    color: Colors.cyan,
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
  footerRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 28,
  },
  footerText: {
    color: Colors.muted,
    fontSize: 14,
  },
  linkText: {
    color: Colors.copper,
    fontSize: 14,
    fontWeight: '700',
  },
});
