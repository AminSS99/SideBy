import React, { useState } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  Pressable,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';
import { useSignUp } from '@clerk/expo';
import { useRouter, Link } from 'expo-router';
import { BackgroundTexture } from '../../src/components/common/BackgroundTexture';
import { Colors } from '../../src/theme/colors';
import { Typography } from '../../src/theme/typography';
import { triggerHaptic } from '../../src/theme/haptics';
import { GlassSurface } from '../../src/components/common/GlassSurface';

export default function SignUpScreen() {
  const { signUp, setActive, isLoaded } = useSignUp() as any;
  const router = useRouter();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [pendingVerification, setPendingVerification] = useState(false);
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleSignUp = async () => {
    if (!isLoaded || !signUp) return;
    if (!email || !password) {
      setErrorMsg('Please enter email and password.');
      return;
    }

    setLoading(true);
    setErrorMsg('');
    triggerHaptic.lightImpact();

    try {
      await signUp.create({
        emailAddress: email.trim(),
        password,
      });

      await signUp.prepareEmailAddressVerification({ strategy: 'email_code' });
      setPendingVerification(true);
    } catch (err: any) {
      triggerHaptic.errorNotification();
      setErrorMsg(err?.errors?.[0]?.message || 'Sign up failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyCode = async () => {
    if (!isLoaded || !signUp) return;
    if (!code) {
      setErrorMsg('Please enter verification code.');
      return;
    }

    setLoading(true);
    setErrorMsg('');
    triggerHaptic.lightImpact();

    try {
      const completeSignUp = await signUp.attemptEmailAddressVerification({
        code: code.trim(),
      });

      if (completeSignUp.status === 'complete') {
        await setActive({ session: completeSignUp.createdSessionId });
        triggerHaptic.successNotification();
        router.replace('/(tabs)');
      } else {
        setErrorMsg('Verification incomplete.');
      }
    } catch (err: any) {
      triggerHaptic.errorNotification();
      setErrorMsg(err?.errors?.[0]?.message || 'Invalid code.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <BackgroundTexture>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.container}
      >
        <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">
          <View style={styles.headerSection}>
            <Text style={styles.brandTitle}>SideBy</Text>
            <Text style={styles.subtitle}>Create your account</Text>
          </View>

          <GlassSurface style={styles.card}>
            <Text style={styles.cardTitle}>
              {pendingVerification ? 'Verify Email' : 'Sign Up'}
            </Text>

            {errorMsg ? (
              <View style={styles.errorBanner}>
                <Text style={styles.errorText}>{errorMsg}</Text>
              </View>
            ) : null}

            {!pendingVerification ? (
              <>
                <Text style={styles.inputLabel}>EMAIL ADDRESS</Text>
                <TextInput
                  style={styles.input}
                  placeholder="you@company.com"
                  placeholderTextColor={Colors.muted}
                  value={email}
                  onChangeText={setEmail}
                  keyboardType="email-address"
                  autoCapitalize="none"
                />

                <Text style={styles.inputLabel}>PASSWORD</Text>
                <TextInput
                  style={styles.input}
                  placeholder="••••••••••••"
                  placeholderTextColor={Colors.muted}
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry
                />

                <Pressable
                  style={[styles.primaryButton, loading && styles.buttonDisabled]}
                  onPress={handleSignUp}
                  disabled={loading}
                >
                  {loading ? (
                    <ActivityIndicator color={Colors.background} />
                  ) : (
                    <Text style={styles.primaryButtonText}>Continue</Text>
                  )}
                </Pressable>
              </>
            ) : (
              <>
                <Text style={styles.instructionText}>
                  We sent a 6-digit verification code to {email}.
                </Text>
                <Text style={styles.inputLabel}>VERIFICATION CODE</Text>
                <TextInput
                  style={styles.input}
                  placeholder="123456"
                  placeholderTextColor={Colors.muted}
                  value={code}
                  onChangeText={setCode}
                  keyboardType="number-pad"
                />

                <Pressable
                  style={[styles.primaryButton, loading && styles.buttonDisabled]}
                  onPress={handleVerifyCode}
                  disabled={loading}
                >
                  {loading ? (
                    <ActivityIndicator color={Colors.background} />
                  ) : (
                    <Text style={styles.primaryButtonText}>Verify & Complete</Text>
                  )}
                </Pressable>
              </>
            )}
          </GlassSurface>

          <View style={styles.footerRow}>
            <Text style={styles.footerText}>Already have an account? </Text>
            <Link href="/(auth)/sign-in" asChild>
              <Pressable>
                <Text style={styles.linkText}>Sign In</Text>
              </Pressable>
            </Link>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </BackgroundTexture>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 24,
    paddingTop: 60,
  },
  headerSection: {
    alignItems: 'center',
    marginBottom: 32,
  },
  brandTitle: {
    ...Typography.h1,
    fontSize: 36,
    color: Colors.ivory,
    letterSpacing: -1,
    marginBottom: 6,
  },
  subtitle: {
    ...Typography.bodySm,
    color: Colors.muted,
  },
  card: {
    borderRadius: 24,
    padding: 24,
    boxShadow: '0 20px 46px rgba(0, 0, 0, 0.28)',
  },
  cardTitle: {
    ...Typography.h2,
    color: Colors.ivory,
    marginBottom: 20,
  },
  errorBanner: {
    backgroundColor: 'rgba(255, 59, 48, 0.15)',
    borderWidth: 1,
    borderColor: Colors.error,
    borderRadius: 12,
    padding: 12,
    marginBottom: 16,
  },
  errorText: {
    color: Colors.error,
    fontSize: 13,
  },
  instructionText: {
    color: Colors.muted,
    fontSize: 14,
    marginBottom: 16,
  },
  inputLabel: {
    color: Colors.muted,
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 0.8,
    marginBottom: 8,
  },
  input: {
    backgroundColor: Colors.raisedTitanium,
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 14,
    color: Colors.ivory,
    fontSize: 15,
    borderWidth: 1,
    borderColor: Colors.borderLight,
    marginBottom: 16,
  },
  primaryButton: {
    backgroundColor: Colors.ivory,
    borderRadius: 16,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 8,
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  primaryButtonText: {
    color: Colors.background,
    fontSize: 16,
    fontWeight: '700',
  },
  footerRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 28,
  },
  footerText: {
    color: Colors.muted,
    fontSize: 14,
  },
  linkText: {
    color: Colors.copper,
    fontSize: 14,
    fontWeight: '700',
  },
});
