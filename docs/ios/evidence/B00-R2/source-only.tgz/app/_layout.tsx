import React, { useEffect } from 'react';
import { Stack, useRouter, useSegments } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { useAuth } from '@clerk/expo';
import { AuthProvider } from '../src/providers/AuthProvider';
import { QueryProvider } from '../src/providers/QueryProvider';
import { NetworkProvider } from '../src/providers/NetworkProvider';
import { Colors } from '../src/theme/colors';
import { AUTH_REQUIRED } from '../src/config/features';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import AsyncStorage from '@react-native-async-storage/async-storage';

function ProtectedNavigation({ children }: { children: React.ReactNode }) {
  const { isLoaded, isSignedIn } = useAuth();
  const segments = useSegments();
  const router = useRouter();
  const [isGuest, setIsGuest] = React.useState<boolean | null>(null);

  React.useEffect(() => {
    AsyncStorage.getItem('SIDEBY_GUEST_MODE').then((val) => {
      setIsGuest(val !== 'false');
    });
  }, []);

  React.useEffect(() => {
    const inAuthGroup = segments[0] === '(auth)';

    if (!isLoaded || isGuest === null) return;

    if (!isSignedIn && !isGuest && !inAuthGroup) {
      router.replace('/(auth)/sign-in');
    } else if (isSignedIn && inAuthGroup) {
      router.replace('/(tabs)');
    }
  }, [isLoaded, isSignedIn, isGuest, segments, router]);

  return <>{children}</>;
}


function BypassedNavigation({ children }: { children: React.ReactNode }) {
  const segments = useSegments();
  const router = useRouter();

  useEffect(() => {
    if (segments[0] === '(auth)') {
      router.replace('/(tabs)');
    }
  }, [segments, router]);

  return <>{children}</>;
}

function AppStack() {
  return (
    <>
      <StatusBar style="light" />
      <Stack
        screenOptions={{
          headerShown: false,
          contentStyle: { backgroundColor: Colors.background },
          animation: 'fade',
        }}
      >
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen name="(auth)" options={{ headerShown: false }} />
        <Stack.Screen
          name="comparison/[id]"
          options={{
            headerShown: false,
            presentation: 'card',
          }}
        />
        <Stack.Screen
          name="account"
          options={{
            headerShown: false,
            presentation: 'modal',
          }}
        />
      </Stack>
    </>
  );
}

export default function RootLayout() {
  return (
    <GestureHandlerRootView style={{ flex: 1, backgroundColor: Colors.background }}>
      <SafeAreaProvider>
        <NetworkProvider>
          <QueryProvider>
            <AuthProvider>
              {AUTH_REQUIRED ? (
                <ProtectedNavigation>
                  <AppStack />
                </ProtectedNavigation>
              ) : (
                <BypassedNavigation>
                  <AppStack />
                </BypassedNavigation>
              )}
            </AuthProvider>
          </QueryProvider>
        </NetworkProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
