import React, { useState, useEffect, useRef } from 'react';
import {
  StyleSheet,
  View,
  Text,
  ScrollView,
  Pressable,
  ActivityIndicator,
  AppState,
  AppStateStatus,
  Share,
  Alert,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { SymbolView } from 'expo-symbols';
import { BackgroundTexture } from '../../src/components/common/BackgroundTexture';
import { ResearchOrbPipeline } from '../../src/components/comparison/ResearchOrbPipeline';
import { InteractiveVerdictCard } from '../../src/components/comparison/InteractiveVerdictCard';
import { ContenderComparisonScrubber } from '../../src/components/comparison/ContenderComparisonScrubber';
import { ExpandableEvidenceCard } from '../../src/components/comparison/ExpandableEvidenceCard';
import { DimensionScoreBar } from '../../src/components/comparison/DimensionScoreBar';
import { ConsensusCallout } from '../../src/components/comparison/ConsensusCallout';
import { FollowUpSheet } from '../../src/components/comparison/FollowUpSheet';
import { SourceCard } from '../../src/components/comparison/SourceCard';
import { Colors } from '../../src/theme/colors';
import { Typography } from '../../src/theme/typography';
import {
  fetchComparisonDetail,
  manageComparison,
  submitFollowUpQuestion,
  exportComparison,
  toggleFavorite,
  submitFeedback,
  isExampleId,
} from '../../src/api/comparisons';
import { jobToViewModel } from '../../src/api/adapters';
import { triggerHaptic } from '../../src/theme/haptics';
import { useNetwork } from '../../src/providers/NetworkProvider';
import { FollowUpResponse } from '../../src/types/schemas';
import { LiquidGlass } from '../../src/components/common/LiquidGlass';
import { PressableScale } from '../../src/components/common/PressableScale';

export default function ComparisonDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const queryClient = useQueryClient();
  const { isOffline } = useNetwork();
  const isExample = isExampleId(id || '');

  const [followUpHistory, setFollowUpHistory] = useState<
    Array<{ question: string; response: FollowUpResponse }>
  >([]);
  const [appState, setAppState] = useState<AppStateStatus>('active');
  const [isFavorited, setIsFavorited] = useState(false);
  const [isFavoriteMutating, setIsFavoriteMutating] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  // Rating submission states: idle | pending | confirmed | error
  const [ratingStatus, setRatingStatus] = useState<'idle' | 'pending' | 'confirmed' | 'error'>('idle');
  const [confirmedRating, setConfirmedRating] = useState<number | null>(null);
  const [ratingError, setRatingError] = useState<string | null>(null);

  useEffect(() => {
    const subscription = AppState.addEventListener('change', (nextAppState) => {
      setAppState(nextAppState);
    });
    return () => subscription.remove();
  }, []);

  const {
    data: jobData,
    isLoading,
    isError,
    error,
    refetch,
  } = useQuery({
    queryKey: ['comparisonDetail', id],
    queryFn: () => fetchComparisonDetail(id!),
    enabled: Boolean(id),
    refetchInterval: (query) => {
      const data = query.state.data;
      if (
        (data?.status === 'running' || data?.status === 'queued') &&
        !isOffline &&
        appState === 'active'
      ) {
        return 2000;
      }
      return false;
    },
  });

  useEffect(() => {
    if (jobData) {
      setIsFavorited(Boolean(jobData.isFavorited));
    }
  }, [jobData]);

  // Management mutation (retry/refresh): invalidates and refetches rather than corrupting cache with acknowledgement
  const manageMutation = useMutation({
    mutationFn: (action: 'refresh' | 'retry') => manageComparison(id!, action),
    onSuccess: async () => {
      triggerHaptic.successNotification();
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ['comparisonDetail', id] }),
        queryClient.invalidateQueries({ queryKey: ['history'] }),
        queryClient.invalidateQueries({ queryKey: ['usage'] }),
      ]);
      await refetch();
    },
    onError: (err: any) => {
      triggerHaptic.errorNotification();
      Alert.alert('Action Failed', err?.message || 'Unable to manage comparison.');
    },
  });

  const followUpMutation = useMutation({
    mutationFn: (question: string) => submitFollowUpQuestion(id!, question),
    onSuccess: (responsePayload, question) => {
      triggerHaptic.successNotification();
      setFollowUpHistory((prev) => [...prev, { question, response: responsePayload }]);
    },
    onError: (err: any) => {
      triggerHaptic.errorNotification();
      Alert.alert('Follow-up Failed', err?.message || 'Unable to process follow-up.');
    },
  });

  // Toggle favorite with serialization to prevent overlapping race conditions and rollback on error
  const handleToggleFavorite = async () => {
    if (isExample) {
      triggerHaptic.lightImpact();
      Alert.alert('Example Brief', 'Example comparisons cannot be favorited.');
      return;
    }
    if (isFavoriteMutating || isOffline) return;

    triggerHaptic.selection();
    setIsFavoriteMutating(true);
    const previousState = isFavorited;
    const nextState = !isFavorited;
    setIsFavorited(nextState);

    try {
      const res = await toggleFavorite(id!, nextState);
      setIsFavorited(res.isFavorited);
      queryClient.invalidateQueries({ queryKey: ['history'] });
    } catch {
      // Revert optimistic update on server error
      setIsFavorited(previousState);
      triggerHaptic.errorNotification();
    } finally {
      setIsFavoriteMutating(false);
    }
  };

  const handleExport = async () => {
    if (isOffline) return;
    triggerHaptic.mediumImpact();
    setIsExporting(true);
    try {
      const markdown = await exportComparison(id!, 'markdown');
      await Share.share({
        title: `${jobData?.query || 'SideBy Comparison'}`,
        message: markdown,
      });
    } catch {
      // Export dismissed or cancelled
    } finally {
      setIsExporting(false);
    }
  };

  // Safe rating submission with pending/confirmed/error distinction and race protection
  const handleRating = async (rating: number) => {
    if (isExample) {
      triggerHaptic.lightImpact();
      Alert.alert('Example Brief', 'Feedback is disabled on static examples.');
      return;
    }
    if (ratingStatus === 'pending' || isOffline) return;

    triggerHaptic.selection();
    setRatingStatus('pending');
    setRatingError(null);

    try {
      await submitFeedback(id!, rating);
      setConfirmedRating(rating);
      setRatingStatus('confirmed');
      triggerHaptic.successNotification();
    } catch (err: any) {
      setRatingStatus('error');
      setRatingError(err?.message || 'Failed to submit rating.');
      triggerHaptic.errorNotification();
    }
  };

  const handleRefresh = () => {
    if (isOffline || manageMutation.isPending) return;
    if (isExample) {
      Alert.alert('Example Brief', 'Static examples cannot be refreshed.');
      return;
    }
    triggerHaptic.lightImpact();
    manageMutation.mutate('refresh');
  };

  const handleRetry = () => {
    if (isOffline || manageMutation.isPending) return;
    if (isExample) {
      Alert.alert('Example Brief', 'Static examples cannot be retried.');
      return;
    }
    triggerHaptic.mediumImpact();
    manageMutation.mutate('retry');
  };

  if (isLoading) {
    return (
      <BackgroundTexture>
        <View style={styles.centerContainer}>
          <ActivityIndicator size="large" color={Colors.copper} />
          <Text style={styles.loadingText}>Synthesizing Comparison Brief...</Text>
        </View>
      </BackgroundTexture>
    );
  }

  if (isError || !jobData) {
    return (
      <BackgroundTexture>
        <View style={styles.centerContainer}>
          <Text style={styles.errorTitle}>Brief Unavailable</Text>
          <Text style={styles.errorSubtitle}>
            {(error as any)?.message || 'The requested comparison could not be loaded.'}
          </Text>
          <PressableScale style={styles.actionButton} onPress={() => refetch()}>
            <Text style={styles.actionButtonText}>Retry Loading</Text>
          </PressableScale>
        </View>
      </BackgroundTexture>
    );
  }

  const vm = jobToViewModel(jobData);
  const result = vm.result;

  const isRunning = vm.status === 'running' || vm.status === 'queued';
  const isFailed = vm.status === 'failed';
  const isCompleted = vm.status === 'completed';

  // Cited-evidence indicator: requires >= 2 sources and at least one official
  // or high-confidence citation. This describes citation presence, not an
  // independent claim-to-citation validation (no such rule is implemented).
  const hasCitedEvidence = Boolean(
    result?.sources &&
      result.sources.length >= 2 &&
      result.sources.some(
        (s) =>
          s.reliability === 'Official' ||
          (s.confidence !== null && s.confidence !== undefined && s.confidence >= 0.8)
      )
  );

  // Compute actual aggregated score across dimensions without hardcoded defaults
  const scoreA =
    result?.dimensions && result.dimensions.length > 0
      ? Math.round(
          (result.dimensions.reduce((acc, d) => acc + (d.a / (d.fullMark || 10)) * 100, 0) /
            result.dimensions.length)
        )
      : 0;

  const scoreB =
    result?.dimensions && result.dimensions.length > 0
      ? Math.round(
          (result.dimensions.reduce((acc, d) => acc + (d.b / (d.fullMark || 10)) * 100, 0) /
            result.dimensions.length)
        )
      : 0;

  return (
    <BackgroundTexture>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        contentInsetAdjustmentBehavior="automatic"
      >
        {isOffline && (
          <View style={styles.offlineBanner}>
            <Text style={styles.offlineText}>
              ⚡ Offline Mode — Displaying cached brief. Actions disabled.
            </Text>
          </View>
        )}

        {isExample && (
          <View style={styles.exampleBanner}>
            <Text style={styles.exampleText}>
              🧪 Static Example Brief — Read-only illustrative data. Live mutations are disabled.
            </Text>
          </View>
        )}

        {/* Entities Title Header with Action Buttons */}
        <View style={styles.titleHeader}>
          <View style={styles.topActionRow}>
            <View style={styles.categoryBadge}>
              <Text style={styles.categoryBadgeText}>
                {hasCitedEvidence ? 'CITED EVIDENCE' : 'PRELIMINARY SYNTHESIS'}
              </Text>
            </View>

            <View style={styles.headerIcons}>
              {/* Star Favorite */}
              <PressableScale
                haptic="selection"
                activeScale={0.90}
                onPress={handleToggleFavorite}
                disabled={isFavoriteMutating || isExample}
                accessibilityLabel="Favorite comparison"
                testID="detail-favorite-button"
              >
                <LiquidGlass
                  borderRadius={18}
                  intensity={55}
                  specularColor={isFavorited ? Colors.copper : 'rgba(255, 255, 255, 0.35)'}
                  glowColor={isFavorited ? Colors.copperSoft : undefined}
                  style={styles.iconGlass}
                  contentStyle={styles.iconGlassContent}
                >
                  <SymbolView
                    name={isFavorited ? 'star.fill' : 'star'}
                    tintColor={isFavorited ? Colors.copper : Colors.ivory}
                    size={18}
                  />
                </LiquidGlass>
              </PressableScale>

              {/* Export / Share */}
              <PressableScale
                haptic="medium"
                activeScale={0.90}
                onPress={handleExport}
                disabled={isExporting}
                accessibilityLabel="Export comparison"
              >
                <LiquidGlass
                  borderRadius={18}
                  intensity={55}
                  specularColor="rgba(255, 255, 255, 0.35)"
                  style={styles.iconGlass}
                  contentStyle={styles.iconGlassContent}
                >
                  {isExporting ? (
                    <ActivityIndicator size="small" color={Colors.ivory} />
                  ) : (
                    <SymbolView name="square.and.arrow.up" tintColor={Colors.ivory} size={18} />
                  )}
                </LiquidGlass>
              </PressableScale>

              {/* Refresh */}
              {!isOffline && isCompleted && !isExample && (
                <PressableScale
                  haptic="light"
                  activeScale={0.90}
                  onPress={handleRefresh}
                  disabled={manageMutation.isPending}
                  accessibilityLabel="Refresh comparison"
                >
                  <LiquidGlass
                    borderRadius={18}
                    intensity={55}
                    specularColor="rgba(255, 255, 255, 0.35)"
                    style={styles.iconGlass}
                    contentStyle={styles.iconGlassContent}
                  >
                    {manageMutation.isPending ? (
                      <ActivityIndicator size="small" color={Colors.ivory} />
                    ) : (
                      <SymbolView name="arrow.clockwise" tintColor={Colors.ivory} size={17} />
                    )}
                  </LiquidGlass>
                </PressableScale>
              )}
            </View>
          </View>

          <View style={styles.entitiesRow}>
            <Text style={[styles.entityTitle, { color: Colors.copper }]}>
              {vm.entityA}
            </Text>
            <Text style={styles.vsText}>VS</Text>
            <Text style={[styles.entityTitle, { color: Colors.cyan }]}>
              {vm.entityB}
            </Text>
          </View>
          <Text style={styles.querySub}>{vm.query}</Text>
        </View>

        {/* Running State with Kinetic Research Orb Pipeline */}
        {isRunning && <ResearchOrbPipeline progress={vm.progress} />}

        {/* Failed State */}
        {isFailed && (
          <LiquidGlass
            borderRadius={20}
            glowColor="rgba(255, 59, 48, 0.15)"
            specularColor={Colors.error}
            style={styles.failedCard}
            contentStyle={styles.failedContent}
          >
            <Text style={styles.failedTitle}>Research Execution Error</Text>
            <Text style={styles.failedDesc}>
              {vm.error || 'An error occurred during evidence synthesis.'}
            </Text>
            {!isOffline && !isExample && (
              <PressableScale
                activeScale={0.96}
                haptic="medium"
                style={styles.retryPressable}
                onPress={handleRetry}
              >
                <LiquidGlass
                  borderRadius={14}
                  intensity={60}
                  glowColor="rgba(255, 59, 48, 0.2)"
                  specularColor={Colors.error}
                  style={styles.retryGlass}
                  contentStyle={styles.retryContent}
                >
                  <Text style={styles.retryButtonText}>Retry Comparison</Text>
                </LiquidGlass>
              </PressableScale>
            )}
          </LiquidGlass>
        )}

        {/* Completed State: Verdict & Interactive Scrubber */}
        {isCompleted && result && (
          <>
            <InteractiveVerdictCard
              entityA={vm.entityA}
              entityB={vm.entityB}
              verdict={{
                winner:
                  result.verdict?.winner === 'b'
                    ? 'B'
                    : result.verdict?.winner === 'tie'
                    ? 'TIE'
                    : result.verdict?.winner === 'a'
                    ? 'A'
                    : 'TIE',
                title: result.verdict?.bestOverall || 'Comparative Synthesis',
                summary: result.verdict?.summary || '',
                scoreA,
                scoreB,
                consensuses: result.consensus || [],
                contradictions: result.contradictions || [],
              }}
            />

            {/* Interactive Head-to-Head Scrubber */}
            <ContenderComparisonScrubber
              entityA={vm.entityA}
              entityB={vm.entityB}
              summaryA={result.verdict?.summary ?? undefined}
              summaryB={result.verdict?.bestOverall ?? undefined}
            />

            {/* Dimension Breakdown Section */}
            {result.dimensions && result.dimensions.length > 0 && (
              <LiquidGlass
                intensity={80}
                borderRadius={22}
                style={styles.dimensionsCard}
                contentStyle={styles.dimensionsContent}
              >
                <Text style={styles.sectionHeader}>EVALUATION DIMENSIONS</Text>
                {result.dimensions.map((dim, dIdx) => (
                  <DimensionScoreBar
                    key={dIdx}
                    dimension={dim}
                    entityAName={vm.entityA}
                    entityBName={vm.entityB}
                  />
                ))}
              </LiquidGlass>
            )}

            {/* Consensus & Contradictions */}
            {((result.consensus && result.consensus.length > 0) ||
              (result.contradictions && result.contradictions.length > 0)) && (
              <ConsensusCallout
                consensus={result.consensus || []}
                contradictions={result.contradictions || []}
              />
            )}

            {/* Evidence Breakdown by Category (Expandable Accordions) */}
            {result.categories && result.categories.length > 0 && (
              <View style={styles.sectionContainer}>
                <Text style={styles.sectionHeader}>EVIDENCE BREAKDOWN BY CATEGORY</Text>

                {result.categories.map((cat, idx) => (
                  <ExpandableEvidenceCard
                    key={idx}
                    category={cat}
                    entityAName={vm.entityA}
                    entityBName={vm.entityB}
                    defaultExpanded={idx === 0}
                  />
                ))}
              </View>
            )}

            {/* Supporting Sources */}
            {result.sources && result.sources.length > 0 && (
              <View style={styles.sectionContainer}>
                <Text style={styles.sectionHeader}>
                  SUPPORTING SOURCES ({result.sources.length})
                </Text>
                {result.sources.map((src, idx) => (
                  <SourceCard
                    key={src.url || String(idx)}
                    source={src}
                  />
                ))}
              </View>
            )}

            {/* Follow-up Question Sheet */}
            {!isExample && (
              <FollowUpSheet
                onAsk={(q) => followUpMutation.mutate(q)}
                isLoading={followUpMutation.isPending}
                history={followUpHistory}
                isOffline={isOffline}
              />
            )}

            {/* Feedback Rating with Pending / Confirmed / Error states */}
            {!isExample && (
              <LiquidGlass
                intensity={78}
                borderRadius={22}
                style={styles.feedbackCard}
                contentStyle={styles.feedbackContent}
              >
                <Text style={styles.sectionHeader}>WAS THIS BRIEF HELPFUL?</Text>
                <Text style={styles.feedbackDesc}>
                  Your feedback calibrates our multi-model consensus engine.
                </Text>

                {ratingStatus === 'confirmed' ? (
                  <View style={styles.ratingConfirmedRow}>
                    <SymbolView name="checkmark.circle.fill" tintColor={Colors.emerald} size={20} />
                    <Text style={styles.ratingConfirmedText}>
                      Feedback received ({confirmedRating}/5 stars). Thank you!
                    </Text>
                  </View>
                ) : (
                  <View style={styles.starRow}>
                    {[1, 2, 3, 4, 5].map((star) => (
                      <PressableScale
                        key={star}
                        haptic="selection"
                        activeScale={0.88}
                        onPress={() => handleRating(star)}
                        disabled={ratingStatus === 'pending'}
                        style={styles.starPressable}
                        accessibilityLabel={`Rate ${star} out of 5 stars`}
                        testID={`feedback-star-${star}`}
                      >
                        <SymbolView
                          name={
                            (confirmedRating ?? 0) >= star || ratingStatus === 'pending'
                              ? 'star.fill'
                              : 'star'
                          }
                          tintColor={
                            (confirmedRating ?? 0) >= star ? Colors.copper : Colors.ivoryMuted
                          }
                          size={24}
                        />
                      </PressableScale>
                    ))}
                    {ratingStatus === 'pending' && (
                      <ActivityIndicator size="small" color={Colors.copper} style={{ marginLeft: 8 }} />
                    )}
                  </View>
                )}

                {ratingStatus === 'error' && ratingError && (
                  <Text style={styles.ratingErrorText}>{ratingError}</Text>
                )}
              </LiquidGlass>
            )}
          </>
        )}
      </ScrollView>
    </BackgroundTexture>
  );
}

const styles = StyleSheet.create({
  scrollContent: {
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 140,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 24,
  },
  loadingText: {
    ...Typography.body,
    color: Colors.ivoryMuted,
    marginTop: 16,
  },
  errorTitle: {
    ...Typography.h2,
    color: Colors.error,
    marginBottom: 8,
  },
  errorSubtitle: {
    ...Typography.body,
    color: Colors.ivoryMuted,
    textAlign: 'center',
    marginBottom: 24,
  },
  actionButton: {
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 14,
    backgroundColor: Colors.raisedTitanium,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  actionButtonText: {
    ...Typography.h3,
    color: Colors.ivory,
  },
  offlineBanner: {
    backgroundColor: 'rgba(255, 214, 10, 0.12)',
    borderColor: 'rgba(255, 214, 10, 0.3)',
    borderWidth: 1,
    padding: 12,
    borderRadius: 12,
    marginBottom: 16,
  },
  offlineText: {
    ...Typography.bodySm,
    color: Colors.amber,
    textAlign: 'center',
  },
  exampleBanner: {
    backgroundColor: 'rgba(255, 155, 115, 0.12)',
    borderColor: 'rgba(255, 155, 115, 0.3)',
    borderWidth: 1,
    padding: 12,
    borderRadius: 12,
    marginBottom: 16,
  },
  exampleText: {
    ...Typography.bodySm,
    color: Colors.copper,
    textAlign: 'center',
    fontWeight: '600',
  },
  titleHeader: {
    marginBottom: 20,
  },
  topActionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  categoryBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.12)',
  },
  categoryBadgeText: {
    ...Typography.caption,
    color: Colors.ivoryMuted,
    letterSpacing: 0.8,
  },
  headerIcons: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  iconGlass: {
    width: 36,
    height: 36,
  },
  iconGlassContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  entitiesRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexWrap: 'wrap',
  },
  entityTitle: {
    ...Typography.h1,
    fontWeight: '700',
  },
  vsText: {
    ...Typography.caption,
    color: Colors.ivoryMuted,
    fontWeight: '800',
  },
  querySub: {
    ...Typography.bodySm,
    color: Colors.ivoryMuted,
    marginTop: 4,
  },
  failedCard: {
    marginTop: 12,
    marginBottom: 20,
  },
  failedContent: {
    padding: 20,
    backgroundColor: 'rgba(255, 59, 48, 0.05)',
  },
  failedTitle: {
    ...Typography.h3,
    color: Colors.error,
    marginBottom: 6,
  },
  failedDesc: {
    ...Typography.bodySm,
    color: Colors.ivoryMuted,
    marginBottom: 16,
  },
  retryPressable: {
    alignSelf: 'flex-start',
  },
  retryGlass: {
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  retryContent: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  retryButtonText: {
    ...Typography.caption,
    color: Colors.ivory,
    fontWeight: '700',
  },
  dimensionsCard: {
    marginTop: 20,
  },
  dimensionsContent: {
    padding: 16,
  },
  sectionContainer: {
    marginTop: 24,
  },
  sectionHeader: {
    ...Typography.caption,
    color: Colors.ivoryMuted,
    letterSpacing: 1.2,
    marginBottom: 12,
    fontWeight: '700',
  },
  feedbackCard: {
    marginTop: 24,
  },
  feedbackContent: {
    padding: 20,
  },
  feedbackDesc: {
    ...Typography.bodySm,
    color: Colors.ivoryMuted,
    marginBottom: 14,
  },
  starRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  starPressable: {
    padding: 4,
  },
  ratingConfirmedRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 4,
  },
  ratingConfirmedText: {
    ...Typography.bodySm,
    color: Colors.emerald,
    fontWeight: '600',
  },
  ratingErrorText: {
    ...Typography.bodySm,
    color: Colors.error,
    marginTop: 8,
  },
});
