import React from 'react';
import {
  StyleSheet,
  View,
  Text,
  ScrollView,
  Pressable,
  Alert,
} from 'react-native';
import { useUser, useClerk } from '@clerk/expo';
import { useRouter } from 'expo-router';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import * as WebBrowser from 'expo-web-browser';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { BackgroundTexture } from '../src/components/common/BackgroundTexture';
import { UsageGauge } from '../src/components/account/UsageGauge';
import { Colors } from '../src/theme/colors';
import { fetchUsageStatus } from '../src/api/usage';
import { triggerHaptic } from '../src/theme/haptics';
import { GlassSurface } from '../src/components/common/GlassSurface';

export default function AccountScreen() {
  const { user } = useUser();
  const { signOut } = useClerk();
  const router = useRouter();
  const queryClient = useQueryClient();

  const {
    data: usage,
    isLoading: isUsageLoading,
    isError: isUsageError,
  } = useQuery({
    queryKey: ['usage'],
    queryFn: fetchUsageStatus,
  });

  const handleSignOut = async () => {
    triggerHaptic.mediumImpact();
    try {
      await AsyncStorage.removeItem('SIDEBY_GUEST_MODE');
      await signOut();
      router.replace('/(auth)/sign-in');
    } catch {
      router.replace('/(auth)/sign-in');
    }
  };


  const handleClearCache = () => {
    triggerHaptic.mediumImpact();
    Alert.alert(
      'Clear Local Cache',
      'This will remove offline cached SideBy comparisons and sources. Are you sure?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Clear Cache',
          style: 'destructive',
          onPress: async () => {
            await queryClient.clear();
            await AsyncStorage.removeItem('SIDEBY_QUERY_CACHE_V1');
            triggerHaptic.successNotification();
            Alert.alert('Cache Cleared', 'Local evidence cache has been reset.');
          },
        },
      ]
    );
  };

  const handleOpenWebLink = async (url: string) => {
    triggerHaptic.selection();
    try {
      await WebBrowser.openBrowserAsync(url);
    } catch {
      // Link open fallback
    }
  };

  return (
    <BackgroundTexture>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* User Profile Info Card */}
        <GlassSurface style={styles.card}>
          <Text style={styles.sectionTitle}>ACCOUNT PROFILE</Text>
          <View style={styles.profileRow}>
            <View style={styles.avatarCircle}>
              <Text style={styles.avatarText}>
                {user?.primaryEmailAddress?.emailAddress?.charAt(0).toUpperCase() || 'U'}
              </Text>
            </View>

            <View style={styles.profileDetails}>
              <Text style={styles.emailText}>
                {user?.primaryEmailAddress?.emailAddress || 'User Account'}
              </Text>
              <Text style={styles.userIdText}>
                ID: {user?.id ? `${user.id.slice(0, 14)}...` : 'Connected'}
              </Text>
            </View>
          </View>
        </GlassSurface>

        {/* Daily Quota Usage Gauge */}
        <UsageGauge
          usage={usage}
          loadState={isUsageError ? 'error' : isUsageLoading ? 'loading' : undefined}
        />

        {/* Cache & Data Management */}
        <GlassSurface style={styles.card}>
          <Text style={styles.sectionTitle}>STORAGE & OFFLINE CACHE</Text>
          <Text style={styles.cardDesc}>
            Completed comparison briefs and evidence sources are cached locally for 7 days.
          </Text>

          <Pressable style={styles.secondaryButton} onPress={handleClearCache}>
            <Text style={styles.secondaryButtonText}>Clear Offline Cache</Text>
          </Pressable>
        </GlassSurface>

        {/* Legal & Privacy */}
        <GlassSurface style={styles.card}>
          <Text style={styles.sectionTitle}>LEGAL & POLICIES</Text>

          <Pressable
            style={styles.linkRow}
            onPress={() => handleOpenWebLink('https://sideby.app/privacy')}
          >
            <Text style={styles.linkRowText}>Privacy Policy</Text>
            <Text style={styles.arrowIcon}>↗</Text>
          </Pressable>

          <View style={styles.lineDivider} />

          <Pressable
            style={styles.linkRow}
            onPress={() => handleOpenWebLink('https://sideby.app/terms')}
          >
            <Text style={styles.linkRowText}>Terms of Service</Text>
            <Text style={styles.arrowIcon}>↗</Text>
          </Pressable>
        </GlassSurface>

        {/* Sign Out Button */}
        <Pressable style={styles.signOutButton} onPress={handleSignOut}>
          <Text style={styles.signOutText}>Sign Out of SideBy</Text>
        </Pressable>
      </ScrollView>
    </BackgroundTexture>
  );
}

const styles = StyleSheet.create({
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  card: {
    borderRadius: 20,
    padding: 18,
    marginBottom: 16,
    boxShadow: '0 16px 34px rgba(0, 0, 0, 0.22)',
  },
  sectionTitle: {
    color: Colors.muted,
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.8,
    marginBottom: 12,
  },
  profileRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  avatarCircle: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: Colors.raisedTitanium,
    borderWidth: 1,
    borderColor: Colors.copper,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    color: Colors.copper,
    fontSize: 20,
    fontWeight: '800',
  },
  profileDetails: {
    flex: 1,
  },
  emailText: {
    color: Colors.ivory,
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 2,
  },
  userIdText: {
    color: Colors.muted,
    fontSize: 12,
  },
  cardDesc: {
    color: Colors.muted,
    fontSize: 13,
    lineHeight: 18,
    marginBottom: 14,
  },
  secondaryButton: {
    backgroundColor: Colors.raisedTitanium,
    borderRadius: 12,
    paddingVertical: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.borderLight,
  },
  secondaryButtonText: {
    color: Colors.ivory,
    fontSize: 14,
    fontWeight: '600',
  },
  linkRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
  },
  linkRowText: {
    color: Colors.ivory,
    fontSize: 15,
  },
  arrowIcon: {
    color: Colors.muted,
    fontSize: 14,
  },
  lineDivider: {
    height: 1,
    backgroundColor: Colors.border,
    marginVertical: 4,
  },
  signOutButton: {
    backgroundColor: 'rgba(255, 59, 48, 0.15)',
    borderRadius: 16,
    paddingVertical: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.error,
    marginTop: 10,
  },
  signOutText: {
    color: Colors.error,
    fontSize: 15,
    fontWeight: '700',
  },
});
