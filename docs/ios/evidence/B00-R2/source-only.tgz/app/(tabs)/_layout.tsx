import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { usePathname, useRouter } from 'expo-router';
import { Tabs, TabList, TabSlot, TabTrigger } from 'expo-router/ui';
import { SymbolView } from 'expo-symbols';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  GlassTabBar,
  GlassTabButton,
  TabBarMinimizeProvider,
  renderFadingTabScreen,
  type GlassTabItem,
} from 'expo-glass-tabs';
import { Colors } from '../../src/theme/colors';
import { AUTH_REQUIRED } from '../../src/config/features';
import { PressableScale } from '../../src/components/common/PressableScale';

const ITEMS: Array<GlassTabItem & { href: string }> = [
  {
    name: 'index',
    href: '/(tabs)',
    label: 'Compare',
    icon: 'arrow.left.arrow.right',
  },
  {
    name: 'history',
    href: '/(tabs)/history',
    label: 'History',
    icon: 'clock.arrow.circlepath',
  },
  {
    name: 'sources',
    href: '/(tabs)/sources',
    label: 'Sources',
    icon: 'doc.text',
  },
];

function CleanAppHeader() {
  const insets = useSafeAreaInsets();
  const pathname = usePathname();
  const router = useRouter();

  const title = pathname.includes('/history')
    ? 'Decision History'
    : pathname.includes('/sources')
      ? 'Evidence Library'
      : 'SideBy';

  return (
    <View style={[styles.headerContainer, { paddingTop: insets.top + 6 }]}>
      <View style={styles.headerRow}>
        <View>
          <Text style={styles.kicker}>SIDEBY INTELLIGENCE</Text>
          <Text style={styles.title}>{title}</Text>
        </View>

        {AUTH_REQUIRED && (
          <PressableScale
            haptic="selection"
            style={styles.avatarButton}
            onPress={() => router.push('/account')}
            accessibilityLabel="Account and usage"
          >
            <SymbolView name="person.crop.circle" tintColor={Colors.ivory} size={22} />
          </PressableScale>
        )}
      </View>
    </View>
  );
}

export default function TabsLayout() {
  const router = useRouter();

  return (
    <TabBarMinimizeProvider>
      <Tabs>
        <CleanAppHeader />
        <TabSlot style={styles.slot} renderFn={renderFadingTabScreen} />
        <TabList asChild>
          <GlassTabBar
            haptics
            theme={{
              activeTint: Colors.ivory,
              inactiveTint: 'rgba(211, 217, 231, 0.55)',
              highlight: 'rgba(255, 255, 255, 0.16)',
              glassTint: 'rgba(12, 14, 20, 0.52)',
              solidFallback: 'rgba(14, 16, 24, 0.94)',
            }}
            onIndexSelected={(index) => {
              const destination = ITEMS[index]?.href;
              if (destination) {
                router.navigate(destination as never);
              }
            }}
          >
            {ITEMS.map(({ href, ...item }, index) => (
              <TabTrigger
                key={item.name}
                name={item.name}
                href={href as never}
                asChild
              >
                <GlassTabButton item={item} index={index} />
              </TabTrigger>
            ))}
          </GlassTabBar>
        </TabList>
      </Tabs>
    </TabBarMinimizeProvider>
  );
}

const styles = StyleSheet.create({
  headerContainer: {
    backgroundColor: 'transparent',
    paddingHorizontal: 22,
    paddingBottom: 10,
    zIndex: 10,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
  },
  kicker: {
    color: Colors.cyan,
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.4,
    marginBottom: 2,
  },
  title: {
    color: Colors.ivory,
    fontSize: 26,
    fontWeight: '700',
    letterSpacing: -0.6,
  },
  avatarButton: {
    width: 38,
    height: 38,
    borderRadius: 19,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.16)',
  },
  slot: {
    flex: 1,
  },
});
