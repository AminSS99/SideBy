import React, { useState } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useMutation } from '@tanstack/react-query';
import { SymbolView } from 'expo-symbols';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, {
  FadeIn,
  FadeOut,
  FadeInDown,
  Easing,
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  useReducedMotion,
} from 'react-native-reanimated';
import { BackgroundTexture } from '../../src/components/common/BackgroundTexture';
import { LiquidGlass } from '../../src/components/common/LiquidGlass';
import { PressableScale } from '../../src/components/common/PressableScale';
import { ContenderInputCard } from '../../src/components/compare/ContenderInputCard';
import { TactileSwapButton } from '../../src/components/compare/TactileSwapButton';
import { PresetRail } from '../../src/components/compare/PresetRail';
import { Colors } from '../../src/theme/colors';
import { Typography } from '../../src/theme/typography';
import { createComparison } from '../../src/api/comparisons';
import { composeQuery } from '../../src/utils/progress';
import { triggerHaptic } from '../../src/theme/haptics';
import { useMinimizeOnScroll } from 'expo-glass-tabs';

const PRESET_COMPARISONS = [
  { a: 'Astro', b: 'SvelteKit', context: 'High-performance content platform' },
  { a: 'PostgreSQL', b: 'MongoDB', context: 'Transactional analytics at scale' },
  { a: 'React', b: 'Vue', context: 'Frontend team architecture' },
  { a: 'Stripe', b: 'Paddle', context: 'Global SaaS billing & MoR' },
];

export default function CompareScreen() {
  const router = useRouter();
  const onScroll = useMinimizeOnScroll();
  const reducedMotion = useReducedMotion();

  const [entityA, setEntityA] = useState('');
  const [entityB, setEntityB] = useState('');
  const [useCase, setUseCase] = useState('');
  const [validationError, setValidationError] = useState('');

  const pulseOpacity = useSharedValue(0.4);
  const pulseScale = useSharedValue(1);

  React.useEffect(() => {
    if (!reducedMotion) {
      pulseOpacity.value = withRepeat(
        withTiming(1, { duration: 1200, easing: Easing.inOut(Easing.ease) }),
        -1,
        true
      );
      pulseScale.value = withRepeat(
        withTiming(1.35, { duration: 1200, easing: Easing.inOut(Easing.ease) }),
        -1,
        true
      );
    }
  }, [reducedMotion]);

  const animatedPulseStyle = useAnimatedStyle(() => {
    'worklet';
    return {
      opacity: pulseOpacity.value,
      transform: [{ scale: pulseScale.value }],
    };
  });

  const createMutation = useMutation({
    mutationFn: (query: string) => createComparison(query),
    onSuccess: (data) => {
      triggerHaptic.successNotification();
      router.push(`/comparison/${data.id}`);
    },
    onError: (err: any) => {
      triggerHaptic.errorNotification();
      setValidationError(err?.message || 'Failed to submit comparison.');
    },
  });

  const handleSwap = () => {
    const temp = entityA;
    setEntityA(entityB);
    setEntityB(temp);
  };

  const handleSelectPreset = (preset: typeof PRESET_COMPARISONS[0]) => {
    triggerHaptic.selection();
    setEntityA(preset.a);
    setEntityB(preset.b);
    setUseCase(preset.context);
    setValidationError('');
  };

  const handleSubmit = async () => {
    if (!entityA.trim() || !entityB.trim()) {
      setValidationError('Please enter names for both Option A and Option B.');
      triggerHaptic.errorNotification();
      return;
    }

    setValidationError('');
    triggerHaptic.heavyImpact();

    const fullQuery = composeQuery(entityA, entityB, useCase);
    createMutation.mutate(fullQuery);
  };

  return (
    <BackgroundTexture>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.container}
      >
        <Animated.ScrollView
          contentContainerStyle={styles.scrollContent}
          contentInsetAdjustmentBehavior="automatic"
          keyboardShouldPersistTaps="handled"
          onScroll={onScroll}
          scrollEventThrottle={16}
        >
          {/* Editorial Hero Header */}
          <Animated.View
            entering={reducedMotion ? undefined : FadeInDown.duration(400)}
            style={styles.hero}
          >
            <View style={styles.liveBadge}>
              <View style={styles.pulseContainer}>
                <Animated.View style={[styles.pulseAura, animatedPulseStyle]} />
                <View style={styles.pulseDot} />
              </View>
              <Text style={styles.liveBadgeText}>AUTONOMOUS DECISION ENGINE</Text>
            </View>
            <Text style={styles.heroTitle}>Make the call.</Text>
            <Text style={styles.heroSubtitle}>
              Two contenders in. A source-backed, calibrated verdict out.
            </Text>
          </Animated.View>

          {validationError ? (
            <LiquidGlass
              borderRadius={16}
              glowColor="rgba(255, 59, 48, 0.16)"
              specularColor="rgba(255, 59, 48, 0.40)"
              style={styles.errorBanner}
              contentStyle={styles.errorContent}
            >
              <SymbolView name="exclamationmark.triangle.fill" tintColor={Colors.error} size={16} />
              <Text style={styles.errorText}>{validationError}</Text>
            </LiquidGlass>
          ) : null}

          {/* Split Contenders Canvas */}
          <View style={styles.cardsContainer}>
            <ContenderInputCard
              optionKey="A"
              label="OPTION A"
              value={entityA}
              onChangeText={setEntityA}
              accentColor={Colors.copper}
              softColor={Colors.copperSoft}
              placeholder="First Option (e.g. Astro)"
            />

            <TactileSwapButton onSwap={handleSwap} />

            <ContenderInputCard
              optionKey="B"
              label="OPTION B"
              value={entityB}
              onChangeText={setEntityB}
              accentColor={Colors.cyan}
              softColor={Colors.cyanSoft}
              placeholder="Second Option (e.g. SvelteKit)"
            />
          </View>

          {/* Curated Benchmarks Rail */}
          <PresetRail
            presets={PRESET_COMPARISONS}
            onSelectPreset={handleSelectPreset}
          />

          {/* Context Card */}
          <LiquidGlass
            intensity={75}
            borderRadius={20}
            style={styles.contextSurface}
            contentStyle={styles.contextContent}
          >
            <Text style={styles.sectionHeading}>EVALUATION CONTEXT (OPTIONAL)</Text>
            <TextInput
              style={styles.contextInput}
              placeholder="e.g. High-throughput edge runtime or startup stack"
              placeholderTextColor="rgba(211, 217, 231, 0.45)"
              value={useCase}
              onChangeText={setUseCase}
            />
          </LiquidGlass>

          {/* Primary Call to Action Button with Spring Physics */}
          <PressableScale
            haptic="none"
            activeScale={0.96}
            style={[styles.ctaButton, createMutation.isPending && styles.ctaButtonDisabled]}
            onPress={handleSubmit}
            disabled={createMutation.isPending}
          >
            <LinearGradient
              colors={['#FFFFFF', '#E6EEFA', '#F3D6C8']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.ctaGradient}
            >
              {createMutation.isPending ? (
                <Animated.View
                  key="loading"
                  entering={reducedMotion ? undefined : FadeIn.duration(200)}
                  exiting={reducedMotion ? undefined : FadeOut.duration(150)}
                  style={styles.ctaInner}
                >
                  <ActivityIndicator color="#0D0D11" size="small" />
                  <Text style={styles.ctaText}>Analyzing Contenders...</Text>
                </Animated.View>
              ) : (
                <Animated.View
                  key="idle"
                  entering={reducedMotion ? undefined : FadeIn.duration(200)}
                  exiting={reducedMotion ? undefined : FadeOut.duration(150)}
                  style={styles.ctaInner}
                >
                  <Text style={styles.ctaText}>Run Deep Comparison</Text>
                  <SymbolView name="sparkles" tintColor="#0D0D11" size={17} />
                </Animated.View>
              )}
            </LinearGradient>
          </PressableScale>
        </Animated.ScrollView>
      </KeyboardAvoidingView>
    </BackgroundTexture>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 22,
    paddingTop: 8,
    paddingBottom: 130,
  },
  hero: {
    paddingTop: 4,
    paddingBottom: 20,
  },
  liveBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    marginBottom: 10,
  },
  pulseContainer: {
    position: 'relative',
    width: 10,
    height: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  pulseAura: {
    position: 'absolute',
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: Colors.cyan,
  },
  pulseDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: Colors.cyan,
    shadowColor: Colors.cyan,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.9,
    shadowRadius: 6,
  },
  liveBadgeText: {
    color: Colors.cyan,
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.6,
  },
  heroTitle: {
    ...Typography.h1,
    color: Colors.ivory,
    fontSize: 40,
    lineHeight: 46,
    letterSpacing: -1.2,
  },
  heroSubtitle: {
    ...Typography.body,
    color: 'rgba(211, 217, 231, 0.75)',
    marginTop: 6,
    fontSize: 15,
  },
  errorBanner: {
    marginBottom: 16,
    borderWidth: 1,
    borderColor: Colors.error,
  },
  errorContent: {
    padding: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  errorText: {
    color: Colors.error,
    fontSize: 13,
    fontWeight: '600',
    flex: 1,
  },
  cardsContainer: {
    marginBottom: 20,
  },
  sectionHeading: {
    color: 'rgba(211, 217, 231, 0.60)',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.2,
    marginBottom: 10,
  },
  contextSurface: {
    marginBottom: 22,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.12)',
  },
  contextContent: {
    padding: 18,
  },
  contextInput: {
    color: Colors.ivory,
    fontSize: 15,
    paddingVertical: 6,
  },
  ctaButton: {
    borderRadius: 20,
    overflow: 'hidden',
    shadowColor: Colors.copper,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.35,
    shadowRadius: 20,
  },
  ctaGradient: {
    minHeight: 58,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  ctaInner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 9,
  },
  ctaButtonDisabled: {
    opacity: 0.6,
  },
  ctaText: {
    color: '#090A0F',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: -0.2,
  },
});
