import React, { useState, useMemo } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import { useQuery } from '@tanstack/react-query';
import { BackgroundTexture } from '../../src/components/common/BackgroundTexture';
import { SourceCard } from '../../src/components/comparison/SourceCard';
import { Colors } from '../../src/theme/colors';
import { Typography } from '../../src/theme/typography';
import { fetchAggregatedSourcesReport } from '../../src/api/sources';
import { ComparisonSource } from '../../src/types/schemas';
import { LiquidGlass } from '../../src/components/common/LiquidGlass';
import { PressableScale } from '../../src/components/common/PressableScale';
import Animated from 'react-native-reanimated';
import { useMinimizeOnScroll } from 'expo-glass-tabs';
import { SymbolView } from 'expo-symbols';

type SourceFilter = 'all' | 'high-confidence' | 'docs' | 'benchmarks';

export default function SourcesScreen() {
  const onScroll = useMinimizeOnScroll();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<SourceFilter>('all');

  const {
    data: report,
    isLoading,
    isError,
    isRefetching,
    refetch,
  } = useQuery({
    queryKey: ['sources'],
    queryFn: () => fetchAggregatedSourcesReport(10),
  });

  const sources = report?.sources ?? [];
  const aggregationStatus = report?.status ?? null;

  const filteredSources = useMemo(() => {
    let list = [...sources];

    if (activeFilter === 'high-confidence') {
      list = list.filter((s: ComparisonSource) => (s.confidence || 0) >= 0.85);
    } else if (activeFilter === 'docs') {
      list = list.filter(
        (s: ComparisonSource) =>
          (s.reliability && s.reliability.toLowerCase().includes('doc')) ||
          s.url.toLowerCase().includes('doc') ||
          s.url.toLowerCase().includes('github.com')
      );
    } else if (activeFilter === 'benchmarks') {
      list = list.filter(
        (s: ComparisonSource) =>
          s.title.toLowerCase().includes('benchmark') ||
          s.title.toLowerCase().includes('perf') ||
          (s.summary && s.summary.toLowerCase().includes('benchmark'))
      );
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(
        (src: ComparisonSource) =>
          src.title.toLowerCase().includes(q) ||
          src.url.toLowerCase().includes(q) ||
          (src.summary && src.summary.toLowerCase().includes(q))
      );
    }

    return list;
  }, [sources, activeFilter, searchQuery]);

  return (
    <BackgroundTexture>
      <View style={styles.container}>
        {/* Floating Arc-Style Search Bar */}
        <View style={styles.searchContainer}>
          <LiquidGlass
            intensity={80}
            borderRadius={18}
            specularColor="rgba(255, 255, 255, 0.25)"
            style={styles.searchGlass}
            contentStyle={styles.searchContent}
          >
            <SymbolView name="magnifyingglass" tintColor={Colors.muted} size={16} />
            <TextInput
              style={styles.searchInput}
              placeholder="Filter cited sources and domains..."
              placeholderTextColor="rgba(211, 217, 231, 0.45)"
              value={searchQuery}
              onChangeText={setSearchQuery}
            />
            {searchQuery.length > 0 && (
              <PressableScale haptic="selection" onPress={() => setSearchQuery('')}>
                <SymbolView name="xmark.circle.fill" tintColor="rgba(255, 255, 255, 0.4)" size={16} />
              </PressableScale>
            )}
          </LiquidGlass>
        </View>

        {/* Filter Pills with Tactile Physics */}
        <View style={styles.filtersRow}>
          {([
            { key: 'all', label: 'ALL' },
            { key: 'high-confidence', label: 'HIGH CONFIDENCE' },
            { key: 'docs', label: 'OFFICIAL DOCS' },
            { key: 'benchmarks', label: 'BENCHMARKS' },
          ] as const).map(({ key, label }) => {
            const isActive = activeFilter === key;
            return (
              <PressableScale
                key={key}
                haptic="selection"
                activeScale={0.92}
                onPress={() => setActiveFilter(key)}
              >
                <LiquidGlass
                  borderRadius={12}
                  intensity={isActive ? 65 : 35}
                  glowColor={isActive ? 'rgba(110, 217, 230, 0.20)' : undefined}
                  specularColor={isActive ? Colors.cyan : 'rgba(255, 255, 255, 0.15)'}
                  style={[styles.filterPill, isActive && styles.filterPillActive]}
                  contentStyle={styles.filterPillContent}
                >
                  <Text style={[styles.filterText, isActive && styles.filterTextActive]}>
                    {label}
                  </Text>
                </LiquidGlass>
              </PressableScale>
            );
          })}
        </View>

        {/* Sources Count Subheader */}
        <View style={styles.countRow}>
          <LiquidGlass
            borderRadius={10}
            intensity={40}
            style={styles.countBadge}
            contentStyle={styles.countBadgeContent}
          >
            <View style={styles.greenDot} />
            <Text style={styles.countText}>
              {filteredSources.length} CITATIONS
            </Text>
          </LiquidGlass>
          <Text style={styles.scopeText}>
            {report
              ? `Across the ${report.totalCompleted} most recent completed briefs`
              : 'Across recent completed briefs'}
          </Text>
        </View>

        {/* Partial-aggregation notice: some briefs failed to load */}
        {aggregationStatus === 'partial' && report && (
          <View style={styles.partialBanner}>
            <Text style={styles.partialText}>
              Partial results — {report.failedCount} of {report.totalCompleted}{' '}
              briefs failed to load. Counts below may be incomplete.
            </Text>
          </View>
        )}

        {isLoading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color={Colors.cyan} />
          </View>
        ) : isError || aggregationStatus === 'all_failed' ? (
          <View style={styles.emptyContainer}>
            <SymbolView name="exclamationmark.triangle" tintColor={Colors.warning} size={42} />
            <Text style={styles.emptyTitle}>Sources Unavailable</Text>
            <Text style={styles.emptySubtitle}>
              Every recent brief failed to load. This is a fetch failure, not an
              empty library. Pull to retry.
            </Text>
          </View>
        ) : (
          <Animated.FlatList
            contentInsetAdjustmentBehavior="automatic"
            data={filteredSources}
            onScroll={onScroll}
            scrollEventThrottle={16}
            keyExtractor={(item, index) => item.url || String(index)}
            renderItem={({ item }) => <SourceCard source={item} />}
            contentContainerStyle={styles.listContent}
            refreshControl={
              <RefreshControl
                refreshing={isRefetching}
                onRefresh={refetch}
                tintColor={Colors.cyan}
              />
            }
            ListEmptyComponent={
              <View style={styles.emptyContainer}>
                <SymbolView name="doc.text.magnifyingglass" tintColor={Colors.muted} size={42} />
                <Text style={styles.emptyTitle}>No Citations Available</Text>
                <Text style={styles.emptySubtitle}>
                  {searchQuery
                    ? 'No matching sources found.'
                    : aggregationStatus === 'empty'
                    ? 'No completed briefs in the recent set. Run a comparison to start building this library.'
                    : 'Run comparisons to build your evidence library.'}
                </Text>
              </View>
            }
          />
        )}
      </View>
    </BackgroundTexture>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  searchContainer: {
    paddingHorizontal: 22,
    paddingTop: 8,
    paddingBottom: 10,
  },
  searchGlass: {
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.12)',
  },
  searchContent: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
  },
  searchInput: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 10,
    color: Colors.ivory,
    fontSize: 14,
  },
  filtersRow: {
    flexDirection: 'row',
    paddingHorizontal: 22,
    paddingBottom: 12,
    gap: 8,
    flexWrap: 'wrap',
  },
  filterPill: {
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.10)',
  },
  filterPillActive: {
    borderColor: 'rgba(110, 217, 230, 0.50)',
  },
  filterPillContent: {
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  filterText: {
    color: 'rgba(211, 217, 231, 0.55)',
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.6,
  },
  filterTextActive: {
    color: Colors.cyan,
  },
  countRow: {
    paddingHorizontal: 22,
    paddingBottom: 4,
  },
  scopeText: {
    color: 'rgba(211, 217, 231, 0.55)',
    fontSize: 11,
    marginTop: 8,
  },
  partialBanner: {
    marginHorizontal: 22,
    marginBottom: 10,
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderRadius: 12,
    backgroundColor: 'rgba(255, 214, 10, 0.10)',
    borderWidth: 1,
    borderColor: 'rgba(255, 214, 10, 0.35)',
  },
  partialText: {
    color: Colors.amber,
    fontSize: 12,
    lineHeight: 17,
  },
  countBadge: {
    alignSelf: 'flex-start',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.10)',
  },
  countBadgeContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  greenDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#34C759',
  },
  countText: {
    color: 'rgba(211, 217, 231, 0.65)',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.1,
  },
  listContent: {
    paddingHorizontal: 22,
    paddingBottom: 120,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 70,
    gap: 10,
  },
  emptyTitle: {
    ...Typography.h3,
    color: Colors.ivory,
    marginTop: 6,
  },
  emptySubtitle: {
    ...Typography.bodySm,
    color: Colors.muted,
    textAlign: 'center',
    maxWidth: 280,
  },
});
