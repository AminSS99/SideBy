import React, { useState, useMemo, useRef } from 'react';
import {
  StyleSheet,
  View,
  Text,
  FlatList,
  TextInput,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { SymbolView } from 'expo-symbols';
import { BackgroundTexture } from '../../src/components/common/BackgroundTexture';
import { LiquidGlass } from '../../src/components/common/LiquidGlass';
import { PressableScale } from '../../src/components/common/PressableScale';
import { Colors } from '../../src/theme/colors';
import { Typography } from '../../src/theme/typography';
import { fetchComparisonsHistory, toggleFavorite } from '../../src/api/comparisons';
import { ComparisonHistoryItem } from '../../src/types/schemas';
import { triggerHaptic } from '../../src/theme/haptics';

type FilterType = 'all' | 'completed' | 'running' | 'starred';

export default function HistoryScreen() {
  const router = useRouter();
  const queryClient = useQueryClient();

  const [activeFilter, setActiveFilter] = useState<FilterType>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const pendingFavorites = useRef<Set<string>>(new Set());

  const {
    data: history = [],
    isLoading,
    isRefetching,
    refetch,
  } = useQuery({
    queryKey: ['history'],
    queryFn: () => fetchComparisonsHistory(50),
  });

  const filteredHistory = useMemo(() => {
    let list = [...history];

    if (activeFilter === 'running') {
      list = list.filter((item) => item.status === 'running' || item.status === 'queued');
    } else if (activeFilter === 'completed') {
      list = list.filter((item) => item.status === 'completed');
    } else if (activeFilter === 'starred') {
      list = list.filter((item) => item.isFavorited);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(
        (item) =>
          item.query.toLowerCase().includes(q) ||
          item.entityA?.toLowerCase().includes(q) ||
          item.entityB?.toLowerCase().includes(q) ||
          item.summary?.toLowerCase().includes(q)
      );
    }

    return list;
  }, [history, activeFilter, searchQuery]);

  // Race-safe serialized favorite toggle with optimistic update and rollback
  const handleToggleFavorite = async (id: string, currentState: boolean) => {
    if (pendingFavorites.current.has(id)) return;
    pendingFavorites.current.add(id);

    triggerHaptic.selection();

    // Optimistic update in queryClient cache
    queryClient.setQueryData(['history'], (old: ComparisonHistoryItem[] | undefined) => {
      if (!old) return old;
      return old.map((item) =>
        item.id === id ? { ...item, isFavorited: !currentState } : item
      );
    });

    try {
      const res = await toggleFavorite(id, !currentState);
      queryClient.setQueryData(['history'], (old: ComparisonHistoryItem[] | undefined) => {
        if (!old) return old;
        return old.map((item) =>
          item.id === id ? { ...item, isFavorited: res.isFavorited } : item
        );
      });
      queryClient.invalidateQueries({ queryKey: ['history'] });
    } catch {
      // Rollback to original state on mutation failure
      queryClient.setQueryData(['history'], (old: ComparisonHistoryItem[] | undefined) => {
        if (!old) return old;
        return old.map((item) =>
          item.id === id ? { ...item, isFavorited: currentState } : item
        );
      });
      triggerHaptic.errorNotification();
    } finally {
      pendingFavorites.current.delete(id);
    }
  };

  return (
    <BackgroundTexture>
      <View style={styles.container}>
        {/* Floating Arc-Style Search Bar */}
        <View style={styles.searchContainer}>
          <LiquidGlass
            intensity={80}
            borderRadius={18}
            style={styles.searchGlass}
            contentStyle={styles.searchContent}
          >
            <SymbolView name="magnifyingglass" tintColor={Colors.muted} size={16} />
            <TextInput
              style={styles.searchInput}
              placeholder="Search past evaluations..."
              placeholderTextColor="rgba(211, 217, 231, 0.45)"
              value={searchQuery}
              onChangeText={setSearchQuery}
              returnKeyType="search"
            />
            {searchQuery.length > 0 && (
              <PressableScale
                haptic="selection"
                onPress={() => setSearchQuery('')}
              >
                <SymbolView name="xmark.circle.fill" tintColor="rgba(255, 255, 255, 0.4)" size={16} />
              </PressableScale>
            )}
          </LiquidGlass>
        </View>

        {/* Filter Pills with Tactile Physics */}
        <View style={styles.filtersRow}>
          {(['all', 'completed', 'running', 'starred'] as FilterType[]).map((f) => {
            const isActive = activeFilter === f;
            return (
              <PressableScale
                key={f}
                haptic="selection"
                activeScale={0.92}
                style={[styles.filterPill, isActive && styles.filterPillActive]}
                onPress={() => setActiveFilter(f)}
              >
                <Text style={[styles.filterText, isActive && styles.filterTextActive]}>
                  {f === 'starred' ? '★ STARRED' : f.toUpperCase()}
                </Text>
              </PressableScale>
            );
          })}
        </View>

        {isLoading ? (
          <View style={styles.centerContainer}>
            <ActivityIndicator size="large" color={Colors.copper} />
          </View>
        ) : filteredHistory.length === 0 ? (
          <View style={styles.centerContainer}>
            <SymbolView name="doc.text.magnifyingglass" tintColor={Colors.ivoryMuted} size={48} />
            <Text style={styles.emptyTitle}>No Decisions Recorded</Text>
            <Text style={styles.emptyDesc}>
              {searchQuery
                ? 'No past evaluations match your query.'
                : 'Start your first source-backed evaluation from the Compare tab.'}
            </Text>
          </View>
        ) : (
          <FlatList
            data={filteredHistory}
            keyExtractor={(item) => item.id}
            contentContainerStyle={styles.listContent}
            refreshControl={
              <RefreshControl
                refreshing={isRefetching}
                onRefresh={refetch}
                tintColor={Colors.copper}
              />
            }
            renderItem={({ item }) => {
              const isRunning = item.status === 'running' || item.status === 'queued';
              return (
                <PressableScale
                  activeScale={0.97}
                  haptic="selection"
                  onPress={() => router.push(`/comparison/${item.id}`)}
                  style={styles.cardContainer}
                >
                  <LiquidGlass
                    intensity={65}
                    borderRadius={18}
                    specularColor={
                      item.isFavorited ? Colors.copperSoft : 'rgba(255, 255, 255, 0.12)'
                    }
                    glowColor={item.isFavorited ? 'rgba(255, 155, 115, 0.08)' : undefined}
                    style={styles.cardGlass}
                    contentStyle={styles.cardContent}
                  >
                    <View style={styles.cardHeader}>
                      <View style={styles.badgeRow}>
                        <View
                          style={[
                            styles.statusBadge,
                            isRunning ? styles.statusBadgeRunning : styles.statusBadgeCompleted,
                          ]}
                        >
                          <Text
                            style={[
                              styles.statusText,
                              isRunning ? styles.statusTextRunning : styles.statusTextCompleted,
                            ]}
                          >
                            {isRunning ? 'RESEARCH IN PROGRESS' : 'COMPLETED BRIEF'}
                          </Text>
                        </View>
                      </View>

                      {/* Favorite Button */}
                      <PressableScale
                        haptic="selection"
                        activeScale={0.88}
                        onPress={() => handleToggleFavorite(item.id, item.isFavorited)}
                        style={styles.favoriteButton}
                        accessibilityLabel={item.isFavorited ? 'Remove favorite' : 'Add to favorites'}
                      >
                        <SymbolView
                          name={item.isFavorited ? 'star.fill' : 'star'}
                          tintColor={item.isFavorited ? Colors.copper : Colors.ivoryMuted}
                          size={18}
                        />
                      </PressableScale>
                    </View>

                    <Text style={styles.itemTitle}>{item.query}</Text>

                    {item.summary ? (
                      <Text style={styles.itemSummary} numberOfLines={2}>
                        {item.summary}
                      </Text>
                    ) : null}

                    <View style={styles.cardFooter}>
                      <Text style={styles.dateText}>
                        {new Date(item.updatedAt).toLocaleDateString(undefined, {
                          month: 'short',
                          day: 'numeric',
                        })}
                      </Text>

                      {item.sourceCount ? (
                        <View style={styles.sourceMeta}>
                          <SymbolView name="link" tintColor={Colors.ivoryMuted} size={12} />
                          <Text style={styles.sourceCountText}>{item.sourceCount} sources</Text>
                        </View>
                      ) : null}
                    </View>
                  </LiquidGlass>
                </PressableScale>
              );
            }}
          />
        )}
      </View>
    </BackgroundTexture>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 60,
    paddingHorizontal: 16,
  },
  searchContainer: {
    marginBottom: 12,
  },
  searchGlass: {
    height: 48,
  },
  searchContent: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    gap: 10,
  },
  searchInput: {
    flex: 1,
    ...Typography.body,
    color: Colors.ivory,
  },
  filtersRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 16,
  },
  filterPill: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 14,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.08)',
  },
  filterPillActive: {
    backgroundColor: 'rgba(255, 155, 115, 0.15)',
    borderColor: Colors.copper,
  },
  filterText: {
    ...Typography.caption,
    color: Colors.ivoryMuted,
  },
  filterTextActive: {
    color: Colors.copper,
    fontWeight: '700',
  },
  listContent: {
    paddingBottom: 130,
    gap: 12,
  },
  cardContainer: {
    marginBottom: 4,
  },
  cardGlass: {
    minHeight: 110,
  },
  cardContent: {
    padding: 16,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  badgeRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
    borderWidth: 1,
  },
  statusBadgeRunning: {
    backgroundColor: 'rgba(255, 214, 10, 0.12)',
    borderColor: 'rgba(255, 214, 10, 0.3)',
  },
  statusBadgeCompleted: {
    backgroundColor: 'rgba(52, 199, 89, 0.12)',
    borderColor: 'rgba(52, 199, 89, 0.3)',
  },
  statusText: {
    ...Typography.caption,
    fontSize: 10,
    letterSpacing: 0.6,
  },
  statusTextRunning: {
    color: Colors.amber,
  },
  statusTextCompleted: {
    color: Colors.emerald,
  },
  favoriteButton: {
    padding: 4,
  },
  itemTitle: {
    ...Typography.h3,
    color: Colors.ivory,
    marginBottom: 6,
  },
  itemSummary: {
    ...Typography.bodySm,
    color: Colors.ivoryMuted,
    lineHeight: 18,
    marginBottom: 10,
  },
  cardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.05)',
    paddingTop: 8,
    marginTop: 4,
  },
  dateText: {
    ...Typography.caption,
    color: Colors.ivoryMuted,
  },
  sourceMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  sourceCountText: {
    ...Typography.caption,
    color: Colors.ivoryMuted,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 32,
    gap: 12,
  },
  emptyTitle: {
    ...Typography.h2,
    color: Colors.ivory,
    marginTop: 8,
  },
  emptyDesc: {
    ...Typography.bodySm,
    color: Colors.ivoryMuted,
    textAlign: 'center',
  },
});
