import React from 'react';
import { StyleSheet, View, Text, ScrollView, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { BackgroundTexture } from '../../src/components/common/BackgroundTexture';
import { Colors } from '../../src/theme/colors';
import { Typography } from '../../src/theme/typography';
import { GlassSurface } from '../../src/components/common/GlassSurface';

export default function DecisionBriefModal() {
  const router = useRouter();

  return (
    <BackgroundTexture>
      <ScrollView
        contentContainerStyle={styles.container}
        contentInsetAdjustmentBehavior="automatic"
      >
        <Text style={styles.title}>Decision Brief</Text>
        <GlassSurface style={styles.card}>
          <Text style={styles.subtitle}>Executive Summary</Text>
          <Text style={styles.body}>
            This decision brief compiles synthesized research facts, confidence ratings, and source citations across both options.
          </Text>

          <Pressable style={styles.closeButton} onPress={() => router.back()}>
            <Text style={styles.closeButtonText}>Done</Text>
          </Pressable>
        </GlassSurface>
      </ScrollView>
    </BackgroundTexture>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
  },
  title: {
    ...Typography.h2,
    color: Colors.ivory,
    marginBottom: 16,
  },
  card: {
    borderRadius: 20,
    padding: 20,
    boxShadow: '0 18px 40px rgba(0, 0, 0, 0.24)',
  },
  subtitle: {
    ...Typography.h3,
    color: Colors.copper,
    marginBottom: 8,
  },
  body: {
    ...Typography.bodySm,
    color: Colors.muted,
    lineHeight: 20,
    marginBottom: 20,
  },
  closeButton: {
    backgroundColor: Colors.raisedTitanium,
    borderRadius: 14,
    paddingVertical: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.borderLight,
  },
  closeButtonText: {
    color: Colors.ivory,
    fontSize: 15,
    fontWeight: '700',
  },
});
