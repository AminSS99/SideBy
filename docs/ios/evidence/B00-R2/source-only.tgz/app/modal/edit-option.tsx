import React, { useState } from 'react';
import { StyleSheet, View, Text, TextInput, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { BackgroundTexture } from '../../src/components/common/BackgroundTexture';
import { Colors } from '../../src/theme/colors';
import { Typography } from '../../src/theme/typography';
import { GlassSurface } from '../../src/components/common/GlassSurface';

export default function EditOptionModal() {
  const router = useRouter();
  const [optionName, setOptionName] = useState('');
  const [notes, setNotes] = useState('');

  const handleSave = () => {
    router.back();
  };

  return (
    <BackgroundTexture>
      <View style={styles.container}>
        <Text style={styles.title}>Edit Option Parameters</Text>

        <GlassSurface style={styles.card}>
          <Text style={styles.label}>OPTION LABEL</Text>
          <TextInput
            style={styles.input}
            placeholder="Option Name"
            placeholderTextColor={Colors.muted}
            value={optionName}
            onChangeText={setOptionName}
          />

          <Text style={styles.label}>CONTEXTUAL NOTES</Text>
          <TextInput
            style={[styles.input, styles.textArea]}
            placeholder="Additional requirements..."
            placeholderTextColor={Colors.muted}
            value={notes}
            onChangeText={setNotes}
            multiline
          />

          <Pressable style={styles.saveButton} onPress={handleSave}>
            <Text style={styles.saveButtonText}>Apply Changes</Text>
          </Pressable>
        </GlassSurface>
      </View>
    </BackgroundTexture>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  title: {
    ...Typography.h2,
    color: Colors.ivory,
    marginBottom: 16,
  },
  card: {
    borderRadius: 20,
    padding: 20,
    boxShadow: '0 18px 40px rgba(0, 0, 0, 0.24)',
  },
  label: {
    color: Colors.muted,
    fontSize: 11,
    fontWeight: '700',
    marginBottom: 8,
  },
  input: {
    backgroundColor: Colors.raisedTitanium,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    color: Colors.ivory,
    fontSize: 14,
    borderWidth: 1,
    borderColor: Colors.borderLight,
    marginBottom: 16,
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
  saveButton: {
    backgroundColor: Colors.ivory,
    borderRadius: 14,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 8,
  },
  saveButtonText: {
    color: Colors.background,
    fontSize: 15,
    fontWeight: '700',
  },
});
