// Learn more https://docs.expo.io/guides/customizing-metro
const { getDefaultConfig } = require('expo/metro-config');

/** @type {import('expo/metro-config').MetroConfig} */
const config = getDefaultConfig(__dirname);

config.resolver.resolveRequest = (context, moduleName, platform) => {
  if (moduleName === '@clerk/react/legacy') {
    return context.resolveRequest(context, '@clerk/react', platform);
  }
  return context.resolveRequest(context, moduleName, platform);
};

module.exports = config;
