import React from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { render, screen, fireEvent, waitFor } from '@testing-library/react-native';
import HistoryScreen from '../history';
import * as client from '../../../src/api/client';

jest.mock('expo-router', () => {
  return {
    useRouter: () => ({ push: jest.fn(), replace: jest.fn(), navigate: jest.fn() }),
    usePathname: () => '/(tabs)/history',
  };
});

jest.mock('expo-symbols', () => {
  const React = require('react');
  const { View } = require('react-native');
  return {
    SymbolView: (props: any) => <View {...props} />,
  };
});

jest.mock('expo-blur', () => {
  const React = require('react');
  const { View } = require('react-native');
  return {
    BlurView: ({ children, ...props }: any) => <View {...props}>{children}</View>,
  };
});

jest.mock('expo-glass-effect', () => {
  const React = require('react');
  const { View } = require('react-native');
  return {
    GlassView: ({ children, ...props }: any) => <View {...props}>{children}</View>,
    isGlassEffectAPIAvailable: () => false,
    isLiquidGlassAvailable: () => false,
  };
});

jest.mock('expo-linear-gradient', () => {
  const React = require('react');
  const { View } = require('react-native');
  return {
    LinearGradient: ({ children, ...props }: any) => <View {...props}>{children}</View>,
  };
});

jest.mock('expo-haptics', () => {
  return {
    selectionAsync: jest.fn(() => Promise.resolve()),
    impactAsync: jest.fn(() => Promise.resolve()),
    notificationAsync: jest.fn(() => Promise.resolve()),
    ImpactFeedbackStyle: { Light: 'light', Medium: 'medium', Heavy: 'heavy' },
    NotificationFeedbackType: { Success: 'success', Error: 'error', Warning: 'warning' },
  };
});

jest.mock('react-native-reanimated', () => {
  const RN = require('react-native');
  const mock: any = {
    createAnimatedComponent: (C: any) => C,
    useSharedValue: (v: any) => ({ value: v }),
    useAnimatedStyle: (fn: any) => fn(),
    withSpring: (v: any) => v,
    withTiming: (v: any) => v,
    withDelay: (_d: any, v: any) => v,
    useReducedMotion: () => false,
    runOnJS: (fn: any) => fn,
    FlatList: RN.FlatList,
    View: RN.View,
    Text: RN.Text,
    ScrollView: RN.ScrollView,
  };
  mock.default = mock;
  return mock;
});

const HISTORY_ITEM = {
  id: 'comp-race-1',
  query: 'Postgres vs MySQL for JSON workloads',
  status: 'completed',
  progress: 100,
  updatedAt: new Date().toISOString(),
  isFavorited: false,
};

// See detail.test.tsx: clear per-render QueryClients so Jest exits normally.
let activeClients: QueryClient[] = [];

function renderHistory() {
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  });
  activeClients.push(queryClient);
  render(
    <QueryClientProvider client={queryClient}>
      <HistoryScreen />
    </QueryClientProvider>
  );
  return queryClient;
}

describe('HistoryScreen — favorite mutation behavior', () => {
  let apiFetchSpy: jest.SpyInstance;

  beforeEach(() => {
    jest.clearAllMocks();
    apiFetchSpy = jest.spyOn(client, 'apiFetch');
  });

  afterEach(() => {
    apiFetchSpy.mockRestore();
    for (const queryClient of activeClients) {
      queryClient.clear();
    }
    activeClients = [];
  });

  it('rolls back the optimistic favorite update when the server rejects', async () => {
    let rejectManage!: (e: unknown) => void;
    const managePromise = new Promise((_resolve, reject) => {
      rejectManage = reject;
    });
    // Attach a no-op catcher so the deferred rejection never surfaces as unhandled.
    managePromise.catch(() => {});
    apiFetchSpy.mockImplementation(async (url: string) => {
      if (url.startsWith('/api/comparisons?limit')) {
        return { comparisons: [HISTORY_ITEM] };
      }
      return managePromise;
    });

    renderHistory();
    await screen.findByText(HISTORY_ITEM.query);

    fireEvent.press(screen.getByLabelText('Add to favorites'));

    // Optimistic update applies immediately…
    await waitFor(() => expect(screen.getByLabelText('Remove favorite')).toBeTruthy());
    // …then rolls back once the server rejects.
    rejectManage({ statusCode: 500, message: 'Database update failed', code: 'HTTP_500' });
    await waitFor(() => expect(screen.getByLabelText('Add to favorites')).toBeTruthy());

    expect(apiFetchSpy).toHaveBeenCalledWith(
      '/api/comparisons/comp-race-1/manage',
      expect.objectContaining({ method: 'POST' })
    );
  });

  it('serializes rapid taps into a single request and confirms the server value', async () => {
    let resolveManage: (v: unknown) => void = () => {};
    const managePromise = new Promise((resolve) => {
      resolveManage = resolve;
    });
    apiFetchSpy.mockImplementation(async (url: string) => {
      if (url.startsWith('/api/comparisons?limit')) {
        return { comparisons: [HISTORY_ITEM] };
      }
      return managePromise;
    });

    renderHistory();
    await screen.findByText(HISTORY_ITEM.query);

    fireEvent.press(screen.getByLabelText('Add to favorites'));
    // Second tap while the first mutation is in flight must be ignored.
    await waitFor(() => expect(screen.getByLabelText('Remove favorite')).toBeTruthy());
    const favButton = screen.getByLabelText('Remove favorite');
    fireEvent.press(favButton);

    resolveManage({ success: true, comparison: { isFavorited: true } });

    await waitFor(() => expect(screen.getByLabelText('Remove favorite')).toBeTruthy());
    const manageCalls = apiFetchSpy.mock.calls.filter((call) =>
      String(call[0]).endsWith('/manage')
    );
    expect(manageCalls).toHaveLength(1);
  });

  it('rolls back when the server acknowledgement omits isFavorited', async () => {
    let resolveManage: (v: unknown) => void = () => {};
    const managePromise = new Promise((resolve) => {
      resolveManage = resolve;
    });
    apiFetchSpy.mockImplementation(async (url: string) => {
      if (url.startsWith('/api/comparisons?limit')) {
        return { comparisons: [HISTORY_ITEM] };
      }
      return managePromise;
    });

    renderHistory();
    await screen.findByText(HISTORY_ITEM.query);

    fireEvent.press(screen.getByLabelText('Add to favorites'));

    await waitFor(() => expect(screen.getByLabelText('Remove favorite')).toBeTruthy());
    // Malformed success (no server isFavorited) must reject and roll back.
    resolveManage({ success: true, comparison: {} });
    await waitFor(() => expect(screen.getByLabelText('Add to favorites')).toBeTruthy());
  });
});
