import React from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { render, screen, fireEvent, waitFor } from '@testing-library/react-native';
import SourcesScreen from '../sources';
import * as client from '../../../src/api/client';

jest.mock('expo-router', () => {
  return {
    useRouter: () => ({ push: jest.fn(), replace: jest.fn(), navigate: jest.fn() }),
    usePathname: () => '/(tabs)/sources',
  };
});

jest.mock('expo-symbols', () => {
  const React = require('react');
  const { View } = require('react-native');
  return {
    SymbolView: (props: any) => <View {...props} />,
  };
});

jest.mock('expo-blur', () => {
  const React = require('react');
  const { View } = require('react-native');
  return {
    BlurView: ({ children, ...props }: any) => <View {...props}>{children}</View>,
  };
});

jest.mock('expo-glass-effect', () => {
  const React = require('react');
  const { View } = require('react-native');
  return {
    GlassView: ({ children, ...props }: any) => <View {...props}>{children}</View>,
    isGlassEffectAPIAvailable: () => false,
    isLiquidGlassAvailable: () => false,
  };
});

jest.mock('expo-linear-gradient', () => {
  const React = require('react');
  const { View } = require('react-native');
  return {
    LinearGradient: ({ children, ...props }: any) => <View {...props}>{children}</View>,
  };
});

jest.mock('expo-glass-tabs', () => {
  return {
    useMinimizeOnScroll: () => () => {},
  };
});

jest.mock('expo-web-browser', () => {
  return {
    openBrowserAsync: jest.fn(() => Promise.resolve({ type: 'dismiss' })),
  };
});

jest.mock('expo-haptics', () => {
  return {
    selectionAsync: jest.fn(() => Promise.resolve()),
    impactAsync: jest.fn(() => Promise.resolve()),
    notificationAsync: jest.fn(() => Promise.resolve()),
    ImpactFeedbackStyle: { Light: 'light', Medium: 'medium', Heavy: 'heavy' },
    NotificationFeedbackType: { Success: 'success', Error: 'error', Warning: 'warning' },
  };
});

jest.mock('react-native-reanimated', () => {
  const RN = require('react-native');
  const mock: any = {
    createAnimatedComponent: (C: any) => C,
    useSharedValue: (v: any) => ({ value: v }),
    useAnimatedStyle: (fn: any) => fn(),
    withSpring: (v: any) => v,
    withTiming: (v: any) => v,
    withDelay: (_d: any, v: any) => v,
    useReducedMotion: () => false,
    runOnJS: (fn: any) => fn,
    FlatList: RN.FlatList,
    View: RN.View,
    Text: RN.Text,
    ScrollView: RN.ScrollView,
  };
  mock.default = mock;
  return mock;
});

const COMPLETED = (id: string) => ({
  id,
  query: `Query ${id}`,
  status: 'completed',
  progress: 100,
  updatedAt: new Date().toISOString(),
  isFavorited: false,
});

const DETAIL_WITH_SOURCE = {
  id: 'comp-s1',
  status: 'completed',
  progress: 100,
  query: 'Query comp-s1',
  updatedAt: new Date().toISOString(),
  result: {
    entities: { a: { name: 'Postgres' }, b: { name: 'MySQL' } },
    sources: [
      {
        title: 'Postgres JSON docs',
        url: 'https://postgresql.org/docs/json',
        reliability: 'Official',
        confidence: 0.95,
      },
    ],
  },
};

// See detail.test.tsx: clear per-render QueryClients so Jest exits normally.
let activeClients: QueryClient[] = [];

function renderSources() {
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  });
  activeClients.push(queryClient);
  render(
    <QueryClientProvider client={queryClient}>
      <SourcesScreen />
    </QueryClientProvider>
  );
  return queryClient;
}

describe('SourcesScreen — aggregation states', () => {
  let apiFetchSpy: jest.SpyInstance;

  beforeEach(() => {
    jest.clearAllMocks();
    apiFetchSpy = jest.spyOn(client, 'apiFetch');
  });

  afterEach(() => {
    apiFetchSpy.mockRestore();
    for (const queryClient of activeClients) {
      queryClient.clear();
    }
    activeClients = [];
  });

  it('shows a true-empty state when no completed briefs exist', async () => {
    apiFetchSpy.mockImplementation(async (url: string) => {
      if (url.startsWith('/api/comparisons?limit')) {
        return { comparisons: [] };
      }
      throw new Error(`unexpected fetch ${url}`);
    });

    renderSources();

    await waitFor(() => expect(screen.getByText('No Citations Available')).toBeTruthy());
    expect(screen.getByText(/No completed briefs in the recent set/)).toBeTruthy();
  });

  it('shows a partial banner when some detail fetches fail', async () => {
    apiFetchSpy.mockImplementation(async (url: string) => {
      if (url.startsWith('/api/comparisons?limit')) {
        return { comparisons: [COMPLETED('comp-s1'), COMPLETED('comp-s2')] };
      }
      if (url === '/api/comparisons/comp-s1') {
        return DETAIL_WITH_SOURCE;
      }
      throw { statusCode: 502, message: 'detail failed', code: 'HTTP_502' };
    });

    renderSources();

    await waitFor(() => expect(screen.getByText('Postgres JSON docs')).toBeTruthy());
    expect(screen.getByText(/Partial results/)).toBeTruthy();
    expect(screen.getByText(/Across the 2 most recent completed briefs/)).toBeTruthy();
  });

  it('shows an unavailable state (not empty) when every detail fetch fails', async () => {
    apiFetchSpy.mockImplementation(async (url: string) => {
      if (url.startsWith('/api/comparisons?limit')) {
        return { comparisons: [COMPLETED('comp-s1')] };
      }
      throw { statusCode: 502, message: 'detail failed', code: 'HTTP_502' };
    });

    renderSources();

    await waitFor(() => expect(screen.getByText('Sources Unavailable')).toBeTruthy());
    expect(screen.queryByText('No Citations Available')).toBeNull();
  });

  it('labels counts neutrally and states the recent-history scope', async () => {
    apiFetchSpy.mockImplementation(async (url: string) => {
      if (url.startsWith('/api/comparisons?limit')) {
        return { comparisons: [COMPLETED('comp-s1')] };
      }
      return DETAIL_WITH_SOURCE;
    });

    renderSources();

    await waitFor(() => expect(screen.getByText('1 CITATIONS')).toBeTruthy());
    expect(screen.queryByText(/VERIFIED/)).toBeNull();
    expect(screen.getByText(/Across the 1 most recent completed brief/)).toBeTruthy();
  });

  it('supports search filtering over the aggregated list', async () => {
    apiFetchSpy.mockImplementation(async (url: string) => {
      if (url.startsWith('/api/comparisons?limit')) {
        return { comparisons: [COMPLETED('comp-s1')] };
      }
      return DETAIL_WITH_SOURCE;
    });

    renderSources();
    await waitFor(() => expect(screen.getByText('Postgres JSON docs')).toBeTruthy());

    fireEvent.changeText(
      screen.getByPlaceholderText('Filter cited sources and domains...'),
      'nonexistent-domain-xyz'
    );
    await waitFor(() => expect(screen.getByText('No Citations Available')).toBeTruthy());
  });
});
