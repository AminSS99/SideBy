import React from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { render, screen, fireEvent, waitFor } from '@testing-library/react-native';
import ComparisonDetailScreen from '../[id]';
import * as client from '../../../src/api/client';

jest.mock('expo-router', () => {
  return {
    useRouter: () => ({ push: jest.fn(), replace: jest.fn(), navigate: jest.fn() }),
    useLocalSearchParams: () => ({ id: 'comp-detail-1' }),
  };
});

jest.mock('../../../src/providers/NetworkProvider', () => {
  return {
    useNetwork: () => ({ isOffline: false }),
  };
});

jest.mock('expo-symbols', () => {
  const React = require('react');
  const { View } = require('react-native');
  return {
    SymbolView: (props: any) => <View {...props} />,
  };
});

jest.mock('expo-blur', () => {
  const React = require('react');
  const { View } = require('react-native');
  return {
    BlurView: ({ children, ...props }: any) => <View {...props}>{children}</View>,
  };
});

jest.mock('expo-glass-effect', () => {
  const React = require('react');
  const { View } = require('react-native');
  return {
    GlassView: ({ children, ...props }: any) => <View {...props}>{children}</View>,
    isGlassEffectAPIAvailable: () => false,
    isLiquidGlassAvailable: () => false,
  };
});

jest.mock('expo-linear-gradient', () => {
  const React = require('react');
  const { View } = require('react-native');
  return {
    LinearGradient: ({ children, ...props }: any) => <View {...props}>{children}</View>,
  };
});

jest.mock('expo-web-browser', () => {
  return {
    openBrowserAsync: jest.fn(() => Promise.resolve({ type: 'dismiss' })),
  };
});

jest.mock('expo-haptics', () => {
  return {
    selectionAsync: jest.fn(() => Promise.resolve()),
    impactAsync: jest.fn(() => Promise.resolve()),
    notificationAsync: jest.fn(() => Promise.resolve()),
    ImpactFeedbackStyle: { Light: 'light', Medium: 'medium', Heavy: 'heavy' },
    NotificationFeedbackType: { Success: 'success', Error: 'error', Warning: 'warning' },
  };
});

jest.mock('react-native-gesture-handler', () => {
  const React = require('react');
  const { View } = require('react-native');
  const chain = () => {
    const h: any = {};
    h.onStart = () => h;
    h.onUpdate = () => h;
    h.onEnd = () => h;
    return h;
  };
  return {
    Gesture: { Pan: chain, Tap: chain },
    GestureDetector: ({ children }: any) => <View>{children}</View>,
  };
});

jest.mock('react-native-reanimated', () => {
  const RN = require('react-native');
  const mock: any = {
    createAnimatedComponent: (C: any) => C,
    useSharedValue: (v: any) => ({ value: v }),
    useAnimatedStyle: (fn: any) => fn(),
    withSpring: (v: any) => v,
    withTiming: (v: any) => v,
    withRepeat: (v: any) => v,
    withSequence: (...a: any[]) => a[a.length - 1],
    withDelay: (_d: any, v: any) => v,
    useReducedMotion: () => false,
    runOnJS: (fn: any) => fn,
    Easing: { linear: (t: any) => t, ease: (t: any) => t },
    FlatList: RN.FlatList,
    View: RN.View,
    Text: RN.Text,
    ScrollView: RN.ScrollView,
  };
  mock.default = mock;
  return mock;
});

const DETAIL = {
  id: 'comp-detail-1',
  status: 'completed',
  progress: 100,
  query: 'Postgres vs MySQL for JSON workloads',
  isFavorited: false,
  result: {
    entities: { a: { name: 'Postgres' }, b: { name: 'MySQL' } },
    verdict: { winner: 'a', bestOverall: 'Postgres leads', summary: 'Postgres wins on JSON.' },
    dimensions: [{ subject: 'DX', a: 8, b: 6, fullMark: 10, weight: 1 }],
    sources: [
      { title: 'Postgres JSON docs', url: 'https://postgresql.org/docs/json', reliability: 'Official', confidence: 0.95 },
      { title: 'JSON benchmark', url: 'https://bench.test/json', confidence: 0.85 },
    ],
    consensus: [],
    contradictions: [],
    categories: [],
  },
};

// QueryClients schedule cache-GC timers that keep the Jest event loop
// alive ("Jest did not exit ..."). Track every client created per render
// and clear it after each test so `--runInBand` exits normally.
let activeClients: QueryClient[] = [];

function renderDetail() {
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  });
  activeClients.push(queryClient);
  render(
    <QueryClientProvider client={queryClient}>
      <ComparisonDetailScreen />
    </QueryClientProvider>
  );
  return queryClient;
}

describe('ComparisonDetailScreen — rating and favorite behavior', () => {
  let apiFetchSpy: jest.SpyInstance;

  beforeEach(() => {
    jest.clearAllMocks();
    apiFetchSpy = jest.spyOn(client, 'apiFetch');
  });

  afterEach(() => {
    apiFetchSpy.mockRestore();
    for (const queryClient of activeClients) {
      queryClient.clear();
    }
    activeClients = [];
  });

  it('shows pending then confirmed UI for a successful rating', async () => {
    let resolveFeedback: (v: unknown) => void = () => {};
    const feedbackPromise = new Promise((resolve) => {
      resolveFeedback = resolve;
    });
    // Route POST feedback (with a body) to the deferred promise, GET to the fixture.
    apiFetchSpy.mockImplementation(async (url: string, options?: any) => {
      if (url === '/api/comparisons/comp-detail-1' && options?.method === 'POST') {
        return feedbackPromise;
      }
      return DETAIL;
    });

    renderDetail();
    await screen.findByText('WAS THIS BRIEF HELPFUL?');

    fireEvent.press(screen.getByTestId('feedback-star-4'));
    // Pending: no confirmed text yet.
    expect(screen.queryByText(/Feedback received/)).toBeNull();

    resolveFeedback({ success: true });
    await waitFor(() =>
      expect(screen.getByText('Feedback received (4/5 stars). Thank you!')).toBeTruthy()
    );
  });

  it('shows an error state when rating submission fails', async () => {
    apiFetchSpy.mockImplementation(async (url: string, options?: any) => {
      if (url === '/api/comparisons/comp-detail-1' && options?.method === 'POST') {
        throw { statusCode: 500, message: 'Feedback store unavailable', code: 'HTTP_500' };
      }
      return DETAIL;
    });

    renderDetail();
    await screen.findByText('WAS THIS BRIEF HELPFUL?');

    fireEvent.press(screen.getByTestId('feedback-star-5'));

    await waitFor(() => expect(screen.getByText('Feedback store unavailable')).toBeTruthy());
    expect(screen.queryByText(/Feedback received/)).toBeNull();
  });

  it('ignores overlapping favorite taps and applies the server value', async () => {
    let resolveManage: (v: unknown) => void = () => {};
    const managePromise = new Promise((resolve) => {
      resolveManage = resolve;
    });
    apiFetchSpy.mockImplementation(async (url: string, options?: any) => {
      if (url.endsWith('/manage') && options?.method === 'POST') {
        return managePromise;
      }
      return DETAIL;
    });

    renderDetail();
    await screen.findByText('WAS THIS BRIEF HELPFUL?');

    const favButton = screen.getByTestId('detail-favorite-button');
    fireEvent.press(favButton);
    fireEvent.press(favButton);

    resolveManage({ success: true, comparison: { isFavorited: true } });
    await waitFor(() =>
      expect(apiFetchSpy).toHaveBeenCalledWith(
        '/api/comparisons/comp-detail-1/manage',
        expect.objectContaining({ method: 'POST' })
      )
    );
    const manageCalls = apiFetchSpy.mock.calls.filter((call) =>
      String(call[0]).endsWith('/manage')
    );
    expect(manageCalls).toHaveLength(1);
  });

  it('labels cited evidence neutrally instead of SOURCE VERIFIED', async () => {
    apiFetchSpy.mockResolvedValue(DETAIL);

    renderDetail();

    await waitFor(() => expect(screen.getByText('CITED EVIDENCE')).toBeTruthy());
    expect(screen.queryByText('SOURCE VERIFIED')).toBeNull();
  });
});
