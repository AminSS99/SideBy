/**
 * sideby-ios-scene — Expo config plugin reproducing the manual iOS launch
 * fixes that B00-R1 applied directly to ignored `ios/` output.
 *
 * Reproduces, from tracked source:
 *  1. AppDelegate: UIScene `configurationForConnecting` + `SceneDelegate`
 *     (windowScene attach for iOS 26/27 SDK runtime compatibility).
 *  2. AppDelegate: build-configuration-gated `bundleURL()` — Debug always
 *     loads from Metro (`RCTBundleURLProvider`), Release loads the embedded
 *     `main.jsbundle`. An embedded bundle must never silently override
 *     Metro in Debug, even when `main.jsbundle` is present on disk.
 *  3. Info.plist: `UIApplicationSceneManifest` wiring the scene delegate,
 *     plus `RCTNewArchEnabled` parity with `app.json` (`newArchEnabled`).
 *
 * All transforms are idempotent: re-running prebuild without `--clean`
 * never duplicates them, and trees written by the retired static-first
 * `bundleURL()` variant are repaired back to the gated block.
 * Provenance: verified by the B00-R3 extraction → prebuild → simulator
 * build → launch run (see B00-R3 evidence); earlier fresh-checkout claims
 * were withdrawn until that run completed.
 */
const { withAppDelegate, withInfoPlist } = require('expo/config-plugins');

const SCENE_DELEGATE_CLASS = `
class SceneDelegate: UIResponder, UIWindowSceneDelegate {
  var window: UIWindow?

  func scene(
    _ scene: UIScene,
    willConnectTo session: UISceneSession,
    options connectionOptions: UIScene.ConnectionOptions
  ) {
    guard let windowScene = scene as? UIWindowScene else { return }
    let appDelegate = UIApplication.shared.delegate as? AppDelegate
    if let window = appDelegate?.window {
      window.windowScene = windowScene
      self.window = window
      window.makeKeyAndVisible()
    }
  }
}
`;

const SCENE_CONFIG_METHOD = `
  // sideby-ios-scene: UIScene lifecycle support for current SDK runtime compatibility
  public func application(
    _ application: UIApplication,
    configurationForConnecting connectingSceneSession: UISceneSession,
    options: UIScene.ConnectionOptions
  ) -> UISceneConfiguration {
    let sceneConfig = UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    sceneConfig.delegateClass = SceneDelegate.self
    return sceneConfig
  }
`;

const UNIVERSAL_LINKS_ANCHOR =
  'return super.application(application, continue: userActivity, restorationHandler: restorationHandler) || result\n  }';

const DEBUG_BUNDLE_URL_BLOCK = `  override func bundleURL() -> URL? {
#if DEBUG
    return RCTBundleURLProvider.sharedSettings().jsBundleURL(forBundleRoot: ".expo/.virtual-metro-entry")
#else
    return Bundle.main.url(forResource: "main", withExtension: "jsbundle")
#endif
  }`;

const STATIC_FIRST_BUNDLE_URL_BLOCK = `  // sideby-ios-scene: prefer the embedded bundle when present (Release),
  // fall back to the Metro bundler URL otherwise (Debug / dev-client).
  override func bundleURL() -> URL? {
    if let bundle = Bundle.main.url(forResource: "main", withExtension: "jsbundle") {
      return bundle
    }
    return RCTBundleURLProvider.sharedSettings().jsBundleURL(forBundleRoot: ".expo/.virtual-metro-entry")
  }`;

function withSceneAppDelegate(config) {
  return withAppDelegate(config, (config) => {
    let contents = config.modResults.contents;

    if (!contents.includes('configurationForConnecting')) {
      if (!contents.includes(UNIVERSAL_LINKS_ANCHOR)) {
        throw new Error(
          '[sideby-ios-scene] AppDelegate anchor not found; template changed — update the plugin.'
        );
      }
      contents = contents.replace(
        UNIVERSAL_LINKS_ANCHOR,
        `${UNIVERSAL_LINKS_ANCHOR}\n${SCENE_CONFIG_METHOD}`
      );
    }

    if (!contents.includes('class SceneDelegate')) {
      // Insert after the AppDelegate class closes (right before ReactNativeDelegate).
      const delegateAnchor = '\nclass ReactNativeDelegate: ExpoReactNativeFactoryDelegate {';
      if (!contents.includes(delegateAnchor)) {
        throw new Error(
          '[sideby-ios-scene] ReactNativeDelegate anchor not found; template changed — update the plugin.'
        );
      }
      contents = contents.replace(
        delegateAnchor,
        `\n${SCENE_DELEGATE_CLASS}\nclass ReactNativeDelegate: ExpoReactNativeFactoryDelegate {`
      );
    }

    if (contents.includes('sideby-ios-scene: prefer the embedded bundle')) {
      // Repair trees written by the retired static-first variant: Debug
      // must resolve Metro even when main.jsbundle exists on disk.
      contents = contents.replace(STATIC_FIRST_BUNDLE_URL_BLOCK, DEBUG_BUNDLE_URL_BLOCK);
    }
    if (!contents.includes(DEBUG_BUNDLE_URL_BLOCK)) {
      throw new Error(
        '[sideby-ios-scene] bundleURL anchor not found; template changed — update the plugin.'
      );
    }

    config.modResults.contents = contents;
    return config;
  });
}

function withSceneInfoPlist(config) {
  return withInfoPlist(config, (config) => {
    config.modResults.UIApplicationSceneManifest = {
      UIApplicationSupportsMultipleScenes: false,
      UISceneConfigurations: {
        UIWindowSceneSessionRoleApplication: [
          {
            UISceneConfigurationName: 'Default Configuration',
            UISceneDelegateClassName: '$(PRODUCT_MODULE_NAME).SceneDelegate',
          },
        ],
      },
    };
    if (config.ios?.newArchEnabled ?? config.newArchEnabled ?? true) {
      config.modResults.RCTNewArchEnabled = true;
    }
    return config;
  });
}

module.exports = function sidebyIosScenePlugin(config) {
  config = withSceneAppDelegate(config);
  config = withSceneInfoPlist(config);
  return config;
};
