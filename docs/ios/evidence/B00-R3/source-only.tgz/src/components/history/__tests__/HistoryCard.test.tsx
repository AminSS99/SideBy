import React from 'react';
import { render, screen } from '@testing-library/react-native';
import { HistoryCard } from '../HistoryCard';

jest.mock('expo-symbols', () => {
  const React = require('react');
  const { View } = require('react-native');
  return {
    SymbolView: (props: any) => <View {...props} />,
  };
});

jest.mock('expo-router', () => ({
  useRouter: () => ({ push: jest.fn() }),
}));

jest.mock('react-native-reanimated', () => {
  const RN = require('react-native');
  const mock: any = {
    createAnimatedComponent: (C: any) => C,
    useSharedValue: (v: any) => ({ value: v }),
    useAnimatedStyle: (fn: any) => fn(),
    withSpring: (v: any) => v,
    withTiming: (v: any) => v,
    useReducedMotion: () => false,
    runOnJS: (fn: any) => fn,
  };
  mock.default = mock;
  return mock;
});

const BASE_ITEM: any = {
  id: 'comp-1',
  query: 'Postgres vs MySQL',
  status: 'completed',
  progress: 100,
  updatedAt: new Date().toISOString(),
  isFavorited: false,
};

describe('HistoryCard — neutral source trust label', () => {
  it('never claims verified sources', () => {
    render(<HistoryCard item={{ ...BASE_ITEM, sourceCount: 4 }} onPress={() => {}} />);
    expect(screen.queryByText(/verified/i)).toBeNull();
    expect(screen.getByText(/4 sources/i)).toBeTruthy();
  });

  it('never fabricates a source count when unknown', () => {
    const { sourceCount, ...rest } = BASE_ITEM;
    render(<HistoryCard item={rest as any} onPress={() => {}} />);
    expect(screen.queryByText(/16/)).toBeNull();
    expect(screen.queryByText(/verified/i)).toBeNull();
  });
});
