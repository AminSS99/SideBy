import React from 'react';
import { render, screen } from '@testing-library/react-native';
import { UsageGauge } from '../UsageGauge';
import { NormalizedUsage } from '../../../api/usage';

jest.mock('expo-blur', () => {
  const React = require('react');
  const { View } = require('react-native');
  return {
    BlurView: ({ children, ...props }: any) => <View {...props}>{children}</View>,
  };
});

jest.mock('expo-glass-effect', () => {
  const React = require('react');
  const { View } = require('react-native');
  return {
    GlassView: ({ children, ...props }: any) => <View {...props}>{children}</View>,
    isGlassEffectAPIAvailable: () => false,
    isLiquidGlassAvailable: () => false,
  };
});

jest.mock('expo-linear-gradient', () => {
  const React = require('react');
  const { View } = require('react-native');
  return {
    LinearGradient: ({ children, ...props }: any) => <View {...props}>{children}</View>,
  };
});

jest.mock('expo-haptics', () => ({
  selectionAsync: jest.fn().mockResolvedValue(undefined),
  impactAsync: jest.fn().mockResolvedValue(undefined),
  notificationAsync: jest.fn().mockResolvedValue(undefined),
  ImpactFeedbackStyle: { Light: 'light', Medium: 'medium', Heavy: 'heavy' },
  NotificationFeedbackType: { Success: 'success', Error: 'error', Warning: 'warning' },
}));

function finiteUsage(): NormalizedUsage {
  return {
    plan: 'Pro Plan',
    planKnown: true,
    subscriptionStatus: 'active',
    entitlementAllowed: true,
    accessStatus: 'active',
    comparison: { used: 3, limit: 20, remaining: 17, state: 'finite', isUnlimited: false },
    followUp: { used: 5, limit: 50, remaining: 45, state: 'finite', isUnlimited: false },
    refresh: { used: 1, limit: 10, remaining: 9, state: 'finite', isUnlimited: false },
    dailyQueries: 3,
    dailyLimit: 20,
    resetAt: 'Midnight UTC',
  };
}

describe('UsageGauge — honest quota rendering', () => {
  it('renders finite counts and an Active badge for a known plan', () => {
    render(<UsageGauge usage={finiteUsage()} />);
    expect(screen.getByText('Pro Plan')).toBeTruthy();
    expect(screen.getByText('Active')).toBeTruthy();
    expect(screen.getByText('3 / 20')).toBeTruthy();
  });

  it('renders explicit unlimited entitlements as Unlimited', () => {
    const usage = finiteUsage();
    usage.comparison = { used: 42, limit: null, remaining: null, state: 'unlimited', isUnlimited: true };
    render(<UsageGauge usage={usage} />);
    expect(screen.getByText('Unlimited')).toBeTruthy();
  });

  it('renders unknown quotas as Unknown with an Unknown badge, never Active or Unlimited', () => {
    const usage = finiteUsage();
    usage.plan = 'Unknown plan';
    usage.planKnown = false;
    usage.subscriptionStatus = 'unknown';
    usage.entitlementAllowed = null;
    usage.accessStatus = 'unknown';
    usage.comparison = { used: null, limit: null, remaining: null, state: 'unknown', isUnlimited: false };
    render(<UsageGauge usage={usage} />);
    expect(screen.getByText('Unknown plan')).toBeTruthy();
    expect(screen.getAllByText('Unknown').length).toBeGreaterThanOrEqual(2);
    expect(screen.queryByText('Active')).toBeNull();
    expect(screen.queryByText('Unlimited')).toBeNull();
  });

  it('renders Inactive, never Active, for a known inactive backend status', () => {
    const usage = finiteUsage();
    usage.subscriptionStatus = 'inactive';
    usage.accessStatus = 'inactive';
    render(<UsageGauge usage={usage} />);
    expect(screen.getByText('Pro Plan')).toBeTruthy();
    expect(screen.getByText('Inactive')).toBeTruthy();
    expect(screen.queryByText('Active')).toBeNull();
  });

  it('renders Trialing for a trialing backend status', () => {
    const usage = finiteUsage();
    usage.subscriptionStatus = 'trialing';
    usage.accessStatus = 'trialing';
    render(<UsageGauge usage={usage} />);
    expect(screen.getByText('Trialing')).toBeTruthy();
    expect(screen.queryByText('Active')).toBeNull();
  });

  it('renders Inactive when the entitlement is denied even with an active status', () => {
    const usage = finiteUsage();
    usage.subscriptionStatus = 'active';
    usage.entitlementAllowed = false;
    usage.accessStatus = 'inactive';
    render(<UsageGauge usage={usage} />);
    expect(screen.getByText('Inactive')).toBeTruthy();
    expect(screen.queryByText('Active')).toBeNull();
  });

  it('shows unknown remaining for a known plan with unknown quota', () => {
    const usage = finiteUsage();
    usage.comparison = { used: 4, limit: null, remaining: null, state: 'unknown', isUnlimited: false };
    render(<UsageGauge usage={usage} />);
    expect(screen.getByText('Active')).toBeTruthy();
    expect(screen.getByText('Unknown')).toBeTruthy();
    expect(screen.queryByText('Unlimited')).toBeNull();
  });

  it('renders an unavailable state on query error instead of Unlimited defaults', () => {
    render(<UsageGauge usage={undefined} loadState="error" />);
    expect(screen.getByText('Usage unavailable')).toBeTruthy();
    expect(screen.queryByText('Unlimited')).toBeNull();
    expect(screen.queryByText('Active')).toBeNull();
  });

  it('renders a loading state while the usage query is in flight', () => {
    render(<UsageGauge usage={undefined} loadState="loading" />);
    expect(screen.getByText('Loading usage…')).toBeTruthy();
  });
});
