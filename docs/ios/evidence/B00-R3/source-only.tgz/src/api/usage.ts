import { apiFetch } from './client';
import { ApiError } from '../types/api';

/**
 * Quota knowledge state for a single metric.
 * - 'finite': server supplied a numeric limit.
 * - 'unlimited': server explicitly reported no limit (JSON null).
 * - 'unknown': server omitted the limit, so no quota claim can be made.
 * A missing field must never render as "Unlimited" or as a known count.
 */
export type QuotaState = 'finite' | 'unlimited' | 'unknown';

export interface UsageQuotaMetric {
  used: number | null; // null when the server did not report usage
  limit: number | null; // null when unlimited OR unknown — see `state`
  remaining: number | null; // null when unlimited, unknown, or used is unknown
  state: QuotaState;
  isUnlimited: boolean; // true only when state === 'unlimited'
}

/**
 * Authoritative subscription lifecycle status from the backend usage
 * handler (`subscription.status`). Never infer this from the plan name:
 * a known plan string with status 'inactive' or 'unknown' must not
 * render as Active.
 */
export type SubscriptionStatus = 'active' | 'trialing' | 'inactive' | 'unknown';

const SUBSCRIPTION_STATUSES: readonly SubscriptionStatus[] = [
  'active',
  'trialing',
  'inactive',
  'unknown',
];

export interface NormalizedUsage {
  plan: string; // 'Unknown plan' when the server did not report one
  planKnown: boolean;
  /** Raw `subscription.status`; 'unknown' when absent or unrecognized. */
  subscriptionStatus: SubscriptionStatus;
  /** Raw `subscription.entitlement.allowed`; null when the server omitted it. */
  entitlementAllowed: boolean | null;
  /**
   * Effective badge status: 'inactive' whenever the entitlement is
   * explicitly denied (`allowed === false`), otherwise the raw
   * `subscriptionStatus`. Only 'active' and 'trialing' may render an
   * affirmative badge.
   */
  accessStatus: SubscriptionStatus;
  comparison: UsageQuotaMetric;
  followUp: UsageQuotaMetric;
  refresh: UsageQuotaMetric;
  dailyQueries: number | null;
  dailyLimit: number | null;
  resetAt: string | null; // null when the server did not report a reset time
}

/**
 * Fetches real usage status and quota limits for the authenticated user.
 * Rejects malformed server payloads ({}) rather than synthesizing a fake Free Plan.
 * Throws a typed ApiError on network, authentication, or schema failure.
 */
export async function fetchUsageStatus(): Promise<NormalizedUsage> {
  const json = await apiFetch<any>('/api/usage');

  if (!json || typeof json !== 'object' || (!json.plan && !json.limits && !json.usage)) {
    const err: ApiError = {
      statusCode: 502,
      message: 'Invalid usage payload received from server.',
      code: 'MALFORMED_RESPONSE',
    };
    throw err;
  }

  const rawPlan = json.plan;
  const subscriptionStatusEarly =
    typeof json.subscription?.status === 'string' ? json.subscription.status : undefined;
  // A fallback plan guess (subscription.status "unknown") is not authoritative.
  const planKnown =
    typeof rawPlan === 'string' &&
    rawPlan.trim().length > 0 &&
    subscriptionStatusEarly !== 'unknown';
  const plan = !planKnown
    ? 'Unknown plan'
    : rawPlan === 'free'
    ? 'Free Tier'
    : rawPlan === 'pro'
    ? 'Pro Plan'
    : rawPlan.charAt(0).toUpperCase() + rawPlan.slice(1);

  const rawUsage = json.usage || {};
  const rawLimits = json.limits || {};
  // The verified backend contract (frontend/api/_routes/usage.ts +
  // api/_lib/subscription.ts + api/_lib/rate-limit.ts, read 2026-10-12):
  // - usage.<metric> always carries the free-plan daily window
  //   ({used, limit, remaining}, finite numbers), regardless of plan.
  // - The paid entitlement lives in limits.* as UNLIMITED, which is
  //   serialized as Number.MAX_SAFE_INTEGER — never as JSON null.
  // - subscription.status may be "unknown" (free_fallback): the plan value
  //   is then a fallback guess, not an authoritative entitlement.
  const comparison = parseQuotaMetric(
    typeof rawUsage.comparison?.used === 'number'
      ? rawUsage.comparison.used
      : typeof rawUsage.dailyQueries === 'number'
      ? rawUsage.dailyQueries
      : undefined,
    rawUsage.comparison?.limit,
    rawLimits.comparisonsPerDay !== undefined
      ? rawLimits.comparisonsPerDay
      : rawLimits.dailyQueries,
    rawUsage.comparison?.remaining
  );
  const followUp = parseQuotaMetric(
    rawUsage.followUp?.used,
    rawUsage.followUp?.limit,
    rawLimits.followUpsPerDay,
    rawUsage.followUp?.remaining
  );
  const refresh = parseQuotaMetric(
    rawUsage.refresh?.used,
    rawUsage.refresh?.limit,
    rawLimits.refreshesPerDay,
    rawUsage.refresh?.remaining
  );

  const rawStatus = json.subscription?.status;
  const subscriptionStatus: SubscriptionStatus =
    typeof rawStatus === 'string' &&
    (SUBSCRIPTION_STATUSES as readonly string[]).includes(rawStatus)
      ? (rawStatus as SubscriptionStatus)
      : 'unknown';
  const rawAllowed = json.subscription?.entitlement?.allowed;
  const entitlementAllowed: boolean | null =
    typeof rawAllowed === 'boolean' ? rawAllowed : null;
  // An explicitly denied entitlement overrides an affirmative status:
  // access is inactive even when the status string says otherwise.
  const accessStatus: SubscriptionStatus =
    entitlementAllowed === false ? 'inactive' : subscriptionStatus;

  return {
    plan,
    planKnown,
    subscriptionStatus,
    entitlementAllowed,
    accessStatus,
    comparison,
    followUp,
    refresh,
    dailyQueries: comparison.used,
    dailyLimit: comparison.limit,
    resetAt: typeof rawUsage.resetAt === 'string' ? rawUsage.resetAt : null,
  };
}

/**
 * Normalizes one quota metric into finite / unlimited / unknown.
 * Either source may declare unlimited: explicit JSON null or the backend's
 * UNLIMITED sentinel (Number.MAX_SAFE_INTEGER). A plan-level unlimited
 * wins over a finite free-window number in the usage metric.
 * An omitted limit (undefined) in both sources is unknown — never
 * unlimited, never zero-used.
 */
function parseQuotaMetric(
  rawUsed: unknown,
  rawMetricLimit: unknown,
  rawPlanLimit: unknown,
  rawRemaining: unknown
): UsageQuotaMetric {
  const used = typeof rawUsed === 'number' ? rawUsed : null;

  if (isUnlimitedValue(rawMetricLimit) || isUnlimitedValue(rawPlanLimit)) {
    return { used, limit: null, remaining: null, state: 'unlimited', isUnlimited: true };
  }
  const limit =
    typeof rawMetricLimit === 'number'
      ? rawMetricLimit
      : typeof rawPlanLimit === 'number'
      ? rawPlanLimit
      : null;
  if (limit === null) {
    return { used, limit: null, remaining: null, state: 'unknown', isUnlimited: false };
  }
  const remaining =
    used === null
      ? null
      : typeof rawRemaining === 'number'
      ? rawRemaining
      : Math.max(0, limit - used);
  return { used, limit, remaining, state: 'finite', isUnlimited: false };
}

function isUnlimitedValue(v: unknown): boolean {
  return v === null || (typeof v === 'number' && v >= Number.MAX_SAFE_INTEGER);
}

/**
 * Returns static example usage status for preview screens without live backend.
 */
export function getExampleUsageStatus(): NormalizedUsage {
  return {
    plan: 'Pro Plan',
    planKnown: true,
    subscriptionStatus: 'active',
    entitlementAllowed: true,
    accessStatus: 'active',
    comparison: { used: 3, limit: 20, remaining: 17, state: 'finite', isUnlimited: false },
    followUp: { used: 5, limit: 50, remaining: 45, state: 'finite', isUnlimited: false },
    refresh: { used: 1, limit: 10, remaining: 9, state: 'finite', isUnlimited: false },
    dailyQueries: 3,
    dailyLimit: 20,
    resetAt: 'Midnight UTC',
  };
}
