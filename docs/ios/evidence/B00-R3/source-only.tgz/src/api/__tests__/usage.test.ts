process.env['EXPO_PUBLIC_API_URL'] = 'https://api.sideby.app';

import { fetchUsageStatus } from '../usage';
import * as client from '../client';

describe('Usage API — Strict Quota Contract and Unlimited Tier Support', () => {
  let apiFetchSpy: jest.SpyInstance;

  beforeEach(() => {
    jest.clearAllMocks();
    apiFetchSpy = jest.spyOn(client, 'apiFetch');
  });

  afterEach(() => {
    apiFetchSpy.mockRestore();
  });

  it('rejects malformed or empty payloads ({}) with typed MALFORMED_RESPONSE error', async () => {
    apiFetchSpy.mockResolvedValueOnce({});

    await expect(fetchUsageStatus()).rejects.toEqual(
      expect.objectContaining({
        statusCode: 502,
        code: 'MALFORMED_RESPONSE',
        message: 'Invalid usage payload received from server.',
      })
    );
  });

  it('correctly maps null limits to unlimited quota (isUnlimited: true, limit: null)', async () => {
    apiFetchSpy.mockResolvedValueOnce({
      plan: 'enterprise',
      limits: {
        comparison: null,
        followUp: null,
        refresh: null,
      },
      usage: {
        comparison: { used: 42, limit: null, remaining: null },
        followUp: { used: 120, limit: null, remaining: null },
        refresh: { used: 15, limit: null, remaining: null },
      },
    });

    const result = await fetchUsageStatus();

    expect(result.plan).toBe('Enterprise');
    expect(result.comparison.isUnlimited).toBe(true);
    expect(result.comparison.limit).toBeNull();
    expect(result.comparison.remaining).toBeNull();
    expect(result.comparison.used).toBe(42);

    expect(result.followUp.isUnlimited).toBe(true);
    expect(result.followUp.limit).toBeNull();
    expect(result.refresh.isUnlimited).toBe(true);
  });

  it('parses structured numerical quotas for standard subscription tiers', async () => {
    apiFetchSpy.mockResolvedValueOnce({
      plan: 'pro',
      limits: {
        comparison: 50,
        followUp: 100,
        refresh: 20,
      },
      usage: {
        comparison: { used: 5, limit: 50, remaining: 45 },
        followUp: { used: 12, limit: 100, remaining: 88 },
        refresh: { used: 2, limit: 20, remaining: 18 },
      },
    });

    const result = await fetchUsageStatus();

    expect(result.plan).toBe('Pro Plan');
    expect(result.planKnown).toBe(true);
    expect(result.comparison.isUnlimited).toBe(false);
    expect(result.comparison.state).toBe('finite');
    expect(result.comparison.used).toBe(5);
    expect(result.comparison.limit).toBe(50);
    expect(result.comparison.remaining).toBe(45);
  });

  it('marks omitted limits as unknown, never unlimited or zero-used', async () => {
    apiFetchSpy.mockResolvedValueOnce({
      plan: 'pro',
      limits: {},
      usage: {
        comparison: { used: 5 },
        followUp: {},
        refresh: {},
      },
    });

    const result = await fetchUsageStatus();

    expect(result.comparison.state).toBe('unknown');
    expect(result.comparison.isUnlimited).toBe(false);
    expect(result.comparison.limit).toBeNull();
    expect(result.comparison.remaining).toBeNull();
    expect(result.comparison.used).toBe(5);
    expect(result.followUp.state).toBe('unknown');
    expect(result.followUp.used).toBeNull();
  });

  it('reports an unknown plan instead of a default active plan label', async () => {
    apiFetchSpy.mockResolvedValueOnce({
      limits: { comparisonsPerDay: 10 },
      usage: { comparison: { used: 1, limit: 10, remaining: 9 } },
    });

    const result = await fetchUsageStatus();

    expect(result.plan).toBe('Unknown plan');
    expect(result.planKnown).toBe(false);
  });

  it('leaves remaining unknown when a finite limit has no reported usage', async () => {
    apiFetchSpy.mockResolvedValueOnce({
      plan: 'free',
      limits: { comparisonsPerDay: 10 },
      usage: { comparison: { limit: 10 } },
    });

    const result = await fetchUsageStatus();

    expect(result.comparison.state).toBe('finite');
    expect(result.comparison.used).toBeNull();
    expect(result.comparison.remaining).toBeNull();
  });

  it('treats the backend MAX_SAFE_INTEGER sentinel as unlimited, winning over free-window numbers', async () => {
    apiFetchSpy.mockResolvedValueOnce({
      plan: 'pro',
      limits: {
        comparisonsPerDay: Number.MAX_SAFE_INTEGER,
        followUpsPerDay: Number.MAX_SAFE_INTEGER,
        refreshesPerDay: Number.MAX_SAFE_INTEGER,
      },
      usage: {
        comparison: { used: 2, limit: 5, remaining: 3 },
        followUp: { used: 1, limit: 10, remaining: 9 },
        refresh: { used: 0, limit: 3, remaining: 3 },
      },
      subscription: { status: 'active' },
    });

    const result = await fetchUsageStatus();

    expect(result.comparison.state).toBe('unlimited');
    expect(result.comparison.isUnlimited).toBe(true);
    expect(result.followUp.state).toBe('unlimited');
    expect(result.refresh.state).toBe('unlimited');
  });

  it('marks the plan unknown when subscription authority is unknown', async () => {
    apiFetchSpy.mockResolvedValueOnce({
      plan: 'free',
      limits: { comparisonsPerDay: 5 },
      usage: { comparison: { used: 1, limit: 5, remaining: 4 } },
      subscription: { source: 'free_fallback', status: 'unknown' },
    });

    const result = await fetchUsageStatus();

    expect(result.planKnown).toBe(false);
    expect(result.plan).toBe('Unknown plan');
  });

  it.each(['active', 'trialing', 'inactive', 'unknown'] as const)(
    'parses subscription status %s without changing quota truth',
    async (status) => {
      apiFetchSpy.mockResolvedValueOnce({
        plan: 'pro',
        limits: { comparisonsPerDay: 10 },
        usage: { comparison: { used: 1, limit: 10, remaining: 9 } },
        subscription: { source: 'snapsolve_entitlement', status },
      });

      const result = await fetchUsageStatus();

      expect(result.subscriptionStatus).toBe(status);
      expect(result.entitlementAllowed).toBeNull();
      expect(result.accessStatus).toBe(status);
      expect(result.comparison.state).toBe('finite');
    }
  );

  it('defaults to unknown status when the server omits or mislabels it', async () => {
    for (const subscription of [undefined, {}, { status: 'cancelled' }, { status: 42 }]) {
      apiFetchSpy.mockResolvedValueOnce({
        plan: 'pro',
        limits: { comparisonsPerDay: 10 },
        usage: { comparison: { used: 1, limit: 10, remaining: 9 } },
        subscription,
      });

      const result = await fetchUsageStatus();

      expect(result.subscriptionStatus).toBe('unknown');
      expect(result.accessStatus).toBe('unknown');
    }
  });

  it.each([
    ['finite', { comparisonsPerDay: 10 }, { used: 1, limit: 10, remaining: 9 }, 'finite'],
    ['unlimited', { comparisonsPerDay: 10 }, { used: 7, limit: null, remaining: null }, 'unlimited'],
    ['missing', {}, {}, 'unknown'],
  ])(
    'marks access inactive for a denied entitlement with %s quota',
    async (_label, limits, comparison, expectedState) => {
      apiFetchSpy.mockResolvedValueOnce({
        plan: 'pro',
        limits,
        usage: { comparison },
        subscription: {
          source: 'snapsolve_entitlement',
          status: 'active',
          entitlement: { allowed: false, reason: 'past_due' },
        },
      });

      const result = await fetchUsageStatus();

      expect(result.subscriptionStatus).toBe('active');
      expect(result.entitlementAllowed).toBe(false);
      expect(result.accessStatus).toBe('inactive');
      expect(result.comparison.state).toBe(expectedState);
    }
  );

  it.each(['active', 'trialing', 'inactive', 'unknown'] as const)(
    'keeps denied entitlement inactive regardless of raw status %s',
    async (status) => {
      apiFetchSpy.mockResolvedValueOnce({
        plan: 'pro',
        limits: {},
        usage: { comparison: {} },
        subscription: {
          source: 'snapsolve_entitlement',
          status,
          entitlement: { allowed: false },
        },
      });

      const result = await fetchUsageStatus();

      expect(result.accessStatus).toBe('inactive');
      expect(result.comparison.state).toBe('unknown');
    }
  );

  it('keeps an allowed entitlement on the raw inactive status', async () => {
    apiFetchSpy.mockResolvedValueOnce({
      plan: 'pro',
      limits: { comparisonsPerDay: 10 },
      usage: { comparison: { used: 1, limit: 10, remaining: 9 } },
      subscription: {
        source: 'snapsolve_entitlement',
        status: 'inactive',
        entitlement: { allowed: true },
      },
    });

    const result = await fetchUsageStatus();

    expect(result.subscriptionStatus).toBe('inactive');
    expect(result.entitlementAllowed).toBe(true);
    expect(result.accessStatus).toBe('inactive');
  });

  it('preserves unknown remaining for a known plan with unknown quota', async () => {
    apiFetchSpy.mockResolvedValueOnce({
      plan: 'pro',
      limits: {},
      usage: { comparison: { used: 4 } },
      subscription: { source: 'snapsolve_entitlement', status: 'active' },
    });

    const result = await fetchUsageStatus();

    expect(result.planKnown).toBe(true);
    expect(result.accessStatus).toBe('active');
    expect(result.comparison.state).toBe('unknown');
    expect(result.comparison.remaining).toBeNull();
  });

  it('leaves reset time unknown when the server omits it', async () => {
    apiFetchSpy.mockResolvedValueOnce({
      plan: 'free',
      limits: { comparisonsPerDay: 10 },
      usage: { comparison: { used: 1, limit: 10, remaining: 9 } },
    });

    const result = await fetchUsageStatus();

    expect(result.resetAt).toBeNull();
  });
});
